"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Field, Input } from "@/components/ui/input";
import { InlineAlert } from "@/components/ui/states";
import { api, errorMessage } from "@/lib/client/api";
import { forgotPasswordSchema, type ForgotPasswordInput } from "@/lib/validation";

export default function ForgotPasswordPage() {
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ devResetLink: string | null } | null>(null);
  const form = useForm<ForgotPasswordInput>({ resolver: zodResolver(forgotPasswordSchema), defaultValues: { email: "" } });

  const onSubmit = form.handleSubmit(async (values) => {
    setError(null);
    try {
      setResult(await api<{ devResetLink: string | null }>("/api/auth/forgot-password", { method: "POST", json: values }));
    } catch (err) {
      setError(errorMessage(err));
    }
  });

  return (
    <Card>
      <CardContent className="space-y-5 p-6">
        <div>
          <h1 className="text-xl font-semibold">Reset your password</h1>
          <p className="mt-1 text-sm text-muted">Enter your e-mail and we will send a reset link if an account exists.</p>
        </div>
        {error && <InlineAlert tone="danger">{error}</InlineAlert>}
        {result ? (
          <InlineAlert tone="success">
            If an account exists for that address, a reset link is on its way (valid for 1 hour).
            {result.devResetLink && (
              <>
                {" "}
                E-mail delivery is not configured here, so use this link:{" "}
                <Link href={result.devResetLink} className="font-medium text-primary underline break-all">
                  Reset password
                </Link>
              </>
            )}
          </InlineAlert>
        ) : (
          <form className="space-y-4" onSubmit={onSubmit} noValidate>
            <Field label="E-mail" htmlFor="email" error={form.formState.errors.email?.message}>
              <Input id="email" type="email" autoComplete="email" {...form.register("email")} />
            </Field>
            <Button type="submit" className="w-full" loading={form.formState.isSubmitting}>
              Send reset link
            </Button>
          </form>
        )}
        <p className="text-center text-sm text-muted">
          <Link href="/login" className="font-medium text-primary hover:underline">
            Back to sign in
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}
