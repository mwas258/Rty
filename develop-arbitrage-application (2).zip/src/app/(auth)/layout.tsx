import { TrendingUp } from "lucide-react";
import Link from "next/link";
import { redirect } from "next/navigation";
import type { ReactNode } from "react";
import { getSessionUser } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export default async function AuthLayout({ children }: { children: ReactNode }) {
  const user = await getSessionUser();
  if (user) redirect("/app");
  return (
    <main className="flex min-h-screen flex-col bg-bg text-fg">
      <header className="mx-auto flex w-full max-w-md items-center justify-between px-5 pt-6">
        <Link href="/" className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary/15 text-primary">
            <TrendingUp className="h-5 w-5" />
          </span>
          <span className="text-sm font-semibold">Arbitrage Finder Pro</span>
        </Link>
      </header>
      <div className="mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-5 py-8">{children}</div>
      <p className="px-5 pb-6 text-center text-[11px] text-muted">Analysis tool only · no guaranteed returns · gamble responsibly</p>
    </main>
  );
}
