"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useQuery } from "@tanstack/react-query";
import { KeyRound } from "lucide-react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox, Field, Input } from "@/components/ui/input";
import { InlineAlert } from "@/components/ui/states";
import { api, errorMessage } from "@/lib/client/api";
import type { AuthUserDTO } from "@/lib/types";
import { loginSchema, type LoginInput } from "@/lib/validation";

const OAUTH_ERRORS: Record<string, string> = {
  oauth_state: "The Google sign-in session expired. Please try again.",
  oauth_email: "Google did not return a verified e-mail address.",
  account_disabled: "This account has been disabled.",
  oauth_not_configured: "Google sign-in is not configured.",
};

function LoginForm() {
  const router = useRouter();
  const params = useSearchParams();
  const next = params.get("next") && params.get("next")!.startsWith("/") ? params.get("next")! : "/app";
  const [mfaToken, setMfaToken] = useState<string | null>(params.get("mfa"));
  const [code, setCode] = useState("");
  const [error, setError] = useState<string | null>(params.get("error") ? OAUTH_ERRORS[params.get("error")!] ?? "Sign-in failed. Please try again." : null);
  const [submitting, setSubmitting] = useState(false);
  const providers = useQuery({ queryKey: ["auth-providers"], queryFn: () => api<{ google: boolean; demoMode: boolean; signupEnabled: boolean }>("/api/auth/providers") });

  const form = useForm<LoginInput>({ resolver: zodResolver(loginSchema), defaultValues: { email: "", password: "", remember: true } });

  useEffect(() => {
    if (mfaToken) setError(null);
  }, [mfaToken]);

  const onSubmit = form.handleSubmit(async (values) => {
    setError(null);
    setSubmitting(true);
    try {
      const res = await api<{ mfaRequired: boolean; challengeToken?: string; user?: AuthUserDTO }>("/api/auth/login", { method: "POST", json: values });
      if (res.mfaRequired && res.challengeToken) {
        setMfaToken(res.challengeToken);
      } else {
        router.push(next);
        router.refresh();
      }
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSubmitting(false);
    }
  });

  const verifyMfa = async () => {
    if (!mfaToken) return;
    setError(null);
    setSubmitting(true);
    try {
      await api("/api/auth/mfa/verify", { method: "POST", json: { challengeToken: mfaToken, code } });
      router.push(next);
      router.refresh();
    } catch (err) {
      setError(errorMessage(err));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Card>
      <CardContent className="space-y-5 p-6">
        <div>
          <h1 className="text-xl font-semibold">{mfaToken ? "Two-factor verification" : "Welcome back"}</h1>
          <p className="mt-1 text-sm text-muted">{mfaToken ? "Enter the 6-digit code from your authenticator app." : "Sign in to your arbitrage workspace."}</p>
        </div>
        {error && <InlineAlert tone="danger">{error}</InlineAlert>}

        {mfaToken ? (
          <form
            className="space-y-4"
            onSubmit={(e) => {
              e.preventDefault();
              void verifyMfa();
            }}
          >
            <Field label="Authenticator code" htmlFor="code">
              <Input id="code" inputMode="numeric" autoComplete="one-time-code" pattern="\d{6}" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} autoFocus className="text-center font-mono text-lg tracking-[0.4em]" />
            </Field>
            <Button type="submit" className="w-full" loading={submitting} disabled={code.length !== 6}>
              <KeyRound className="h-4 w-4" /> Verify and sign in
            </Button>
            <button type="button" onClick={() => setMfaToken(null)} className="w-full text-center text-xs text-muted hover:underline">
              Back to password sign-in
            </button>
          </form>
        ) : (
          <form className="space-y-4" onSubmit={onSubmit} noValidate>
            <Field label="E-mail" htmlFor="email" error={form.formState.errors.email?.message}>
              <Input id="email" type="email" autoComplete="email" inputMode="email" {...form.register("email")} />
            </Field>
            <Field label="Password" htmlFor="password" error={form.formState.errors.password?.message}>
              <Input id="password" type="password" autoComplete="current-password" {...form.register("password")} />
            </Field>
            <div className="flex items-center justify-between">
              <Checkbox checked={form.watch("remember")} onChange={(v) => form.setValue("remember", v)} label="Keep me signed in" />
              <Link href="/forgot-password" className="text-xs font-medium text-primary hover:underline">
                Forgot password?
              </Link>
            </div>
            <Button type="submit" className="w-full" loading={submitting}>
              Sign in
            </Button>
            {providers.data?.google && (
              <a href="/api/auth/google" className="flex h-10 w-full items-center justify-center gap-2 rounded-xl border border-border-strong text-sm font-medium hover:bg-surface-2">
                <svg className="h-4 w-4" viewBox="0 0 24 24" aria-hidden>
                  <path fill="#4285F4" d="M23.5 12.3c0-.8-.1-1.6-.2-2.3H12v4.5h6.5c-.3 1.5-1.1 2.8-2.4 3.6v3h3.9c2.3-2.1 3.5-5.2 3.5-8.8z" />
                  <path fill="#34A853" d="M12 24c3.2 0 6-1.1 8-2.9l-3.9-3c-1.1.7-2.5 1.2-4.1 1.2-3.1 0-5.8-2.1-6.7-5H1.3v3.1C3.3 21.3 7.3 24 12 24z" />
                  <path fill="#FBBC05" d="M5.3 14.3c-.2-.7-.4-1.5-.4-2.3s.1-1.6.4-2.3V6.6H1.3C.5 8.2 0 10 0 12s.5 3.8 1.3 5.4l4-3.1z" />
                  <path fill="#EA4335" d="M12 4.8c1.8 0 3.3.6 4.6 1.8l3.4-3.4C18 1.2 15.2 0 12 0 7.3 0 3.3 2.7 1.3 6.6l4 3.1c.9-2.9 3.6-4.9 6.7-4.9z" />
                </svg>
                Continue with Google
              </a>
            )}
            {providers.data?.demoMode && (
              <p className="rounded-lg bg-surface-2 p-2 text-center text-xs text-muted">
                Demo mode: try <span className="font-mono">demo@arbitragefinder.pro</span> / <span className="font-mono">Demo12345!</span>
              </p>
            )}
          </form>
        )}
        <p className="text-center text-sm text-muted">
          No account yet?{" "}
          <Link href="/register" className="font-medium text-primary hover:underline">
            Create one
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={null}>
      <LoginForm />
    </Suspense>
  );
}
