"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { CheckCircle2 } from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Button, LinkButton } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Checkbox, Field, Input } from "@/components/ui/input";
import { InlineAlert } from "@/components/ui/states";
import { api, errorMessage } from "@/lib/client/api";
import { registerSchema, type RegisterInput } from "@/lib/validation";

export default function RegisterPage() {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState<{ emailSent: boolean; devVerificationLink: string | null } | null>(null);
  const form = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: { displayName: "", email: "", password: "", acceptTerms: false },
  });
  const password = form.watch("password");
  const checks = [
    { ok: password.length >= 10, label: "10+ characters" },
    { ok: /[A-Za-z]/.test(password), label: "a letter" },
    { ok: /\d/.test(password), label: "a number" },
  ];

  const onSubmit = form.handleSubmit(async (values) => {
    setError(null);
    try {
      const res = await api<{ emailSent: boolean; devVerificationLink: string | null }>("/api/auth/register", { method: "POST", json: values });
      setDone(res);
      router.refresh();
    } catch (err) {
      setError(errorMessage(err));
    }
  });

  if (done) {
    return (
      <Card>
        <CardContent className="space-y-4 p-6 text-center">
          <CheckCircle2 className="mx-auto h-10 w-10 text-profit" />
          <h1 className="text-xl font-semibold">Account created</h1>
          {done.emailSent ? (
            <p className="text-sm text-muted">We sent a verification link to your inbox. Verify your e-mail to unlock alerts and account recovery.</p>
          ) : (
            <InlineAlert tone="info" className="text-left">
              E-mail delivery is not configured in this environment, so your verification link is shown here instead:
              {done.devVerificationLink && (
                <Link href={done.devVerificationLink} className="mt-1 block font-medium text-primary underline break-all">
                  Verify my e-mail now
                </Link>
              )}
            </InlineAlert>
          )}
          <LinkButton href="/app" className="w-full">
            Continue to dashboard
          </LinkButton>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="space-y-5 p-6">
        <div>
          <h1 className="text-xl font-semibold">Create your account</h1>
          <p className="mt-1 text-sm text-muted">Free plan included. No card required.</p>
        </div>
        {error && <InlineAlert tone="danger">{error}</InlineAlert>}
        <form className="space-y-4" onSubmit={onSubmit} noValidate>
          <Field label="Name" htmlFor="displayName" error={form.formState.errors.displayName?.message}>
            <Input id="displayName" autoComplete="name" {...form.register("displayName")} />
          </Field>
          <Field label="E-mail" htmlFor="email" error={form.formState.errors.email?.message}>
            <Input id="email" type="email" autoComplete="email" inputMode="email" {...form.register("email")} />
          </Field>
          <Field label="Password" htmlFor="password" error={form.formState.errors.password?.message}>
            <Input id="password" type="password" autoComplete="new-password" {...form.register("password")} />
            <ul className="mt-1.5 flex flex-wrap gap-x-3 gap-y-1 text-[11px]">
              {checks.map((c) => (
                <li key={c.label} className={c.ok ? "text-profit" : "text-muted"}>
                  {c.ok ? "✓" : "○"} {c.label}
                </li>
              ))}
            </ul>
          </Field>
          <Field error={form.formState.errors.acceptTerms?.message}>
            <Checkbox
              checked={form.watch("acceptTerms")}
              onChange={(v) => form.setValue("acceptTerms", v, { shouldValidate: form.formState.isSubmitted })}
              label={<span className="text-xs text-muted">I understand this is an analysis tool that does not guarantee profit, and I am legally allowed to use betting services in my jurisdiction.</span>}
            />
          </Field>
          <Button type="submit" className="w-full" loading={form.formState.isSubmitting}>
            Create account
          </Button>
        </form>
        <p className="text-center text-sm text-muted">
          Already registered?{" "}
          <Link href="/login" className="font-medium text-primary hover:underline">
            Sign in
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}
