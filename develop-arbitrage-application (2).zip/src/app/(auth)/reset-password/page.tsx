"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useForm } from "react-hook-form";
import { Button, LinkButton } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Field, Input } from "@/components/ui/input";
import { InlineAlert } from "@/components/ui/states";
import { api, errorMessage } from "@/lib/client/api";
import { resetPasswordSchema, type ResetPasswordInput } from "@/lib/validation";

function ResetForm() {
  const token = useSearchParams().get("token") ?? "";
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const form = useForm<ResetPasswordInput>({ resolver: zodResolver(resetPasswordSchema), defaultValues: { token, password: "", confirmPassword: "" } });

  const onSubmit = form.handleSubmit(async (values) => {
    setError(null);
    try {
      await api("/api/auth/reset-password", { method: "POST", json: values });
      setDone(true);
    } catch (err) {
      setError(errorMessage(err));
    }
  });

  return (
    <Card>
      <CardContent className="space-y-5 p-6">
        <div>
          <h1 className="text-xl font-semibold">Choose a new password</h1>
          <p className="mt-1 text-sm text-muted">All existing sessions will be signed out.</p>
        </div>
        {!token && <InlineAlert tone="danger">This link is missing its token. Request a new reset e-mail.</InlineAlert>}
        {error && <InlineAlert tone="danger">{error}</InlineAlert>}
        {done ? (
          <>
            <InlineAlert tone="success">Your password was updated. You can sign in now.</InlineAlert>
            <LinkButton href="/login" className="w-full">
              Go to sign in
            </LinkButton>
          </>
        ) : (
          <form className="space-y-4" onSubmit={onSubmit} noValidate>
            <input type="hidden" {...form.register("token")} />
            <Field label="New password" htmlFor="password" error={form.formState.errors.password?.message} hint="10+ characters with a letter and a number">
              <Input id="password" type="password" autoComplete="new-password" {...form.register("password")} />
            </Field>
            <Field label="Confirm password" htmlFor="confirmPassword" error={form.formState.errors.confirmPassword?.message}>
              <Input id="confirmPassword" type="password" autoComplete="new-password" {...form.register("confirmPassword")} />
            </Field>
            <Button type="submit" className="w-full" loading={form.formState.isSubmitting} disabled={!token}>
              Update password
            </Button>
          </form>
        )}
        <p className="text-center text-sm text-muted">
          <Link href="/forgot-password" className="font-medium text-primary hover:underline">
            Request a new link
          </Link>
        </p>
      </CardContent>
    </Card>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={null}>
      <ResetForm />
    </Suspense>
  );
}
