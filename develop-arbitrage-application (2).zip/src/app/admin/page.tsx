"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Activity, Bug, Flag, RefreshCw, ScrollText, Server, Users } from "lucide-react";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, PageHeader, StatCard } from "@/components/ui/card";
import { Input, Select, Switch } from "@/components/ui/input";
import { CardSkeleton, EmptyState, ErrorState, InlineAlert } from "@/components/ui/states";
import { Tabs } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage } from "@/lib/client/api";
import { useMe } from "@/lib/client/hooks";
import type { ProviderStatusDTO } from "@/lib/types";
import { formatDateTime, formatRelative } from "@/lib/utils";

type Tab = "overview" | "users" | "providers" | "flags" | "errors" | "audit";

interface Run {
  id: number;
  provider: string;
  trigger: string;
  status: string;
  startedAt: string;
  finishedAt: string | null;
  durationMs: number | null;
  eventsCount: number;
  opportunitiesCount: number;
  requestsUsed: number | null;
  requestsRemaining: number | null;
  error: string | null;
}
interface Overview {
  users: { total: number; admins: number; disabled: number; verified: number; last7d: number };
  opportunities: { active: number; expired: number };
  subscriptions: { premium: number; trials: number };
  errors: { last24h: number };
  provider: ProviderStatusDTO;
  apiCalls24h: number;
  recentRuns: Run[];
}
interface AdminUser {
  id: string;
  email: string;
  displayName: string;
  role: "user" | "admin";
  status: "active" | "disabled";
  emailVerified: boolean;
  mfaEnabled: boolean;
  plan: "free" | "premium";
  planStatus: string | null;
  planProvider: string | null;
  periodEnd: string | null;
  lastLoginAt: string | null;
  createdAt: string;
}

export default function AdminPage() {
  const [tab, setTab] = useState<Tab>("overview");
  return (
    <div className="space-y-4">
      <PageHeader title="Admin console" description="Role-based operations area: users, provider health, API usage, feature flags, errors and audit trail." />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { value: "overview", label: "Overview" },
          { value: "users", label: "Users" },
          { value: "providers", label: "Provider" },
          { value: "flags", label: "Flags" },
          { value: "errors", label: "Errors" },
          { value: "audit", label: "Audit log" },
        ]}
      />
      {tab === "overview" && <OverviewTab />}
      {tab === "users" && <UsersTab />}
      {tab === "providers" && <ProvidersTab />}
      {tab === "flags" && <FlagsTab />}
      {tab === "errors" && <ErrorsTab />}
      {tab === "audit" && <AuditTab />}
    </div>
  );
}

function RunsTable({ runs }: { runs: Run[] }) {
  if (!runs.length) return <p className="text-sm text-muted">No provider runs recorded yet.</p>;
  return (
    <div className="scrollbar-thin overflow-x-auto">
      <table className="w-full min-w-[680px] text-sm">
        <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
          <tr>
            <th className="px-3 py-2 text-left font-medium">Started</th>
            <th className="px-3 py-2 text-left font-medium">Trigger</th>
            <th className="px-3 py-2 text-left font-medium">Status</th>
            <th className="px-3 py-2 text-right font-medium">Events</th>
            <th className="px-3 py-2 text-right font-medium">Opps</th>
            <th className="px-3 py-2 text-right font-medium">Duration</th>
            <th className="px-3 py-2 text-right font-medium">Quota left</th>
          </tr>
        </thead>
        <tbody>
          {runs.map((r) => (
            <tr key={r.id} className="border-t border-border">
              <td className="px-3 py-2">{formatDateTime(r.startedAt)}</td>
              <td className="px-3 py-2">{r.trigger}</td>
              <td className="px-3 py-2">
                <Badge variant={r.status === "success" ? "profit" : r.status === "error" ? "danger" : "warning"}>{r.status}</Badge>
                {r.error && <p className="mt-1 max-w-xs truncate text-xs text-danger" title={r.error}>{r.error}</p>}
              </td>
              <td className="px-3 py-2 text-right tabular">{r.eventsCount}</td>
              <td className="px-3 py-2 text-right tabular">{r.opportunitiesCount}</td>
              <td className="px-3 py-2 text-right tabular">{r.durationMs !== null ? `${r.durationMs} ms` : "—"}</td>
              <td className="px-3 py-2 text-right tabular">{r.requestsRemaining ?? "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function OverviewTab() {
  const q = useQuery({ queryKey: ["admin", "overview"], queryFn: () => api<Overview>("/api/admin/overview"), refetchInterval: 60_000 });
  if (q.isError) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  if (!q.data) return <CardSkeleton rows={4} />;
  const d = q.data;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard label="Users" value={d.users.total} hint={`${d.users.last7d} new in 7d · ${d.users.verified} verified · ${d.users.admins} admins`} icon={<Users className="h-4 w-4" />} />
        <StatCard label="Premium" value={d.subscriptions.premium} hint={`${d.subscriptions.trials} on trial`} tone="profit" />
        <StatCard label="Opportunities" value={d.opportunities.active} hint={`${d.opportunities.expired} expired stored`} icon={<Activity className="h-4 w-4" />} />
        <StatCard label="Errors (24h)" value={d.errors.last24h} hint={`${d.apiCalls24h} provider runs in 24h`} tone={d.errors.last24h > 0 ? "warning" : "default"} icon={<Bug className="h-4 w-4" />} />
      </div>
      <Card>
        <CardHeader title={`Provider: ${d.provider.name}`} description={d.provider.isDemo ? "Demo provider — no external API usage." : `Interval ${d.provider.intervalSec}s`} action={<Badge variant={d.provider.stale ? "danger" : "profit"}>{d.provider.stale ? "Stale" : "Healthy"}</Badge>} />
        <CardContent>
          <RunsTable runs={d.recentRuns} />
        </CardContent>
      </Card>
    </div>
  );
}

function UsersTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe();
  const [q, setQ] = useState("");
  const users = useQuery({ queryKey: ["admin", "users", q], queryFn: () => api<{ items: AdminUser[] }>(`/api/admin/users?q=${encodeURIComponent(q)}`) });
  const patch = useMutation({
    mutationFn: (body: { userId: string; role?: string; status?: string; plan?: string; resetMfa?: boolean }) => api("/api/admin/users", { method: "PATCH", json: body }),
    onSuccess: () => {
      toast.success("User updated");
      void qc.invalidateQueries({ queryKey: ["admin", "users"] });
    },
    onError: (err) => toast.error("Update failed", errorMessage(err)),
  });
  return (
    <div className="space-y-3">
      <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search by e-mail or name" aria-label="Search users" className="max-w-sm" />
      <InlineAlert tone="info">Admins cannot change their own role or status. Role changes are recorded in the audit log.</InlineAlert>
      {users.isError ? (
        <ErrorState error={users.error} onRetry={() => users.refetch()} />
      ) : !users.data ? (
        <CardSkeleton rows={5} />
      ) : (
        <Card>
          <CardContent className="scrollbar-thin overflow-x-auto p-0">
            <table className="w-full min-w-[860px] text-sm">
              <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
                <tr>
                  <th className="px-3 py-2 text-left font-medium">User</th>
                  <th className="px-3 py-2 text-left font-medium">Role</th>
                  <th className="px-3 py-2 text-left font-medium">Status</th>
                  <th className="px-3 py-2 text-left font-medium">Plan</th>
                  <th className="px-3 py-2 text-left font-medium">Security</th>
                  <th className="px-3 py-2 text-left font-medium">Last login</th>
                </tr>
              </thead>
              <tbody>
                {users.data.items.map((u) => {
                  const self = u.id === me.data?.user.id;
                  return (
                    <tr key={u.id} className="border-t border-border">
                      <td className="px-3 py-2">
                        <p className="font-medium">{u.displayName}</p>
                        <p className="text-xs text-muted">{u.email}</p>
                      </td>
                      <td className="px-3 py-2">
                        <Select value={u.role} disabled={self} onChange={(e) => patch.mutate({ userId: u.id, role: e.target.value })} className="h-8 w-28 text-xs">
                          <option value="user">user</option>
                          <option value="admin">admin</option>
                        </Select>
                      </td>
                      <td className="px-3 py-2">
                        <Switch checked={u.status === "active"} disabled={self} onChange={(v) => patch.mutate({ userId: u.id, status: v ? "active" : "disabled" })} label={<span className="text-xs">{u.status}</span>} />
                      </td>
                      <td className="px-3 py-2">
                        <Select value={u.plan} onChange={(e) => patch.mutate({ userId: u.id, plan: e.target.value })} className="h-8 w-28 text-xs">
                          <option value="free">free</option>
                          <option value="premium">premium</option>
                        </Select>
                        {u.planStatus && <p className="mt-0.5 text-[11px] text-muted">{u.planStatus} · {u.planProvider}{u.periodEnd ? ` · ${formatRelative(u.periodEnd)}` : ""}</p>}
                      </td>
                      <td className="px-3 py-2 text-xs">
                        <div className="flex flex-wrap items-center gap-1">
                          <Badge variant={u.emailVerified ? "profit" : "warning"}>{u.emailVerified ? "verified" : "unverified"}</Badge>
                          <Badge variant={u.mfaEnabled ? "info" : "outline"}>{u.mfaEnabled ? "2FA" : "no 2FA"}</Badge>
                          {u.mfaEnabled && (
                            <Button variant="ghost" size="sm" onClick={() => patch.mutate({ userId: u.id, resetMfa: true })}>
                              Reset 2FA
                            </Button>
                          )}
                        </div>
                      </td>
                      <td className="px-3 py-2 text-xs text-muted">{u.lastLoginAt ? formatRelative(u.lastLoginAt) : "never"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function ProvidersTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({
    queryKey: ["admin", "providers"],
    queryFn: () =>
      api<{ status: ProviderStatusDTO; health: { ok: boolean; message: string; checkedAt: string }; config: { mode: string; sports: string[]; regions: string; markets: string; refreshIntervalSec: number; keyConfigured: boolean }; runs: Run[] }>("/api/admin/providers"),
  });
  const act = useMutation({
    mutationFn: (action: "force_sync" | "health") => api<{ result?: { error?: string; eventsCount: number; opportunitiesCount: number } }>("/api/admin/providers", { method: "POST", json: { action } }),
    onSuccess: (d, action) => {
      if (action === "force_sync") d.result?.error ? toast.error("Sync failed", d.result.error) : toast.success("Sync complete", `${d.result?.eventsCount} events · ${d.result?.opportunitiesCount} active opportunities`);
      else toast.success("Health check complete");
      void qc.invalidateQueries({ queryKey: ["admin"] });
      void qc.invalidateQueries({ queryKey: ["opportunities"] });
    },
    onError: (err) => toast.error("Action failed", errorMessage(err)),
  });
  if (q.isError) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  if (!q.data) return <CardSkeleton rows={4} />;
  const { status, health, config, runs } = q.data;
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader
          title={status.name}
          description={`Mode: ${config.mode} · key ${config.keyConfigured ? "configured" : "missing (demo fallback)"} · regions ${config.regions} · markets ${config.markets}`}
          action={
            <div className="flex gap-2">
              <Button variant="outline" size="sm" loading={act.isPending} onClick={() => act.mutate("health")}>
                <Server className="h-4 w-4" /> Health check
              </Button>
              <Button size="sm" loading={act.isPending} onClick={() => act.mutate("force_sync")}>
                <RefreshCw className="h-4 w-4" /> Force sync
              </Button>
            </div>
          }
        />
        <CardContent className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          <div>
            <p className="text-[11px] uppercase text-muted">Health</p>
            <p className={health.ok ? "text-profit" : "text-danger"}>{health.message}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase text-muted">Last success</p>
            <p>{status.lastSuccessAt ? formatRelative(status.lastSuccessAt) : "never"}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase text-muted">Quota</p>
            <p>{status.requestsRemaining !== null ? `${status.requestsRemaining} remaining · ${status.requestsUsed} used` : "n/a"}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase text-muted">Sports</p>
            <p className="truncate" title={config.sports.join(", ")}>{config.sports.join(", ")}</p>
          </div>
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Run history" description="Each run = one refresh cycle across configured sports. Errors back off automatically." />
        <CardContent>
          <RunsTable runs={runs} />
        </CardContent>
      </Card>
    </div>
  );
}

function FlagsTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["admin", "flags"], queryFn: () => api<{ items: { key: string; enabled: boolean; description: string; updatedAt: string }[] }>("/api/admin/flags") });
  const patch = useMutation({
    mutationFn: (body: { key: string; enabled: boolean }) => api("/api/admin/flags", { method: "PATCH", json: body }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin", "flags"] }),
    onError: (err) => toast.error("Could not update flag", errorMessage(err)),
  });
  if (q.isError) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  if (!q.data) return <CardSkeleton rows={4} />;
  return (
    <Card>
      <CardHeader title="Feature flags" description="Changes apply within 30 seconds (server-side cache)." action={<Flag className="h-4 w-4 text-muted" />} />
      <CardContent className="divide-y divide-border p-0">
        {q.data.items.map((f) => (
          <div key={f.key} className="flex items-center justify-between gap-4 px-4 py-3">
            <div>
              <p className="font-mono text-sm">{f.key}</p>
              <p className="text-xs text-muted">{f.description}</p>
            </div>
            <Switch checked={f.enabled} onChange={(v) => patch.mutate({ key: f.key, enabled: v })} />
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function ErrorsTab() {
  const qc = useQueryClient();
  const q = useQuery({ queryKey: ["admin", "errors"], queryFn: () => api<{ items: { id: number; level: string; message: string; path: string | null; context: Record<string, unknown>; createdAt: string }[] }>("/api/admin/errors") });
  const clear = useMutation({ mutationFn: () => api("/api/admin/errors", { method: "DELETE" }), onSuccess: () => void qc.invalidateQueries({ queryKey: ["admin", "errors"] }) });
  if (q.isError) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  if (!q.data) return <CardSkeleton rows={4} />;
  return (
    <Card>
      <CardHeader title="Error monitoring" description="Server-side errors with redacted context. Retained for 30 days." action={<Button variant="ghost" size="sm" onClick={() => clear.mutate()} disabled={!q.data.items.length}>Clear</Button>} />
      <CardContent className="p-0">
        {q.data.items.length === 0 ? (
          <div className="p-4">
            <EmptyState icon={<Bug className="h-6 w-6" />} title="No errors logged" description="Unhandled API errors and failed provider runs will appear here." />
          </div>
        ) : (
          <ul className="divide-y divide-border text-sm">
            {q.data.items.map((e) => (
              <li key={e.id} className="px-4 py-3">
                <div className="flex items-center justify-between gap-3">
                  <p className="font-medium text-danger">{e.message}</p>
                  <time className="shrink-0 text-xs text-muted">{formatDateTime(e.createdAt)}</time>
                </div>
                <p className="mt-0.5 font-mono text-xs text-muted">
                  {e.path ?? "—"} {Object.keys(e.context).length > 0 && JSON.stringify(e.context).slice(0, 200)}
                </p>
              </li>
            ))}
          </ul>
        )}
      </CardContent>
    </Card>
  );
}

function AuditTab() {
  const q = useQuery({ queryKey: ["admin", "audit"], queryFn: () => api<{ items: { id: number; action: string; actorEmail: string | null; targetType: string | null; targetId: string | null; metadata: Record<string, unknown>; ip: string | null; createdAt: string }[] }>("/api/admin/audit") });
  if (q.isError) return <ErrorState error={q.error} onRetry={() => q.refetch()} />;
  if (!q.data) return <CardSkeleton rows={4} />;
  return (
    <Card>
      <CardHeader title="Audit log" description="Security-relevant events: authentication, role and plan changes, flag updates." action={<ScrollText className="h-4 w-4 text-muted" />} />
      <CardContent className="scrollbar-thin overflow-x-auto p-0">
        <table className="w-full min-w-[720px] text-sm">
          <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
            <tr>
              <th className="px-3 py-2 text-left font-medium">When</th>
              <th className="px-3 py-2 text-left font-medium">Action</th>
              <th className="px-3 py-2 text-left font-medium">Actor</th>
              <th className="px-3 py-2 text-left font-medium">Target</th>
              <th className="px-3 py-2 text-left font-medium">Details</th>
            </tr>
          </thead>
          <tbody>
            {q.data.items.map((a) => (
              <tr key={a.id} className="border-t border-border">
                <td className="px-3 py-2 text-xs text-muted">{formatDateTime(a.createdAt)}</td>
                <td className="px-3 py-2 font-mono text-xs">{a.action}</td>
                <td className="px-3 py-2 text-xs">{a.actorEmail ?? "—"}</td>
                <td className="px-3 py-2 text-xs text-muted">{a.targetType ? `${a.targetType}:${a.targetId?.slice(0, 8)}` : "—"}</td>
                <td className="max-w-xs truncate px-3 py-2 font-mono text-[11px] text-muted" title={JSON.stringify(a.metadata)}>
                  {Object.keys(a.metadata).length ? JSON.stringify(a.metadata) : a.ip ?? ""}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </CardContent>
    </Card>
  );
}
