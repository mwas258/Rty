import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { trackActivity } from "@/lib/audit";
import { enforceRateLimit } from "@/lib/rate-limit";
import { activitySchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "activity", 60, 60_000, user.id);
  const input = await parseBody(req, activitySchema);
  await trackActivity(user.id, input.action, input.entityType ? { type: input.entityType, id: input.entityId ?? null } : undefined, input.metadata ?? {});
  return ok({ ok: true }, { status: 201 });
});
