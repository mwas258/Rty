import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { auditLogs, profiles } from "@/db/schema";
import { handle, ok, requireAdmin } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  await requireAdmin();
  const rows = await db
    .select({ log: auditLogs, actorEmail: profiles.email })
    .from(auditLogs)
    .leftJoin(profiles, eq(auditLogs.actorId, profiles.id))
    .orderBy(desc(auditLogs.createdAt))
    .limit(200);
  return ok({
    items: rows.map((r) => ({
      id: r.log.id,
      action: r.log.action,
      actorEmail: r.actorEmail,
      targetType: r.log.targetType,
      targetId: r.log.targetId,
      metadata: r.log.metadata,
      ip: r.log.ip,
      createdAt: r.log.createdAt.toISOString(),
    })),
  });
});
