import { desc } from "drizzle-orm";
import { db } from "@/db";
import { errorLogs } from "@/db/schema";
import { handle, ok, requireAdmin } from "@/lib/api";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  await requireAdmin();
  return ok({ items: await db.select().from(errorLogs).orderBy(desc(errorLogs.createdAt)).limit(100) });
});

export const DELETE = handle(async () => {
  await requireAdmin();
  await db.delete(errorLogs);
  return ok({ ok: true });
});
