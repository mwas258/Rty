import { asc } from "drizzle-orm";
import { db } from "@/db";
import { featureFlags } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireAdmin } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { DEFAULT_FLAGS, ensureDefaultFlags, setFlag } from "@/lib/flags";
import { flagPatchSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  await requireAdmin();
  await ensureDefaultFlags();
  return ok({ items: await db.select().from(featureFlags).orderBy(asc(featureFlags.key)) });
});

export const PATCH = handle(async (req) => {
  const admin = await requireAdmin();
  const input = await parseBody(req, flagPatchSchema);
  if (!DEFAULT_FLAGS.some((f) => f.key === input.key)) throw new HttpError(404, "Unknown flag.", "not_found");
  await setFlag(input.key, input.enabled);
  await recordAudit({ actorId: admin.id, action: "admin.flag_updated", targetType: "flag", targetId: input.key, metadata: { enabled: input.enabled } });
  return ok({ ok: true });
});
