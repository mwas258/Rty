import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { errorLogs, opportunities, profiles, providerRuns, subscriptions } from "@/db/schema";
import { handle, ok, requireAdmin } from "@/lib/api";
import { getOddsProvider } from "@/lib/providers";
import { getProviderStatus } from "@/lib/services/opportunities";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  await requireAdmin();
  const [[users], [opps], [subs], [errors], runs, provider] = await Promise.all([
    db
      .select({
        total: sql<number>`count(*)::int`,
        admins: sql<number>`count(*) filter (where ${profiles.role} = 'admin')::int`,
        disabled: sql<number>`count(*) filter (where ${profiles.status} = 'disabled')::int`,
        verified: sql<number>`count(*) filter (where ${profiles.emailVerifiedAt} is not null)::int`,
        last7d: sql<number>`count(*) filter (where ${profiles.createdAt} > now() - interval '7 days')::int`,
      })
      .from(profiles),
    db
      .select({
        active: sql<number>`count(*) filter (where ${opportunities.status} = 'active')::int`,
        expired: sql<number>`count(*) filter (where ${opportunities.status} = 'expired')::int`,
      })
      .from(opportunities),
    db
      .select({
        premium: sql<number>`count(*) filter (where ${subscriptions.status} in ('active','trialing') and ${subscriptions.plan} = 'premium')::int`,
        trials: sql<number>`count(*) filter (where ${subscriptions.status} = 'trialing')::int`,
      })
      .from(subscriptions),
    db.select({ last24h: sql<number>`count(*) filter (where ${errorLogs.createdAt} > now() - interval '24 hours')::int` }).from(errorLogs),
    db.select().from(providerRuns).orderBy(desc(providerRuns.startedAt)).limit(10),
    getProviderStatus(),
  ]);
  const [{ apiCalls24h }] = await db
    .select({ apiCalls24h: sql<number>`count(*) filter (where ${providerRuns.startedAt} > now() - interval '24 hours' and ${providerRuns.status} <> 'running')::int` })
    .from(providerRuns)
    .where(eq(providerRuns.provider, getOddsProvider().key));
  return ok({ users, opportunities: opps, subscriptions: subs, errors, provider, apiCalls24h, recentRuns: runs });
});
