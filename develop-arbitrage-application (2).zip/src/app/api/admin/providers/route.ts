import { desc } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { providerRuns } from "@/db/schema";
import { handle, ok, parseBody, requireAdmin } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { providerConfig } from "@/lib/env";
import { getOddsProvider } from "@/lib/providers";
import { getProviderStatus } from "@/lib/services/opportunities";
import { runSync } from "@/lib/services/sync";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  await requireAdmin();
  const provider = getOddsProvider();
  const cfg = providerConfig();
  const [runs, status, health] = await Promise.all([
    db.select().from(providerRuns).orderBy(desc(providerRuns.startedAt)).limit(40),
    getProviderStatus(),
    provider.health(),
  ]);
  return ok({
    status,
    health,
    config: { mode: cfg.mode, sports: provider.sportKeys, regions: cfg.regions, markets: cfg.markets, refreshIntervalSec: provider.refreshIntervalSec, keyConfigured: Boolean(cfg.apiKey) },
    runs,
  });
});

export const POST = handle(async (req) => {
  const admin = await requireAdmin();
  const { action } = await parseBody(req, z.object({ action: z.enum(["force_sync", "health"]) }));
  if (action === "force_sync") {
    const result = await runSync({ trigger: "admin", force: true });
    await recordAudit({ actorId: admin.id, action: "admin.force_sync", metadata: { result } });
    return ok({ result, status: await getProviderStatus() });
  }
  return ok({ health: await getOddsProvider().health() });
});
