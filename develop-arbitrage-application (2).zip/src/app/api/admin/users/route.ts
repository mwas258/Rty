import { and, desc, eq, ilike, inArray, or } from "drizzle-orm";
import { db } from "@/db";
import { profiles, subscriptions } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireAdmin } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { revokeUserSessions } from "@/lib/auth/session";
import { getClientIp } from "@/lib/rate-limit";
import { adminUserPatchSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async (req) => {
  await requireAdmin();
  const q = req.nextUrl.searchParams.get("q")?.trim();
  const rows = await db
    .select()
    .from(profiles)
    .where(q ? or(ilike(profiles.email, `%${q}%`), ilike(profiles.displayName, `%${q}%`)) : undefined)
    .orderBy(desc(profiles.createdAt))
    .limit(200);
  const subs = rows.length
    ? await db
        .select()
        .from(subscriptions)
        .where(and(inArray(subscriptions.userId, rows.map((r) => r.id)), inArray(subscriptions.status, ["active", "trialing"])))
    : [];
  const planByUser = new Map(subs.filter((s) => s.plan === "premium").map((s) => [s.userId, s]));
  return ok({
    items: rows.map((u) => {
      const sub = planByUser.get(u.id);
      return {
        id: u.id,
        email: u.email,
        displayName: u.displayName,
        role: u.role,
        status: u.status,
        emailVerified: Boolean(u.emailVerifiedAt),
        mfaEnabled: u.mfaEnabled,
        plan: sub ? "premium" : "free",
        planStatus: sub?.status ?? null,
        planProvider: sub?.provider ?? null,
        periodEnd: sub?.currentPeriodEnd?.toISOString() ?? null,
        lastLoginAt: u.lastLoginAt?.toISOString() ?? null,
        createdAt: u.createdAt.toISOString(),
      };
    }),
  });
});

export const PATCH = handle(async (req) => {
  const admin = await requireAdmin();
  const input = await parseBody(req, adminUserPatchSchema);
  const [target] = await db.select().from(profiles).where(eq(profiles.id, input.userId)).limit(1);
  if (!target) throw new HttpError(404, "User not found.", "not_found");
  if (input.userId === admin.id && (input.role || input.status)) {
    throw new HttpError(400, "You cannot change your own role or status.", "self_modification");
  }
  const ip = getClientIp(req);
  const changes: Record<string, unknown> = {};

  if (input.role && input.role !== target.role) {
    await db.update(profiles).set({ role: input.role, updatedAt: new Date() }).where(eq(profiles.id, target.id));
    changes.role = input.role;
  }
  if (input.status && input.status !== target.status) {
    await db.update(profiles).set({ status: input.status, updatedAt: new Date() }).where(eq(profiles.id, target.id));
    if (input.status === "disabled") await revokeUserSessions(target.id);
    changes.status = input.status;
  }
  if (input.resetMfa) {
    await db.update(profiles).set({ mfaEnabled: false, mfaSecretEnc: null, mfaPendingSecretEnc: null, updatedAt: new Date() }).where(eq(profiles.id, target.id));
    changes.resetMfa = true;
  }
  if (input.plan) {
    await db
      .update(subscriptions)
      .set({ status: "canceled", updatedAt: new Date() })
      .where(and(eq(subscriptions.userId, target.id), inArray(subscriptions.status, ["active", "trialing"])));
    if (input.plan === "premium") {
      await db.insert(subscriptions).values({
        userId: target.id,
        plan: "premium",
        status: "active",
        provider: "manual",
        currentPeriodEnd: new Date(Date.now() + 365 * 86_400_000),
      });
    }
    changes.plan = input.plan;
  }
  await recordAudit({ actorId: admin.id, action: "admin.user_updated", targetType: "user", targetId: target.id, metadata: changes, ip });
  return ok({ ok: true, changes });
});
