import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { alertRules } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { getEntitlements } from "@/lib/entitlements";
import { toAlertRuleDTO } from "@/lib/services/users";
import { alertRuleSchema } from "@/lib/validation";

export const PATCH = handle(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const input = await parseBody(req, alertRuleSchema.partial());
  const entitlements = await getEntitlements(user);
  const update = { ...input };
  if (update.channels && !entitlements.limits.externalChannels) update.channels = ["in_app"];
  const [rule] = await db
    .update(alertRules)
    .set(update)
    .where(and(eq(alertRules.id, id), eq(alertRules.userId, user.id)))
    .returning();
  if (!rule) throw new HttpError(404, "Alert rule not found.", "not_found");
  return ok(toAlertRuleDTO(rule));
});

export const DELETE = handle(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  await db.delete(alertRules).where(and(eq(alertRules.id, id), eq(alertRules.userId, user.id)));
  return ok({ ok: true });
});
