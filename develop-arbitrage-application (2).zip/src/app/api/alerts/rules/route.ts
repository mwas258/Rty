import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { alertRules } from "@/db/schema";
import { handle, ok, parseBody, requireUser, requireVerified } from "@/lib/api";
import { trackActivity } from "@/lib/audit";
import { assertWithinLimit, getEntitlements } from "@/lib/entitlements";
import { toAlertRuleDTO } from "@/lib/services/users";
import { alertRuleSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const [rows, entitlements] = await Promise.all([
    db.select().from(alertRules).where(eq(alertRules.userId, user.id)).orderBy(asc(alertRules.createdAt)),
    getEntitlements(user),
  ]);
  return ok({ items: rows.map(toAlertRuleDTO), limit: entitlements.limits.maxAlertRules, externalChannels: entitlements.limits.externalChannels });
});

export const POST = handle(async (req) => {
  const user = await requireUser();
  requireVerified(user);
  const input = await parseBody(req, alertRuleSchema);
  const entitlements = await getEntitlements(user);
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(alertRules).where(eq(alertRules.userId, user.id));
  assertWithinLimit(count, entitlements.limits.maxAlertRules, "alert rules");
  const channels = entitlements.limits.externalChannels ? input.channels : ["in_app"];
  const [rule] = await db
    .insert(alertRules)
    .values({ ...input, channels: channels.includes("in_app") ? channels : ["in_app", ...channels], userId: user.id })
    .returning();
  void trackActivity(user.id, "alert_rule_created", { type: "alert_rule", id: rule.id }, { name: rule.name });
  return ok(toAlertRuleDTO(rule), { status: 201 });
});
