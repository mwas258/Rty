import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { hashPassword, verifyPassword } from "@/lib/auth/password";
import { revokeUserSessions } from "@/lib/auth/session";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { changePasswordSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "change-password", 5, 15 * 60_000, user.id);
  const input = await parseBody(req, changePasswordSchema);
  const [row] = await db.select({ hash: profiles.passwordHash }).from(profiles).where(eq(profiles.id, user.id)).limit(1);
  if (row?.hash && !(await verifyPassword(input.currentPassword, row.hash))) {
    throw new HttpError(400, "Your current password is incorrect.", "invalid_password");
  }
  await db.update(profiles).set({ passwordHash: await hashPassword(input.newPassword), updatedAt: new Date() }).where(eq(profiles.id, user.id));
  await revokeUserSessions(user.id, user.sessionId);
  await recordAudit({ actorId: user.id, action: "auth.password_changed", ip: getClientIp(req) });
  return ok({ ok: true });
});
