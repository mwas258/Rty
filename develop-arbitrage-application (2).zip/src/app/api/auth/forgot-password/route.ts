import { sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, ok, parseBody } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { issueToken } from "@/lib/auth/tokens";
import { sendEmail } from "@/lib/email";
import { appUrl, isEmailConfigured } from "@/lib/env";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { forgotPasswordSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  enforceRateLimit(req, "forgot-password", 5, 15 * 60_000);
  const { email } = await parseBody(req, forgotPasswordSchema);
  const [user] = await db
    .select()
    .from(profiles)
    .where(sql`lower(${profiles.email}) = ${email}`)
    .limit(1);

  let devResetLink: string | null = null;
  if (user && user.status === "active") {
    const token = await issueToken(user.id, "reset_password");
    const link = `${appUrl()}/reset-password?token=${token}`;
    const sent = await sendEmail({
      to: user.email,
      subject: "Reset your Arbitrage Finder Pro password",
      text: `We received a request to reset your password. Open this link within 1 hour to choose a new one:\n${link}\n\nIf you did not request this, ignore this e-mail.`,
    });
    if (!sent.delivered && !isEmailConfigured()) devResetLink = link;
    await recordAudit({ actorId: user.id, action: "auth.password_reset_requested", ip: getClientIp(req) });
  }
  // Always respond the same way so e-mail addresses cannot be enumerated.
  return ok({ ok: true, devResetLink });
});
