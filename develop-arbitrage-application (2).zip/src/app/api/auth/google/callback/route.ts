import { eq, sql } from "drizzle-orm";
import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { profiles, userPreferences } from "@/db/schema";
import { handle } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { loginUser } from "@/lib/auth/session";
import { issueToken } from "@/lib/auth/tokens";
import { appUrl, isGoogleConfigured } from "@/lib/env";
import { logError } from "@/lib/logger";
import { getClientIp } from "@/lib/rate-limit";

export const GET = handle(async (req) => {
  const fail = (code: string) => NextResponse.redirect(new URL(`/login?error=${code}`, req.url));
  if (!isGoogleConfigured()) return fail("oauth_not_configured");

  const code = req.nextUrl.searchParams.get("code");
  const state = req.nextUrl.searchParams.get("state");
  const jar = await cookies();
  const expected = jar.get("afp_oauth_state")?.value;
  jar.delete("afp_oauth_state");
  if (!code || !state || !expected || state !== expected) return fail("oauth_state");

  try {
    const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID as string,
        client_secret: process.env.GOOGLE_CLIENT_SECRET as string,
        redirect_uri: `${appUrl()}/api/auth/google/callback`,
        grant_type: "authorization_code",
      }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!tokenRes.ok) return fail("oauth_token");
    const tokens = (await tokenRes.json()) as { access_token?: string };
    if (!tokens.access_token) return fail("oauth_token");

    const infoRes = await fetch("https://openidconnect.googleapis.com/v1/userinfo", {
      headers: { Authorization: `Bearer ${tokens.access_token}` },
      signal: AbortSignal.timeout(10_000),
    });
    if (!infoRes.ok) return fail("oauth_profile");
    const info = (await infoRes.json()) as { sub: string; email?: string; email_verified?: boolean; name?: string; picture?: string };
    if (!info.email || !info.email_verified) return fail("oauth_email");

    const email = info.email.toLowerCase();
    let [user] = await db.select().from(profiles).where(eq(profiles.googleId, info.sub)).limit(1);
    if (!user) {
      const [byEmail] = await db
        .select()
        .from(profiles)
        .where(sql`lower(${profiles.email}) = ${email}`)
        .limit(1);
      if (byEmail) {
        [user] = await db
          .update(profiles)
          .set({ googleId: info.sub, emailVerifiedAt: byEmail.emailVerifiedAt ?? new Date(), avatarUrl: byEmail.avatarUrl ?? info.picture ?? null, updatedAt: new Date() })
          .where(eq(profiles.id, byEmail.id))
          .returning();
      } else {
        [user] = await db
          .insert(profiles)
          .values({ email, displayName: info.name || email.split("@")[0], googleId: info.sub, avatarUrl: info.picture ?? null, emailVerifiedAt: new Date() })
          .returning();
        await db.insert(userPreferences).values({ userId: user.id }).onConflictDoNothing();
        await recordAudit({ actorId: user.id, action: "auth.register_google", ip: getClientIp(req) });
      }
    }
    if (user.status !== "active") return fail("account_disabled");

    if (user.mfaEnabled && user.mfaSecretEnc) {
      const challenge = await issueToken(user.id, "mfa_challenge");
      return NextResponse.redirect(new URL(`/login?mfa=${encodeURIComponent(challenge)}`, req.url));
    }
    await loginUser(user.id, { userAgent: req.headers.get("user-agent"), ip: getClientIp(req), remember: true });
    await recordAudit({ actorId: user.id, action: "auth.login_google", ip: getClientIp(req) });
    return NextResponse.redirect(new URL("/app", req.url));
  } catch (err) {
    await logError("Google OAuth callback failed", err);
    return fail("oauth_failed");
  }
});
