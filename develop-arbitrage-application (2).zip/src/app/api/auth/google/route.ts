import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { handle, HttpError } from "@/lib/api";
import { randomToken } from "@/lib/auth/crypto";
import { appUrl, isGoogleConfigured } from "@/lib/env";

/** Start Google OAuth (only available when GOOGLE_CLIENT_ID/SECRET are configured). */
export const GET = handle(async () => {
  if (!isGoogleConfigured()) throw new HttpError(404, "Google sign-in is not configured.", "not_configured");
  const state = randomToken(16);
  const jar = await cookies();
  jar.set("afp_oauth_state", state, { httpOnly: true, sameSite: "lax", secure: appUrl().startsWith("https://"), path: "/", maxAge: 600 });
  const url = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  url.searchParams.set("client_id", process.env.GOOGLE_CLIENT_ID as string);
  url.searchParams.set("redirect_uri", `${appUrl()}/api/auth/google/callback`);
  url.searchParams.set("response_type", "code");
  url.searchParams.set("scope", "openid email profile");
  url.searchParams.set("state", state);
  url.searchParams.set("prompt", "select_account");
  return NextResponse.redirect(url);
});
