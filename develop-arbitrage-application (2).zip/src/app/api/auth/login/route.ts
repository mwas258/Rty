import { sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { verifyPassword } from "@/lib/auth/password";
import { loginUser, toAuthUser, toUserDTO } from "@/lib/auth/session";
import { issueToken } from "@/lib/auth/tokens";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { loginSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  enforceRateLimit(req, "login", 15, 15 * 60_000);
  const input = await parseBody(req, loginSchema);
  enforceRateLimit(req, "login-account", 8, 15 * 60_000, input.email);
  const ip = getClientIp(req);

  const [user] = await db
    .select()
    .from(profiles)
    .where(sql`lower(${profiles.email}) = ${input.email}`)
    .limit(1);
  const valid = await verifyPassword(input.password, user?.passwordHash);
  if (!user || !valid) {
    await recordAudit({ actorId: user?.id ?? null, action: "auth.login_failed", ip, metadata: { reason: user ? "bad_password" : "unknown_email" } });
    throw new HttpError(401, "Invalid e-mail or password.", "invalid_credentials");
  }
  if (user.status !== "active") throw new HttpError(403, "This account has been disabled. Contact support.", "account_disabled");

  if (user.mfaEnabled && user.mfaSecretEnc) {
    const challengeToken = await issueToken(user.id, "mfa_challenge");
    return ok({ mfaRequired: true, challengeToken });
  }

  await loginUser(user.id, { userAgent: req.headers.get("user-agent"), ip, remember: input.remember });
  await recordAudit({ actorId: user.id, action: "auth.login", ip });
  return ok({ mfaRequired: false, user: toUserDTO(toAuthUser(user, "")) });
});
