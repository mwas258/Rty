import { handle, ok } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { destroyCurrentSession, getSessionUser } from "@/lib/auth/session";
import { getClientIp } from "@/lib/rate-limit";

export const POST = handle(async (req) => {
  const user = await getSessionUser();
  await destroyCurrentSession();
  if (user) await recordAudit({ actorId: user.id, action: "auth.logout", ip: getClientIp(req) });
  return ok({ ok: true });
});
