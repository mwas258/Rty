import { handle, ok, requireUser } from "@/lib/api";
import { toUserDTO } from "@/lib/auth/session";
import { getEntitlements } from "@/lib/entitlements";
import { countUnread, getAppConfig, getOrCreatePreferences, toPreferencesDTO } from "@/lib/services/users";
import type { MeResponse } from "@/lib/types";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const [prefs, entitlements, config, unreadNotifications] = await Promise.all([
    getOrCreatePreferences(user.id),
    getEntitlements(user),
    getAppConfig(),
    countUnread(user.id),
  ]);
  const body: MeResponse = { user: toUserDTO(user), preferences: toPreferencesDTO(prefs), entitlements, config, unreadNotifications };
  return ok(body);
});
