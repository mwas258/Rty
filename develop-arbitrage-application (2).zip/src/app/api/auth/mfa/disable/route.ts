import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { decryptSecret } from "@/lib/auth/crypto";
import { verifyPassword } from "@/lib/auth/password";
import { verifyTotp } from "@/lib/auth/totp";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { mfaDisableSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "mfa-disable", 5, 15 * 60_000, user.id);
  const { password, code } = await parseBody(req, mfaDisableSchema);
  const [row] = await db.select({ hash: profiles.passwordHash, secret: profiles.mfaSecretEnc }).from(profiles).where(eq(profiles.id, user.id)).limit(1);
  if (!row?.secret) throw new HttpError(400, "Two-factor authentication is not enabled.", "mfa_disabled");
  if (row.hash && !(await verifyPassword(password, row.hash))) throw new HttpError(400, "Incorrect password.", "invalid_password");
  if (!verifyTotp(decryptSecret(row.secret), code)) throw new HttpError(400, "Invalid authenticator code.", "invalid_code");
  await db.update(profiles).set({ mfaEnabled: false, mfaSecretEnc: null, mfaPendingSecretEnc: null, updatedAt: new Date() }).where(eq(profiles.id, user.id));
  await recordAudit({ actorId: user.id, action: "auth.mfa_disabled", ip: getClientIp(req) });
  return ok({ ok: true });
});
