import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { decryptSecret } from "@/lib/auth/crypto";
import { verifyTotp } from "@/lib/auth/totp";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { mfaCodeSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "mfa-enable", 10, 15 * 60_000, user.id);
  const { code } = await parseBody(req, mfaCodeSchema);
  const [row] = await db.select({ pending: profiles.mfaPendingSecretEnc }).from(profiles).where(eq(profiles.id, user.id)).limit(1);
  if (!row?.pending) throw new HttpError(400, "Start the setup first.", "mfa_not_started");
  const secret = decryptSecret(row.pending);
  if (!verifyTotp(secret, code)) throw new HttpError(400, "That code is not valid. Check your authenticator app and try again.", "invalid_code");
  await db
    .update(profiles)
    .set({ mfaEnabled: true, mfaSecretEnc: row.pending, mfaPendingSecretEnc: null, updatedAt: new Date() })
    .where(eq(profiles.id, user.id));
  await recordAudit({ actorId: user.id, action: "auth.mfa_enabled", ip: getClientIp(req) });
  return ok({ ok: true });
});
