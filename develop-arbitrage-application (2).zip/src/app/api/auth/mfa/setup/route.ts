import { eq } from "drizzle-orm";
import QRCode from "qrcode";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, requireUser } from "@/lib/api";
import { encryptSecret } from "@/lib/auth/crypto";
import { generateTotpSecret, otpauthUrl } from "@/lib/auth/totp";
import { enforceRateLimit } from "@/lib/rate-limit";

/** Begin TOTP enrolment: returns a fresh secret (also stored encrypted as "pending"). */
export const POST = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "mfa-setup", 5, 15 * 60_000, user.id);
  if (user.mfaEnabled) throw new HttpError(400, "Two-factor authentication is already enabled.", "mfa_enabled");
  const secret = generateTotpSecret();
  await db.update(profiles).set({ mfaPendingSecretEnc: encryptSecret(secret), updatedAt: new Date() }).where(eq(profiles.id, user.id));
  const url = otpauthUrl(secret, user.email);
  const qrDataUrl = await QRCode.toDataURL(url, { margin: 1, width: 220 });
  return ok({ secret, otpauthUrl: url, qrDataUrl });
});
