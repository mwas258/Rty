import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { decryptSecret } from "@/lib/auth/crypto";
import { loginUser, toAuthUser, toUserDTO } from "@/lib/auth/session";
import { bumpTokenAttempts, consumeToken, findValidToken } from "@/lib/auth/tokens";
import { verifyTotp } from "@/lib/auth/totp";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { mfaVerifySchema } from "@/lib/validation";

/** Second step of login for accounts with TOTP enabled. */
export const POST = handle(async (req) => {
  enforceRateLimit(req, "mfa-verify", 15, 15 * 60_000);
  const { challengeToken, code } = await parseBody(req, mfaVerifySchema);
  const challenge = await findValidToken(challengeToken, "mfa_challenge");
  if (!challenge) throw new HttpError(401, "Your sign-in challenge expired. Please sign in again.", "challenge_expired");
  if (challenge.attempts >= 5) throw new HttpError(429, "Too many invalid codes. Please sign in again.", "too_many_attempts");

  const [user] = await db.select().from(profiles).where(eq(profiles.id, challenge.userId)).limit(1);
  if (!user?.mfaSecretEnc || !verifyTotp(decryptSecret(user.mfaSecretEnc), code)) {
    await bumpTokenAttempts(challenge.id);
    throw new HttpError(401, "Invalid authenticator code.", "invalid_code");
  }
  await consumeToken(challengeToken, "mfa_challenge");
  const ip = getClientIp(req);
  await loginUser(user.id, { userAgent: req.headers.get("user-agent"), ip, remember: true });
  await recordAudit({ actorId: user.id, action: "auth.login_mfa", ip });
  return ok({ user: toUserDTO(toAuthUser(user, "")) });
});
