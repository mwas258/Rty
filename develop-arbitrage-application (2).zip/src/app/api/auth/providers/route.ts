import { handle, ok } from "@/lib/api";
import { getFlag } from "@/lib/flags";
import { getAppConfig } from "@/lib/services/users";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const config = await getAppConfig();
  return ok({ google: config.google, emailDelivery: config.emailDelivery, demoMode: config.demoMode, signupEnabled: await getFlag("signup.enabled", true) });
});
