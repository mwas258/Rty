import { sql } from "drizzle-orm";
import { db } from "@/db";
import { profiles, userPreferences } from "@/db/schema";
import { handle, HttpError, ok, parseBody } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { hashPassword } from "@/lib/auth/password";
import { loginUser, toAuthUser, toUserDTO } from "@/lib/auth/session";
import { issueToken } from "@/lib/auth/tokens";
import { sendEmail } from "@/lib/email";
import { appUrl, isEmailConfigured } from "@/lib/env";
import { getFlag } from "@/lib/flags";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { registerSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  enforceRateLimit(req, "register", 5, 15 * 60_000);
  if (!(await getFlag("signup.enabled", true))) throw new HttpError(403, "Registrations are currently closed.", "signup_disabled");
  const input = await parseBody(req, registerSchema);

  const [existing] = await db
    .select({ id: profiles.id })
    .from(profiles)
    .where(sql`lower(${profiles.email}) = ${input.email}`)
    .limit(1);
  if (existing) throw new HttpError(409, "An account with this e-mail already exists.", "email_taken");

  const [user] = await db
    .insert(profiles)
    .values({ email: input.email, passwordHash: await hashPassword(input.password), displayName: input.displayName })
    .returning();
  await db.insert(userPreferences).values({ userId: user.id }).onConflictDoNothing();

  const token = await issueToken(user.id, "verify_email");
  const link = `${appUrl()}/verify-email?token=${token}`;
  const sent = await sendEmail({
    to: user.email,
    subject: "Verify your Arbitrage Finder Pro e-mail",
    text: `Welcome to Arbitrage Finder Pro!\n\nConfirm your e-mail address by opening this link (valid for 24 hours):\n${link}\n\nIf you did not create an account you can ignore this message.`,
  });

  const ip = getClientIp(req);
  await loginUser(user.id, { userAgent: req.headers.get("user-agent"), ip, remember: true });
  await recordAudit({ actorId: user.id, action: "auth.register", targetType: "user", targetId: user.id, ip });

  return ok(
    {
      user: toUserDTO(toAuthUser(user, "")),
      emailSent: sent.delivered,
      // Demo convenience only: when no e-mail provider is configured the link is returned to the caller.
      devVerificationLink: !isEmailConfigured() ? link : null,
    },
    { status: 201 },
  );
});
