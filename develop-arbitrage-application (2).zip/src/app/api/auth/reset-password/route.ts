import { eq } from "drizzle-orm";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { hashPassword } from "@/lib/auth/password";
import { revokeUserSessions } from "@/lib/auth/session";
import { consumeToken } from "@/lib/auth/tokens";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";
import { resetPasswordSchema } from "@/lib/validation";

export const POST = handle(async (req) => {
  enforceRateLimit(req, "reset-password", 10, 15 * 60_000);
  const input = await parseBody(req, resetPasswordSchema);
  const userId = await consumeToken(input.token, "reset_password");
  if (!userId) throw new HttpError(400, "This reset link is invalid or has expired. Request a new one.", "invalid_token");
  await db.update(profiles).set({ passwordHash: await hashPassword(input.password), updatedAt: new Date() }).where(eq(profiles.id, userId));
  await revokeUserSessions(userId);
  await recordAudit({ actorId: userId, action: "auth.password_reset", ip: getClientIp(req) });
  return ok({ ok: true });
});
