import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { sessions } from "@/db/schema";
import { handle, HttpError, ok, requireUser } from "@/lib/api";
import { recordAudit } from "@/lib/audit";

export const DELETE = handle(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  if (id === user.sessionId) throw new HttpError(400, "Use sign out to end the current session.", "current_session");
  await db.delete(sessions).where(and(eq(sessions.id, id), eq(sessions.userId, user.id)));
  await recordAudit({ actorId: user.id, action: "auth.session_revoked", targetType: "session", targetId: id });
  return ok({ ok: true });
});
