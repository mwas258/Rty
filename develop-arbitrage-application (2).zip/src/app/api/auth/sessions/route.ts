import { handle, ok, requireUser } from "@/lib/api";
import { listUserSessions } from "@/lib/auth/session";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  return ok({ sessions: await listUserSessions(user.id, user.sessionId) });
});
