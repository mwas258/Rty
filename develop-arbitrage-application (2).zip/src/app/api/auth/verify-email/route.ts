import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { consumeToken, issueToken } from "@/lib/auth/tokens";
import { sendEmail } from "@/lib/email";
import { appUrl, isEmailConfigured } from "@/lib/env";
import { enforceRateLimit, getClientIp } from "@/lib/rate-limit";

export const POST = handle(async (req) => {
  enforceRateLimit(req, "verify-email", 10, 15 * 60_000);
  const { token } = await parseBody(req, z.object({ token: z.string().min(10) }));
  const userId = await consumeToken(token, "verify_email");
  if (!userId) throw new HttpError(400, "This verification link is invalid or has expired.", "invalid_token");
  await db.update(profiles).set({ emailVerifiedAt: new Date(), updatedAt: new Date() }).where(eq(profiles.id, userId));
  await recordAudit({ actorId: userId, action: "auth.email_verified", ip: getClientIp(req) });
  return ok({ ok: true });
});

/** Resend the verification e-mail for the signed-in user. */
export const PUT = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "resend-verification", 3, 15 * 60_000, user.id);
  if (user.emailVerified) return ok({ ok: true, alreadyVerified: true });
  const token = await issueToken(user.id, "verify_email");
  const link = `${appUrl()}/verify-email?token=${token}`;
  const sent = await sendEmail({ to: user.email, subject: "Verify your Arbitrage Finder Pro e-mail", text: `Confirm your e-mail address:\n${link}` });
  return ok({ ok: true, emailSent: sent.delivered, devVerificationLink: !isEmailConfigured() ? link : null });
});
