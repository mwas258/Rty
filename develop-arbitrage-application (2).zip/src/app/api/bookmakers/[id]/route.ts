import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookmakers, userBookmakers } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { trackActivity } from "@/lib/audit";
import { bookmakerAvailabilitySchema } from "@/lib/validation";

export const PATCH = handle(async (req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  const bookmakerId = Number(id);
  if (!Number.isInteger(bookmakerId)) throw new HttpError(404, "Bookmaker not found.", "not_found");
  const [book] = await db.select().from(bookmakers).where(eq(bookmakers.id, bookmakerId)).limit(1);
  if (!book) throw new HttpError(404, "Bookmaker not found.", "not_found");
  const input = await parseBody(req, bookmakerAvailabilitySchema);
  await db
    .insert(userBookmakers)
    .values({ userId: user.id, bookmakerId, available: input.available, notes: input.notes ?? null })
    .onConflictDoUpdate({
      target: [userBookmakers.userId, userBookmakers.bookmakerId],
      set: { available: input.available, notes: input.notes ?? null, updatedAt: new Date() },
    });
  void trackActivity(user.id, input.available ? "bookmaker_enabled" : "bookmaker_disabled", { type: "bookmaker", id: book.key }, { name: book.name });
  return ok({ ok: true });
});
