import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookmakers, opportunities, userBookmakers } from "@/db/schema";
import { handle, ok, requireUser } from "@/lib/api";
import type { BookmakerDTO } from "@/lib/types";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const rows = await db
    .select({ book: bookmakers, available: userBookmakers.available, notes: userBookmakers.notes })
    .from(bookmakers)
    .leftJoin(userBookmakers, and(eq(userBookmakers.bookmakerId, bookmakers.id), eq(userBookmakers.userId, user.id)))
    .orderBy(asc(bookmakers.name));
  const active = await db.select({ legs: opportunities.legs }).from(opportunities).where(eq(opportunities.status, "active"));
  const counts = new Map<string, number>();
  for (const o of active) for (const leg of o.legs) counts.set(leg.bookmakerKey, (counts.get(leg.bookmakerKey) ?? 0) + 1);

  const items: BookmakerDTO[] = rows.map((r) => ({
    id: r.book.id,
    key: r.book.key,
    name: r.book.name,
    country: r.book.country,
    currency: r.book.currency,
    website: r.book.website,
    supportedMarkets: r.book.supportedMarkets,
    isExchange: r.book.isExchange,
    commissionPct: r.book.commissionPct,
    active: r.book.active,
    available: r.available ?? null,
    notes: r.notes ?? null,
    activeOpportunities: counts.get(r.book.key) ?? 0,
  }));
  const [{ saved }] = await db
    .select({ saved: sql<number>`count(*)::int` })
    .from(userBookmakers)
    .where(and(eq(userBookmakers.userId, user.id), eq(userBookmakers.available, true)));
  return ok({ items, saved });
});
