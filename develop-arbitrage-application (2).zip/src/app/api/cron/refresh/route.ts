import { timingSafeEqual } from "node:crypto";
import { handle, HttpError, ok } from "@/lib/api";
import { cronSecret } from "@/lib/env";
import { runSync, maybeRunRetention } from "@/lib/services/sync";

/** External scheduler endpoint. Protect with CRON_SECRET (Authorization: Bearer <secret>). */
export const POST = handle(async (req) => {
  const secret = cronSecret();
  if (!secret) throw new HttpError(503, "CRON_SECRET is not configured.", "not_configured");
  const provided = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  const a = Buffer.from(provided);
  const b = Buffer.from(secret);
  if (a.length !== b.length || !timingSafeEqual(a, b)) throw new HttpError(401, "Unauthorized", "unauthorized");
  const result = await runSync({ trigger: "cron" });
  await maybeRunRetention();
  return ok(result);
});

export const GET = POST;
