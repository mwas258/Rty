import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { events, opportunities, watchlist } from "@/db/schema";
import { handle, HttpError, requireUser } from "@/lib/api";
import { trackActivity } from "@/lib/audit";
import { assertFeature, getEntitlements } from "@/lib/entitlements";
import { toCsv } from "@/lib/utils";

export const dynamic = "force-dynamic";

/** CSV export (Premium). ?type=history | watchlist */
export const GET = handle(async (req) => {
  const user = await requireUser();
  const entitlements = await getEntitlements(user);
  assertFeature(entitlements.limits.csvExport, "CSV export");
  const type = req.nextUrl.searchParams.get("type") ?? "history";
  if (type !== "history" && type !== "watchlist") throw new HttpError(400, "Unknown export type.", "bad_request");

  const base = db
    .select({ opp: opportunities, ev: events })
    .from(opportunities)
    .innerJoin(events, eq(opportunities.eventId, events.id));
  const rows =
    type === "history"
      ? await base
          .where(and(eq(opportunities.status, "expired"), gte(opportunities.expiredAt, new Date(Date.now() - entitlements.limits.historyDays * 86_400_000))))
          .orderBy(desc(opportunities.expiredAt))
          .limit(2000)
      : await base.innerJoin(watchlist, and(eq(watchlist.opportunityId, opportunities.id), eq(watchlist.userId, user.id))).limit(2000);

  const data = rows.map(({ opp, ev }) => ({
    id: opp.id,
    sport: opp.sportKey,
    league: ev.league,
    event: `${ev.homeTeam} vs ${ev.awayTeam}`,
    commence_time: ev.commenceTime.toISOString(),
    market: opp.marketKey,
    line: opp.line,
    status: opp.status,
    margin_pct: opp.marginPct.toFixed(3),
    peak_margin_pct: opp.peakMarginPct.toFixed(3),
    legs: opp.legs.map((l) => `${l.outcome}@${l.odds}(${l.bookmakerKey})`).join(" | "),
    first_seen: opp.firstSeenAt.toISOString(),
    last_seen: opp.lastSeenAt.toISOString(),
    expired_at: opp.expiredAt ? opp.expiredAt.toISOString() : "",
    demo: opp.isDemo ? "yes" : "no",
  }));
  void trackActivity(user.id, "export_csv", { type: "export", id: type }, { rows: data.length });
  const csv = toCsv(data, Object.keys(data[0] ?? { id: "" }));
  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="arbitrage-${type}-${new Date().toISOString().slice(0, 10)}.csv"`,
    },
  });
});
