import { and, desc, eq, gte } from "drizzle-orm";
import { db } from "@/db";
import { events, opportunities, sports, userActivity } from "@/db/schema";
import { handle, ok, requireUser } from "@/lib/api";
import { getEntitlements } from "@/lib/entitlements";
import { getWatchedIds, toOpportunityDTO } from "@/lib/services/opportunities";
import type { HistoryResponse } from "@/lib/types";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const entitlements = await getEntitlements(user);
  const since = new Date(Date.now() - entitlements.limits.historyDays * 86_400_000);
  const watched = await getWatchedIds(user.id);
  const rows = await db
    .select({ opp: opportunities, ev: events, sportTitle: sports.title })
    .from(opportunities)
    .innerJoin(events, eq(opportunities.eventId, events.id))
    .innerJoin(sports, eq(events.sportId, sports.id))
    .where(and(eq(opportunities.status, "expired"), gte(opportunities.expiredAt, since)))
    .orderBy(desc(opportunities.expiredAt))
    .limit(300);
  const activity = await db
    .select()
    .from(userActivity)
    .where(and(eq(userActivity.userId, user.id), gte(userActivity.createdAt, since)))
    .orderBy(desc(userActivity.createdAt))
    .limit(200);
  const body: HistoryResponse = {
    opportunities: rows.map((r) => toOpportunityDTO(r.opp, r.ev, r.sportTitle, watched.has(r.opp.id))),
    activity: activity.map((a) => ({ id: a.id, action: a.action, entityType: a.entityType, entityId: a.entityId, metadata: a.metadata, createdAt: a.createdAt.toISOString() })),
    historyDays: entitlements.limits.historyDays,
    csvExport: entitlements.limits.csvExport,
  };
  return ok(body);
});
