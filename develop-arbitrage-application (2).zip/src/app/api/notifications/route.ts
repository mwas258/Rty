import { and, desc, eq, inArray, isNull } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { notifications } from "@/db/schema";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { countUnread, toNotificationDTO } from "@/lib/services/users";

export const dynamic = "force-dynamic";

export const GET = handle(async (req) => {
  const user = await requireUser();
  const unreadOnly = req.nextUrl.searchParams.get("unread") === "1";
  const limit = Math.min(Number(req.nextUrl.searchParams.get("limit")) || 50, 200);
  const rows = await db
    .select()
    .from(notifications)
    .where(unreadOnly ? and(eq(notifications.userId, user.id), isNull(notifications.readAt)) : eq(notifications.userId, user.id))
    .orderBy(desc(notifications.createdAt))
    .limit(limit);
  return ok({ items: rows.map(toNotificationDTO), unread: await countUnread(user.id) });
});

const patchSchema = z.object({ ids: z.array(z.string().uuid()).max(200).optional(), all: z.boolean().optional() });

export const PATCH = handle(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, patchSchema);
  const now = new Date();
  if (input.all) {
    await db.update(notifications).set({ readAt: now }).where(and(eq(notifications.userId, user.id), isNull(notifications.readAt)));
  } else if (input.ids?.length) {
    await db.update(notifications).set({ readAt: now }).where(and(eq(notifications.userId, user.id), inArray(notifications.id, input.ids)));
  }
  return ok({ ok: true, unread: await countUnread(user.id) });
});

export const DELETE = handle(async () => {
  const user = await requireUser();
  await db.delete(notifications).where(eq(notifications.userId, user.id));
  return ok({ ok: true });
});
