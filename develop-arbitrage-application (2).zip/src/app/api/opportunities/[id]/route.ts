import { z } from "zod";
import { handle, HttpError, ok, requireUser } from "@/lib/api";
import { trackActivity } from "@/lib/audit";
import { getOpportunityDetail } from "@/lib/services/opportunities";

export const dynamic = "force-dynamic";

export const GET = handle(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  if (!z.string().uuid().safeParse(id).success) throw new HttpError(404, "Opportunity not found.", "not_found");
  const detail = await getOpportunityDetail(user.id, id);
  if (!detail) throw new HttpError(404, "Opportunity not found.", "not_found");
  void trackActivity(user.id, "opportunity_viewed", { type: "opportunity", id }, {
    title: `${detail.opportunity.homeTeam} vs ${detail.opportunity.awayTeam}`,
    marginPct: detail.opportunity.marginPct,
  });
  return ok(detail);
});
