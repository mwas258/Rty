import { handle, ok, parseQuery, requireUser } from "@/lib/api";
import { getEntitlements } from "@/lib/entitlements";
import { listOpportunities } from "@/lib/services/opportunities";
import { runSync } from "@/lib/services/sync";
import { opportunityQuerySchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async (req) => {
  const user = await requireUser();
  const query = parseQuery(req, opportunityQuerySchema);
  void runSync({ trigger: "auto" }).catch(() => undefined);
  const entitlements = await getEntitlements(user);
  return ok(await listOpportunities(user.id, query, entitlements));
});
