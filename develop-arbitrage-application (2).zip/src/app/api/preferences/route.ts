import { eq } from "drizzle-orm";
import { db } from "@/db";
import { userPreferences } from "@/db/schema";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { getEntitlements } from "@/lib/entitlements";
import { getOrCreatePreferences, toPreferencesDTO } from "@/lib/services/users";
import { preferencesSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  return ok(toPreferencesDTO(await getOrCreatePreferences(user.id)));
});

export const PATCH = handle(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, preferencesSchema.partial());
  const entitlements = await getEntitlements(user);
  const update = { ...input };
  if (update.dashboardWidgets && !entitlements.limits.dashboardCustomization) delete update.dashboardWidgets;
  if (!entitlements.limits.externalChannels) {
    update.emailAlerts = false;
    update.telegramAlerts = false;
  }
  await getOrCreatePreferences(user.id);
  const [row] = await db
    .update(userPreferences)
    .set({ ...update, updatedAt: new Date() })
    .where(eq(userPreferences.userId, user.id))
    .returning();
  return ok(toPreferencesDTO(row));
});
