import { eq } from "drizzle-orm";
import { z } from "zod";
import { db } from "@/db";
import { profiles, userPreferences } from "@/db/schema";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { recordAudit } from "@/lib/audit";
import { profileSchema } from "@/lib/validation";

const schema = profileSchema.partial().extend({ acknowledgeResponsibleUse: z.boolean().optional() });

export const PATCH = handle(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, schema);
  if (input.displayName) {
    await db.update(profiles).set({ displayName: input.displayName, updatedAt: new Date() }).where(eq(profiles.id, user.id));
  }
  if (input.acknowledgeResponsibleUse) {
    await db
      .insert(userPreferences)
      .values({ userId: user.id, responsibleUseAckAt: new Date() })
      .onConflictDoUpdate({ target: userPreferences.userId, set: { responsibleUseAckAt: new Date(), updatedAt: new Date() } });
    await recordAudit({ actorId: user.id, action: "user.responsible_use_acknowledged" });
  }
  return ok({ ok: true });
});
