import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { savedFilters } from "@/db/schema";
import { handle, ok, requireUser } from "@/lib/api";

export const DELETE = handle(async (_req, ctx) => {
  const user = await requireUser();
  const { id } = await ctx.params;
  await db.delete(savedFilters).where(and(eq(savedFilters.id, id), eq(savedFilters.userId, user.id)));
  return ok({ ok: true });
});
