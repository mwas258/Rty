import { asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { savedFilters } from "@/db/schema";
import { handle, ok, parseBody, requireUser } from "@/lib/api";
import { assertWithinLimit, getEntitlements } from "@/lib/entitlements";
import type { SavedFilterDTO } from "@/lib/types";
import { savedFilterSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

const toDTO = (r: typeof savedFilters.$inferSelect): SavedFilterDTO => ({ id: r.id, name: r.name, filters: r.filters, createdAt: r.createdAt.toISOString() });

export const GET = handle(async () => {
  const user = await requireUser();
  const [rows, entitlements] = await Promise.all([
    db.select().from(savedFilters).where(eq(savedFilters.userId, user.id)).orderBy(asc(savedFilters.createdAt)),
    getEntitlements(user),
  ]);
  return ok({ items: rows.map(toDTO), limit: entitlements.limits.maxSavedFilters });
});

export const POST = handle(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, savedFilterSchema);
  const entitlements = await getEntitlements(user);
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(savedFilters).where(eq(savedFilters.userId, user.id));
  assertWithinLimit(count, entitlements.limits.maxSavedFilters, "saved filters");
  const [row] = await db.insert(savedFilters).values({ userId: user.id, name: input.name, filters: input.filters }).returning();
  return ok(toDTO(row), { status: 201 });
});
