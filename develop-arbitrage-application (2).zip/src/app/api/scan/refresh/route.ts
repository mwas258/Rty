import { handle, ok, requireUser } from "@/lib/api";
import { enforceRateLimit } from "@/lib/rate-limit";
import { getProviderStatus } from "@/lib/services/opportunities";
import { runSync } from "@/lib/services/sync";

/** Manual refresh. The provider interval is still respected (admins may force). */
export const POST = handle(async (req) => {
  const user = await requireUser();
  enforceRateLimit(req, "scan-refresh", 10, 60_000, user.id);
  const force = user.role === "admin" && req.nextUrl.searchParams.get("force") === "1";
  const result = await runSync({ trigger: "manual", force });
  return ok({ result, provider: await getProviderStatus() });
});
