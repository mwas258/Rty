import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { recordAudit, trackActivity } from "@/lib/audit";
import { getEntitlements, PLANS, TRIAL_DAYS } from "@/lib/entitlements";
import { isPaymentsConfigured } from "@/lib/env";
import { getFlag } from "@/lib/flags";
import { subscriptionActionSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const [entitlements, trialEnabled] = await Promise.all([getEntitlements(user), getFlag("billing.trial_enabled", true)]);
  return ok({ entitlements, plans: PLANS, trialDays: TRIAL_DAYS, trialEnabled, paymentsEnabled: isPaymentsConfigured() });
});

export const POST = handle(async (req) => {
  const user = await requireUser();
  const { action } = await parseBody(req, subscriptionActionSchema);
  const entitlements = await getEntitlements(user);

  if (action === "start_trial") {
    if (!(await getFlag("billing.trial_enabled", true))) throw new HttpError(403, "Trials are currently disabled.", "trial_disabled");
    if (!entitlements.trialEligible || entitlements.plan === "premium") throw new HttpError(400, "You are not eligible for a trial.", "not_eligible");
    const end = new Date(Date.now() + TRIAL_DAYS * 86_400_000);
    await db.insert(subscriptions).values({ userId: user.id, plan: "premium", status: "trialing", provider: "demo_trial", currentPeriodEnd: end });
    await recordAudit({ actorId: user.id, action: "billing.trial_started", metadata: { days: TRIAL_DAYS } });
    void trackActivity(user.id, "trial_started", undefined, { days: TRIAL_DAYS });
  } else if (action === "cancel" || action === "resume") {
    const rows = await db
      .update(subscriptions)
      .set({ cancelAtPeriodEnd: action === "cancel", updatedAt: new Date() })
      .where(and(eq(subscriptions.userId, user.id), eq(subscriptions.plan, "premium"), inArray(subscriptions.status, ["active", "trialing"])))
      .returning();
    if (!rows.length) throw new HttpError(400, "No active subscription.", "no_subscription");
    await recordAudit({ actorId: user.id, action: action === "cancel" ? "billing.cancel_requested" : "billing.resumed" });
  } else if (action === "checkout") {
    // A payment provider is only enabled after availability and legal requirements are verified.
    throw new HttpError(501, "Online payments are not available yet. Start a trial or contact support to upgrade.", "payments_unavailable");
  }
  return ok({ entitlements: await getEntitlements(user) });
});
