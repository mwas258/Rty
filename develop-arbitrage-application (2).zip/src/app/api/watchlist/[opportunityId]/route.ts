import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { watchlist } from "@/db/schema";
import { handle, ok, requireUser } from "@/lib/api";
import { trackActivity } from "@/lib/audit";

export const DELETE = handle(async (_req, ctx) => {
  const user = await requireUser();
  const { opportunityId } = await ctx.params;
  await db.delete(watchlist).where(and(eq(watchlist.userId, user.id), eq(watchlist.opportunityId, opportunityId)));
  void trackActivity(user.id, "watchlist_removed", { type: "opportunity", id: opportunityId });
  return ok({ ok: true });
});
