import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { events, opportunities, sports, watchlist } from "@/db/schema";
import { handle, HttpError, ok, parseBody, requireUser } from "@/lib/api";
import { trackActivity } from "@/lib/audit";
import { assertWithinLimit, getEntitlements } from "@/lib/entitlements";
import { toOpportunityDTO } from "@/lib/services/opportunities";
import type { WatchlistItemDTO } from "@/lib/types";
import { watchlistCreateSchema } from "@/lib/validation";

export const dynamic = "force-dynamic";

export const GET = handle(async () => {
  const user = await requireUser();
  const rows = await db
    .select({ w: watchlist, opp: opportunities, ev: events, sportTitle: sports.title })
    .from(watchlist)
    .innerJoin(opportunities, eq(watchlist.opportunityId, opportunities.id))
    .innerJoin(events, eq(opportunities.eventId, events.id))
    .innerJoin(sports, eq(events.sportId, sports.id))
    .where(eq(watchlist.userId, user.id))
    .orderBy(desc(watchlist.createdAt));
  const items: WatchlistItemDTO[] = rows.map((r) => ({
    id: r.w.id,
    note: r.w.note,
    marginAtSave: r.w.marginAtSave,
    createdAt: r.w.createdAt.toISOString(),
    opportunity: toOpportunityDTO(r.opp, r.ev, r.sportTitle, true),
  }));
  const entitlements = await getEntitlements(user);
  return ok({ items, limit: entitlements.limits.maxWatchlist });
});

export const POST = handle(async (req) => {
  const user = await requireUser();
  const input = await parseBody(req, watchlistCreateSchema);
  const [opp] = await db.select().from(opportunities).where(eq(opportunities.id, input.opportunityId)).limit(1);
  if (!opp) throw new HttpError(404, "Opportunity not found.", "not_found");
  const entitlements = await getEntitlements(user);
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(watchlist).where(eq(watchlist.userId, user.id));
  assertWithinLimit(count, entitlements.limits.maxWatchlist, "saved opportunities");
  await db
    .insert(watchlist)
    .values({ userId: user.id, opportunityId: opp.id, marginAtSave: opp.marginPct, note: input.note ?? null })
    .onConflictDoNothing();
  void trackActivity(user.id, "watchlist_added", { type: "opportunity", id: opp.id }, { marginPct: opp.marginPct });
  return ok({ ok: true }, { status: 201 });
});
