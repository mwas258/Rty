"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bell, BellRing, CheckCheck, Clock, Pencil, Plus, Trash2, TrendingDown, TrendingUp } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, PageHeader } from "@/components/ui/card";
import { Checkbox, Field, Input, Switch } from "@/components/ui/input";
import { Modal } from "@/components/ui/modal";
import { EmptyState, ErrorState, InlineAlert, ListSkeleton } from "@/components/ui/states";
import { Tabs } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage, isPlanError } from "@/lib/client/api";
import { useMe } from "@/lib/client/hooks";
import type { AlertRuleDTO, NotificationDTO, OpportunityListResponse } from "@/lib/types";
import { formatRelative } from "@/lib/utils";
import { alertRuleSchema, type AlertRuleInput } from "@/lib/validation";

const TYPE_ICON: Record<string, typeof Bell> = { new_opportunity: BellRing, odds_change: TrendingUp, opportunity_expired: TrendingDown, stale_data: Clock };
const SPORT_GROUPS = [
  { key: "soccer", label: "Soccer" },
  { key: "basketball", label: "Basketball" },
  { key: "tennis", label: "Tennis" },
  { key: "icehockey", label: "Ice hockey" },
  { key: "americanfootball", label: "American football" },
];
const MARKETS = [
  { key: "h2h", label: "Match winner / 1X2" },
  { key: "totals", label: "Totals" },
  { key: "spreads", label: "Handicap" },
];

export default function AlertsPage() {
  const [tab, setTab] = useState<"inbox" | "rules">("inbox");
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe();
  const inbox = useQuery({ queryKey: ["notifications", "list"], queryFn: () => api<{ items: NotificationDTO[]; unread: number }>("/api/notifications?limit=100"), refetchInterval: 60_000 });
  const rules = useQuery({ queryKey: ["alert-rules"], queryFn: () => api<{ items: AlertRuleDTO[]; limit: number; externalChannels: boolean }>("/api/alerts/rules") });
  const facets = useQuery({ queryKey: ["opportunities", "facets"], queryFn: () => api<OpportunityListResponse>("/api/opportunities?limit=1"), staleTime: 5 * 60_000 });
  const [editing, setEditing] = useState<AlertRuleDTO | null | "new">(null);

  const invalidate = () => {
    void qc.invalidateQueries({ queryKey: ["notifications"] });
    void qc.invalidateQueries({ queryKey: ["dashboard"] });
  };
  const markAll = useMutation({ mutationFn: () => api("/api/notifications", { method: "PATCH", json: { all: true } }), onSuccess: invalidate });
  const markOne = useMutation({ mutationFn: (id: string) => api("/api/notifications", { method: "PATCH", json: { ids: [id] } }), onSuccess: invalidate });
  const toggleRule = useMutation({
    mutationFn: ({ id, enabled }: { id: string; enabled: boolean }) => api(`/api/alerts/rules/${id}`, { method: "PATCH", json: { enabled } }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["alert-rules"] }),
    onError: (err) => toast.error("Could not update rule", errorMessage(err)),
  });
  const deleteRule = useMutation({
    mutationFn: (id: string) => api(`/api/alerts/rules/${id}`, { method: "DELETE" }),
    onSuccess: () => {
      toast.success("Rule deleted");
      void qc.invalidateQueries({ queryKey: ["alert-rules"] });
    },
  });

  const unread = inbox.data?.unread ?? 0;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Alerts & notifications"
        description="In-app alerts for new opportunities, odds moves, disappearing opportunities and stale data. Duplicates are suppressed automatically."
        action={
          tab === "inbox" ? (
            <Button variant="outline" size="sm" disabled={!unread} loading={markAll.isPending} onClick={() => markAll.mutate()}>
              <CheckCheck className="h-4 w-4" /> Mark all read
            </Button>
          ) : (
            <Button size="sm" onClick={() => setEditing("new")}>
              <Plus className="h-4 w-4" /> New rule
            </Button>
          )
        }
      />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { value: "inbox", label: "Inbox", badge: unread || undefined },
          { value: "rules", label: "Rules", badge: rules.data ? `${rules.data.items.length}/${rules.data.limit}` : undefined },
        ]}
      />

      {tab === "inbox" &&
        (inbox.isError ? (
          <ErrorState error={inbox.error} onRetry={() => inbox.refetch()} />
        ) : inbox.isLoading ? (
          <ListSkeleton count={3} rows={1} />
        ) : !inbox.data?.items.length ? (
          <EmptyState icon={<Bell className="h-6 w-6" />} title="No notifications yet" description="Create an alert rule and you will be notified here when matching opportunities appear." action={<Button size="sm" onClick={() => setTab("rules")}>Set up a rule</Button>} />
        ) : (
          <ul className="space-y-2">
            {inbox.data.items.map((n) => {
              const Icon = TYPE_ICON[n.type] ?? Bell;
              return (
                <li key={n.id} className={`rounded-2xl border bg-surface p-4 ${n.readAt ? "border-border" : "border-primary/40"}`}>
                  <div className="flex items-start gap-3">
                    <span className={`mt-0.5 rounded-lg p-2 ${n.readAt ? "bg-surface-2 text-muted" : "bg-primary/15 text-primary"}`}>
                      <Icon className="h-4 w-4" />
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <p className={`text-sm ${n.readAt ? "" : "font-semibold"}`}>{n.title}</p>
                        {n.data.isDemo === true && <Badge variant="outline">Demo</Badge>}
                      </div>
                      <p className="mt-0.5 text-xs text-muted">{n.body}</p>
                      <div className="mt-2 flex items-center gap-3 text-xs">
                        <span className="text-muted">{formatRelative(n.createdAt)}</span>
                        {n.opportunityId && (
                          <Link href={`/app/opportunities/${n.opportunityId}`} className="font-medium text-primary hover:underline" onClick={() => !n.readAt && markOne.mutate(n.id)}>
                            View opportunity
                          </Link>
                        )}
                        {!n.readAt && (
                          <button type="button" className="text-muted hover:text-fg" onClick={() => markOne.mutate(n.id)}>
                            Mark read
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        ))}

      {tab === "rules" && (
        <>
          {!me.data?.user.emailVerified && <InlineAlert tone="warning">Verify your e-mail address to create alert rules.</InlineAlert>}
          {rules.isError ? (
            <ErrorState error={rules.error} onRetry={() => rules.refetch()} />
          ) : rules.isLoading ? (
            <ListSkeleton count={2} rows={2} />
          ) : !rules.data?.items.length ? (
            <EmptyState title="No alert rules" description="Rules combine a minimum margin with preferred sports, markets and bookmakers." action={<Button size="sm" onClick={() => setEditing("new")}>Create your first rule</Button>} />
          ) : (
            <div className="grid gap-3 md:grid-cols-2">
              {rules.data.items.map((r) => (
                <Card key={r.id}>
                  <CardContent className="space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="font-semibold">{r.name}</h3>
                        <p className="text-xs text-muted">
                          ≥ {r.minMarginPct}% margin{r.minNetProfit !== null ? ` · ≥ ${r.minNetProfit} net` : ""} · {r.channels.join(", ")}
                        </p>
                      </div>
                      <Switch checked={r.enabled} onChange={(v) => toggleRule.mutate({ id: r.id, enabled: v })} />
                    </div>
                    <div className="flex flex-wrap gap-1.5 text-xs">
                      {(r.sports.length ? r.sports : ["all sports"]).map((s) => (
                        <Badge key={s} variant="outline">
                          {s}
                        </Badge>
                      ))}
                      {(r.markets.length ? r.markets : ["all markets"]).map((m) => (
                        <Badge key={m} variant="outline">
                          {m}
                        </Badge>
                      ))}
                      {r.bookmakers.length > 0 && <Badge variant="outline">{r.bookmakers.length} bookmakers</Badge>}
                    </div>
                    <div className="flex items-center justify-between text-xs text-muted">
                      <span>{r.lastTriggeredAt ? `Last triggered ${formatRelative(r.lastTriggeredAt)}` : "Not triggered yet"}</span>
                      <span className="flex gap-1">
                        <Button variant="ghost" size="sm" onClick={() => setEditing(r)} aria-label="Edit rule">
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm" onClick={() => deleteRule.mutate(r.id)} aria-label="Delete rule">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
          {rules.data && rules.data.items.length >= rules.data.limit && (
            <InlineAlert tone="info">
              You have reached the {rules.data.limit}-rule limit of your plan.{" "}
              <Link href="/app/settings?tab=subscription" className="font-medium underline">
                Upgrade for more
              </Link>
            </InlineAlert>
          )}
        </>
      )}

      {editing && (
        <RuleModal
          rule={editing === "new" ? null : editing}
          onClose={() => setEditing(null)}
          bookmakers={facets.data?.facets.bookmakers ?? []}
          externalChannels={rules.data?.externalChannels ?? false}
          emailConfigured={me.data?.config.emailDelivery ?? false}
          telegramConfigured={me.data?.config.telegram ?? false}
        />
      )}
    </div>
  );
}

function RuleModal({
  rule,
  onClose,
  bookmakers,
  externalChannels,
  emailConfigured,
  telegramConfigured,
}: {
  rule: AlertRuleDTO | null;
  onClose: () => void;
  bookmakers: { key: string; name: string }[];
  externalChannels: boolean;
  emailConfigured: boolean;
  telegramConfigured: boolean;
}) {
  const qc = useQueryClient();
  const toast = useToast();
  const form = useForm<AlertRuleInput>({
    resolver: zodResolver(alertRuleSchema),
    defaultValues: rule
      ? { name: rule.name, minMarginPct: rule.minMarginPct, minNetProfit: rule.minNetProfit, sports: rule.sports, markets: rule.markets, bookmakers: rule.bookmakers, channels: rule.channels as AlertRuleInput["channels"], enabled: rule.enabled }
      : { name: "", minMarginPct: 1, minNetProfit: null, sports: [], markets: [], bookmakers: [], channels: ["in_app"], enabled: true },
  });
  const save = useMutation({
    mutationFn: (values: AlertRuleInput) => (rule ? api(`/api/alerts/rules/${rule.id}`, { method: "PATCH", json: values }) : api("/api/alerts/rules", { method: "POST", json: values })),
    onSuccess: () => {
      toast.success(rule ? "Rule updated" : "Rule created");
      void qc.invalidateQueries({ queryKey: ["alert-rules"] });
      onClose();
    },
    onError: (err) => toast.error(isPlanError(err) ? "Plan limit reached" : "Could not save rule", errorMessage(err)),
  });
  const arr = (key: "sports" | "markets" | "bookmakers" | "channels") => form.watch(key) as string[];
  const toggleArr = (key: "sports" | "markets" | "bookmakers" | "channels", value: string) => {
    const cur = arr(key);
    form.setValue(key, (cur.includes(value) ? cur.filter((v) => v !== value) : [...cur, value]) as never, { shouldValidate: true });
  };

  return (
    <Modal open onClose={onClose} title={rule ? "Edit alert rule" : "New alert rule"} description="Leave a group empty to match everything in it.">
      <form className="space-y-4" onSubmit={form.handleSubmit((v) => save.mutate(v))} noValidate>
        <Field label="Name" htmlFor="rule-name" error={form.formState.errors.name?.message}>
          <Input id="rule-name" {...form.register("name")} placeholder="e.g. Soccer ≥ 1.5%" />
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Minimum margin %" error={form.formState.errors.minMarginPct?.message}>
            <Input type="number" step="0.1" min="0" inputMode="decimal" {...form.register("minMarginPct", { valueAsNumber: true })} />
          </Field>
          <Field label="Minimum net profit (optional)" hint="At your default stake" error={form.formState.errors.minNetProfit?.message}>
            <Input type="number" step="0.5" min="0" inputMode="decimal" {...form.register("minNetProfit", { setValueAs: (v) => (v === "" || v === null ? null : Number(v)) })} />
          </Field>
        </div>
        <div>
          <p className="mb-1.5 text-xs font-medium text-muted">Sports</p>
          <div className="grid grid-cols-2 gap-1.5">
            {SPORT_GROUPS.map((s) => (
              <Checkbox key={s.key} checked={arr("sports").includes(s.key)} onChange={() => toggleArr("sports", s.key)} label={s.label} />
            ))}
          </div>
        </div>
        <div>
          <p className="mb-1.5 text-xs font-medium text-muted">Markets</p>
          <div className="grid grid-cols-2 gap-1.5">
            {MARKETS.map((m) => (
              <Checkbox key={m.key} checked={arr("markets").includes(m.key)} onChange={() => toggleArr("markets", m.key)} label={m.label} />
            ))}
          </div>
        </div>
        {bookmakers.length > 0 && (
          <div>
            <p className="mb-1.5 text-xs font-medium text-muted">Bookmakers (all legs must match)</p>
            <div className="grid max-h-36 grid-cols-2 gap-1.5 overflow-y-auto">
              {bookmakers.map((b) => (
                <Checkbox key={b.key} checked={arr("bookmakers").includes(b.key)} onChange={() => toggleArr("bookmakers", b.key)} label={b.name} />
              ))}
            </div>
          </div>
        )}
        <div>
          <p className="mb-1.5 text-xs font-medium text-muted">Channels</p>
          <div className="flex flex-wrap gap-3">
            <Checkbox checked disabled onChange={() => undefined} label="In-app" />
            <Checkbox checked={arr("channels").includes("email")} disabled={!externalChannels || !emailConfigured} onChange={() => toggleArr("channels", "email")} label={`E-mail${!emailConfigured ? " (not configured)" : !externalChannels ? " (Premium)" : ""}`} />
            <Checkbox checked={arr("channels").includes("telegram")} disabled={!externalChannels || !telegramConfigured} onChange={() => toggleArr("channels", "telegram")} label={`Telegram${!telegramConfigured ? " (not configured)" : !externalChannels ? " (Premium)" : ""}`} />
          </div>
        </div>
        <Switch checked={form.watch("enabled")} onChange={(v) => form.setValue("enabled", v)} label="Rule enabled" />
        <div className="flex justify-end gap-2 pt-2">
          <Button variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit" loading={save.isPending}>
            {rule ? "Save changes" : "Create rule"}
          </Button>
        </div>
      </form>
    </Modal>
  );
}
