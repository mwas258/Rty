"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ExternalLink, Search } from "lucide-react";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, PageHeader } from "@/components/ui/card";
import { Input, Select, Switch } from "@/components/ui/input";
import { EmptyState, ErrorState, ListSkeleton } from "@/components/ui/states";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage } from "@/lib/client/api";
import type { BookmakerDTO } from "@/lib/types";

export default function BookmakersPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const [q, setQ] = useState("");
  const [country, setCountry] = useState("");
  const [market, setMarket] = useState("");
  const [onlyMine, setOnlyMine] = useState(false);
  const list = useQuery({ queryKey: ["bookmakers"], queryFn: () => api<{ items: BookmakerDTO[]; saved: number }>("/api/bookmakers") });

  const toggle = useMutation({
    mutationFn: ({ id, available }: { id: number; available: boolean }) => api(`/api/bookmakers/${id}`, { method: "PATCH", json: { available } }),
    onMutate: async ({ id, available }) => {
      await qc.cancelQueries({ queryKey: ["bookmakers"] });
      const prev = qc.getQueryData<{ items: BookmakerDTO[]; saved: number }>(["bookmakers"]);
      if (prev) qc.setQueryData(["bookmakers"], { ...prev, items: prev.items.map((b) => (b.id === id ? { ...b, available } : b)) });
      return { prev };
    },
    onError: (err, _vars, ctx) => {
      if (ctx?.prev) qc.setQueryData(["bookmakers"], ctx.prev);
      toast.error("Could not update bookmaker", errorMessage(err));
    },
    onSettled: () => {
      void qc.invalidateQueries({ queryKey: ["bookmakers"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });

  const items = useMemo(() => list.data?.items ?? [], [list.data]);
  const countries = useMemo(() => [...new Set(items.map((b) => b.country).filter((c): c is string => Boolean(c)))].sort(), [items]);
  const markets = useMemo(() => [...new Set(items.flatMap((b) => b.supportedMarkets))].sort(), [items]);
  const filtered = items.filter(
    (b) =>
      (!q || b.name.toLowerCase().includes(q.toLowerCase())) &&
      (!country || b.country === country) &&
      (!market || b.supportedMarkets.includes(market)) &&
      (!onlyMine || b.available === true),
  );
  const mine = items.filter((b) => b.available === true).length;

  return (
    <div className="space-y-4">
      <PageHeader
        title="Bookmaker directory"
        description={`Mark the bookmakers where you hold a funded account. ${mine} of ${items.length} marked available — the scanner can filter opportunities to those.`}
      />
      <div className="grid gap-2 sm:grid-cols-[1fr_auto_auto_auto]">
        <div className="relative">
          <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search bookmakers" className="pl-9" aria-label="Search bookmakers" />
        </div>
        <Select value={country} onChange={(e) => setCountry(e.target.value)} aria-label="Country" className="sm:w-44">
          <option value="">All countries</option>
          {countries.map((c) => (
            <option key={c}>{c}</option>
          ))}
        </Select>
        <Select value={market} onChange={(e) => setMarket(e.target.value)} aria-label="Market" className="sm:w-40">
          <option value="">All markets</option>
          {markets.map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </Select>
        <div className="flex h-10 items-center">
          <Switch checked={onlyMine} onChange={setOnlyMine} label="Only mine" />
        </div>
      </div>

      {list.isError ? (
        <ErrorState error={list.error} onRetry={() => list.refetch()} />
      ) : list.isLoading ? (
        <ListSkeleton count={6} rows={2} />
      ) : filtered.length === 0 ? (
        <EmptyState title="No bookmakers match" description="Try a different search, country or market." />
      ) : (
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {filtered.map((b) => (
            <Card key={b.id} className={b.available === false ? "opacity-70" : ""}>
              <CardContent className="space-y-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <h3 className="truncate font-semibold">{b.name}</h3>
                    <p className="text-xs text-muted">
                      {b.country ?? "Country unknown"} · {b.currency ?? "—"}
                    </p>
                  </div>
                  <Switch checked={b.available === true} onChange={(v) => toggle.mutate({ id: b.id, available: v })} id={`bk-${b.id}`} />
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {b.supportedMarkets.map((m) => (
                    <Badge key={m} variant="outline">
                      {m}
                    </Badge>
                  ))}
                  {b.isExchange && <Badge variant="info">Exchange · {b.commissionPct}% commission</Badge>}
                  {b.activeOpportunities > 0 && <Badge variant="profit">{b.activeOpportunities} active opp.</Badge>}
                </div>
                <div className="flex items-center justify-between text-xs text-muted">
                  <span>{b.available === true ? "Marked available" : b.available === false ? "Marked unavailable" : "Not set"}</span>
                  {b.website && (
                    <a href={b.website} target="_blank" rel="noreferrer noopener" className="inline-flex items-center gap-1 text-primary hover:underline">
                      Website <ExternalLink className="h-3 w-3" />
                    </a>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
