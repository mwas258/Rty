"use client";

import { Crown, Plus, X } from "lucide-react";
import Link from "next/link";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { ArbCalculator, emptyLegs, initialCalculatorState, type CalcLegInput, type CalculatorDefaults, type CalculatorState } from "@/components/calculator/arb-calculator";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/card";
import { CardSkeleton } from "@/components/ui/states";
import { useToast } from "@/components/ui/toast";
import { useMe } from "@/lib/client/hooks";

function parseLegs(raw: string | null): CalcLegInput[] | undefined {
  if (!raw) return undefined;
  const legs = raw
    .split("|")
    .map((part) => {
      const [label, odds, bookmaker] = part.split("@").map((p) => decodeURIComponent(p));
      return { label: label ?? "", odds: odds ?? "", bookmaker: bookmaker ?? "" };
    })
    .filter((l) => l.odds);
  return legs.length >= 2 ? legs : undefined;
}

function CalculatorWorkspace() {
  const params = useSearchParams();
  const me = useMe();
  const toast = useToast();
  const [tabs, setTabs] = useState<{ id: number; state: CalculatorState; opportunityId: string | null }[]>([]);
  const [active, setActive] = useState(0);

  const prefs = me.data?.preferences;
  const maxCalculators = me.data?.entitlements.limits.maxCalculators ?? 1;
  const defaults: CalculatorDefaults | null = prefs
    ? {
        stake: prefs.defaultStake,
        commissionPct: prefs.defaultCommissionPct,
        fxPct: prefs.defaultFxPct,
        fixedCosts: prefs.defaultFixedCosts,
        roundingStep: prefs.roundingStep,
        currency: prefs.currency,
      }
    : null;

  useEffect(() => {
    if (!defaults || tabs.length) return;
    const legs = parseLegs(params.get("legs"));
    const stake = Number(params.get("stake")) || undefined;
    setTabs([{ id: 1, state: initialCalculatorState(defaults, legs ?? emptyLegs(2), stake), opportunityId: params.get("opp") }]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [defaults?.stake, params]);

  if (!defaults || !tabs.length) return <CardSkeleton rows={6} />;

  const addTab = () => {
    if (tabs.length >= maxCalculators) {
      toast.info("Calculator limit reached", `Your plan allows ${maxCalculators} calculator${maxCalculators === 1 ? "" : "s"}. Premium allows 5.`);
      return;
    }
    const id = Math.max(...tabs.map((t) => t.id)) + 1;
    setTabs([...tabs, { id, state: initialCalculatorState(defaults, emptyLegs(2)), opportunityId: null }]);
    setActive(tabs.length);
  };
  const closeTab = (idx: number) => {
    if (tabs.length === 1) return;
    const next = tabs.filter((_, i) => i !== idx);
    setTabs(next);
    setActive(Math.max(0, Math.min(active, next.length - 1)));
  };
  const current = tabs[active] ?? tabs[0];

  return (
    <div className="space-y-4">
      <PageHeader
        title="Arbitrage calculator"
        description="Two-way, three-way or multi-outcome markets. Defaults come from your preferences."
        action={
          <Button variant="outline" size="sm" onClick={addTab}>
            <Plus className="h-4 w-4" /> New calculator {maxCalculators > 1 && `(${tabs.length}/${maxCalculators})`}
          </Button>
        }
      />
      {tabs.length > 1 && (
        <div className="scrollbar-thin flex gap-1 overflow-x-auto rounded-xl border border-border bg-surface p-1">
          {tabs.map((t, i) => (
            <div key={t.id} className={`flex items-center rounded-lg ${i === active ? "bg-primary text-primary-fg" : "text-muted hover:bg-surface-2"}`}>
              <button type="button" onClick={() => setActive(i)} className="px-3 py-1.5 text-sm font-medium">
                Calc {t.id}
              </button>
              <button type="button" onClick={() => closeTab(i)} className="pr-2 opacity-70 hover:opacity-100" aria-label={`Close calculator ${t.id}`}>
                <X className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>
      )}
      <ArbCalculator
        key={current.id}
        state={current.state}
        onChange={(s) => setTabs(tabs.map((t) => (t.id === current.id ? { ...t, state: s } : t)))}
        defaults={defaults}
        opportunityId={current.opportunityId}
      />
      {maxCalculators === 1 && (
        <p className="text-xs text-muted">
          <Crown className="mr-1 inline h-3.5 w-3.5 text-warning" /> Premium members can keep up to 5 calculators open side by side.{" "}
          <Link href="/app/settings?tab=subscription" className="font-medium text-primary hover:underline">
            Learn more
          </Link>
        </p>
      )}
    </div>
  );
}

export default function CalculatorPage() {
  return (
    <Suspense fallback={<CardSkeleton rows={6} />}>
      <CalculatorWorkspace />
    </Suspense>
  );
}
