"use client";

import { useQuery } from "@tanstack/react-query";
import { Crown, Download, History } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { OpportunityCard } from "@/components/opportunity/opportunity-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent, PageHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, InlineAlert, ListSkeleton } from "@/components/ui/states";
import { Tabs } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/toast";
import { api, ApiError, errorMessage } from "@/lib/client/api";
import { useMe } from "@/lib/client/hooks";
import type { HistoryResponse } from "@/lib/types";
import { formatDateTime, formatMoney, formatPct } from "@/lib/utils";

const ACTIVITY_LABELS: Record<string, string> = {
  calculation_saved: "Calculation saved",
  opportunity_viewed: "Opportunity viewed",
  watchlist_added: "Added to watchlist",
  watchlist_removed: "Removed from watchlist",
  alert_rule_created: "Alert rule created",
  bookmaker_enabled: "Bookmaker enabled",
  bookmaker_disabled: "Bookmaker disabled",
  export_csv: "CSV exported",
  trial_started: "Premium trial started",
};

export default function HistoryPage() {
  const [tab, setTab] = useState<"opportunities" | "activity">("opportunities");
  const toast = useToast();
  const me = useMe();
  const history = useQuery({ queryKey: ["history"], queryFn: () => api<HistoryResponse>("/api/history") });
  const [exporting, setExporting] = useState(false);
  const currency = me.data?.preferences.currency ?? "EUR";

  const exportCsv = async () => {
    setExporting(true);
    try {
      const res = await fetch("/api/export?type=history", { credentials: "same-origin" });
      if (!res.ok) {
        const body = (await res.json().catch(() => ({}))) as { error?: string };
        throw new ApiError(res.status, body.error ?? "Export failed");
      }
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `arbitrage-history-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(url);
      toast.success("CSV downloaded");
    } catch (err) {
      toast.error(err instanceof ApiError && err.status === 402 ? "Premium feature" : "Export failed", errorMessage(err));
    } finally {
      setExporting(false);
    }
  };

  const data = history.data;

  return (
    <div className="space-y-4">
      <PageHeader
        title="History"
        description={data ? `Expired opportunities and your activity from the last ${data.historyDays} days (plan retention).` : "Expired opportunities and your activity."}
        action={
          <Button variant="outline" size="sm" loading={exporting} onClick={exportCsv} title={data?.csvExport ? "Download CSV" : "CSV export is a Premium feature"}>
            {data?.csvExport ? <Download className="h-4 w-4" /> : <Crown className="h-4 w-4 text-warning" />} Export CSV
          </Button>
        }
      />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { value: "opportunities", label: "Expired opportunities", badge: data?.opportunities.length },
          { value: "activity", label: "My activity", badge: data?.activity.length },
        ]}
      />
      {history.isError ? (
        <ErrorState error={history.error} onRetry={() => history.refetch()} />
      ) : !data ? (
        <ListSkeleton />
      ) : tab === "opportunities" ? (
        data.opportunities.length === 0 ? (
          <EmptyState icon={<History className="h-6 w-6" />} title="No expired opportunities in this window" description="Opportunities move here when odds change, the market closes or the event starts." />
        ) : (
          <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
            {data.opportunities.map((o) => (
              <OpportunityCard key={o.id} opportunity={o} stake={me.data?.preferences.defaultStake} currency={currency} compact />
            ))}
          </div>
        )
      ) : data.activity.length === 0 ? (
        <EmptyState title="No activity yet" description="Calculations you save, watchlist changes and exports are recorded here." />
      ) : (
        <Card>
          <CardContent className="p-0">
            <ul className="divide-y divide-border">
              {data.activity.map((a) => {
                const meta = a.metadata as { title?: string; name?: string; marginPct?: number; netProfit?: number; totalStake?: number };
                return (
                  <li key={a.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 text-sm">
                    <div className="min-w-0">
                      <p className="font-medium">{ACTIVITY_LABELS[a.action] ?? a.action}</p>
                      <p className="truncate text-xs text-muted">
                        {meta.title ?? meta.name ?? ""}
                        {typeof meta.marginPct === "number" && ` · margin ${formatPct(meta.marginPct)}`}
                        {typeof meta.netProfit === "number" && ` · net ${formatMoney(meta.netProfit, currency)} on ${formatMoney(meta.totalStake ?? 0, currency)}`}
                        {a.entityType === "opportunity" && a.entityId && (
                          <>
                            {" "}
                            ·{" "}
                            <Link href={`/app/opportunities/${a.entityId}`} className="text-primary hover:underline">
                              open
                            </Link>
                          </>
                        )}
                      </p>
                    </div>
                    <time className="text-xs text-muted">{formatDateTime(a.createdAt)}</time>
                  </li>
                );
              })}
            </ul>
          </CardContent>
        </Card>
      )}
      {data && !data.csvExport && (
        <InlineAlert tone="info">
          Premium extends history to 90 days and enables CSV export.{" "}
          <Link href="/app/settings?tab=subscription" className="font-medium underline">
            Compare plans
          </Link>
        </InlineAlert>
      )}
    </div>
  );
}
