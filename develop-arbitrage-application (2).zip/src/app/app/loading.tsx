import { ListSkeleton, Skeleton } from "@/components/ui/states";

export default function Loading() {
  return (
    <div className="space-y-4">
      <Skeleton className="h-7 w-48" />
      <ListSkeleton count={3} />
    </div>
  );
}
