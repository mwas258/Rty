"use client";

import { useQuery } from "@tanstack/react-query";
import { AlertTriangle, ArrowLeft, Calculator, Clock, ExternalLink } from "lucide-react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import { StaleDataBanner } from "@/components/banners";
import { ArbCalculator, initialCalculatorState, type CalculatorState } from "@/components/calculator/arb-calculator";
import { FreshnessBadge, MarginBadge, WatchButton } from "@/components/opportunity/badges";
import { OddsTable } from "@/components/opportunity/odds-table";
import { calculatorHref } from "@/components/opportunity/opportunity-card";
import { Badge } from "@/components/ui/badge";
import { LinkButton } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { CardSkeleton, ErrorState, InlineAlert } from "@/components/ui/states";
import { dataFreshness, oddsMovement } from "@/lib/arb/engine";
import { api } from "@/lib/client/api";
import { useMe, useNow } from "@/lib/client/hooks";
import type { OpportunityDetailResponse } from "@/lib/types";
import { formatDateTime, formatOdds, formatPct, formatRelative, sportIcon } from "@/lib/utils";

export default function OpportunityDetailPage() {
  const { id } = useParams<{ id: string }>();
  const me = useMe();
  const now = useNow();
  const detail = useQuery({ queryKey: ["opportunity", id], queryFn: () => api<OpportunityDetailResponse>(`/api/opportunities/${id}`), refetchInterval: 60_000, enabled: Boolean(id) });
  const [calc, setCalc] = useState<CalculatorState | null>(null);

  const prefs = me.data?.preferences;
  const defaults = {
    stake: prefs?.defaultStake ?? 100,
    commissionPct: prefs?.defaultCommissionPct ?? 0,
    fxPct: prefs?.defaultFxPct ?? 0,
    fixedCosts: prefs?.defaultFixedCosts ?? 0,
    roundingStep: prefs?.roundingStep ?? 1,
    currency: prefs?.currency ?? "EUR",
  };

  useEffect(() => {
    if (!detail.data || !prefs || calc) return;
    setCalc(
      initialCalculatorState(
        defaults,
        detail.data.opportunity.legs.map((l) => ({ label: l.outcome, odds: String(l.odds), bookmaker: l.bookmakerName })),
      ),
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [detail.data, prefs]);

  if (detail.isError) return <ErrorState error={detail.error} onRetry={() => detail.refetch()} title="Could not load this opportunity" />;
  if (!detail.data) return <CardSkeleton rows={6} />;

  const { opportunity: o, provider, previousLegs } = detail.data;
  const freshness = dataFreshness(o.dataUpdatedAt, now);
  const started = new Date(o.commenceTime).getTime() < now;
  const movements = previousLegs
    ? o.legs
        .map((leg) => {
          const prev = previousLegs.find((p) => p.outcome === leg.outcome);
          return prev ? { leg, prev, movement: oddsMovement(prev.odds, leg.odds) } : null;
        })
        .filter((m): m is NonNullable<typeof m> => Boolean(m?.movement.warning))
    : [];

  return (
    <div className="space-y-4">
      <Link href="/app/scanner" className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg">
        <ArrowLeft className="h-4 w-4" /> Back to scanner
      </Link>

      <Card>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div className="min-w-0">
              <div className="flex flex-wrap items-center gap-2 text-xs text-muted">
                <span aria-hidden>{sportIcon(o.sportKey)}</span>
                <span>{o.sportTitle}</span>
                <span aria-hidden>·</span>
                <span>{o.league}</span>
                {o.isDemo && <Badge variant="outline">Demo data</Badge>}
                <Badge variant={o.status === "active" ? "profit" : "danger"}>{o.status === "active" ? "Active" : `Expired · ${o.expiredReason?.replace("_", " ") ?? ""}`}</Badge>
              </div>
              <h1 className="mt-1 text-xl font-semibold sm:text-2xl">
                {o.homeTeam} vs {o.awayTeam}
              </h1>
              <p className="mt-0.5 text-sm text-muted">
                {o.marketLabel} · {o.outcomeCount}-way · kick-off {formatDateTime(o.commenceTime)} ({formatRelative(o.commenceTime, now)})
              </p>
            </div>
            <div className="flex flex-col items-end gap-2">
              <MarginBadge value={o.marginPct} size="lg" />
              <p className="text-xs text-muted">implied sum {formatPct(o.impliedSum * 100)} · peak {formatPct(o.peakMarginPct)}</p>
            </div>
          </div>

          <div className="grid gap-2 sm:grid-cols-3">
            {o.legs.map((leg) => (
              <div key={leg.outcome} className="rounded-xl border border-border bg-surface-2 p-3">
                <p className="text-xs text-muted">{leg.outcome}</p>
                <p className="text-2xl font-semibold tabular">{formatOdds(leg.odds)}</p>
                <p className="text-sm">{leg.bookmakerName}</p>
                <p className="text-[11px] text-muted">updated {formatRelative(leg.updatedAt, now)}</p>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <WatchButton opportunityId={o.id} watched={o.watched} size="md" label />
            <LinkButton href={calculatorHref(o, defaults.stake)} variant="outline">
              <Calculator className="h-4 w-4" /> Open in full calculator
            </LinkButton>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        <StaleDataBanner provider={provider} />
        {freshness.level === "stale" && (
          <InlineAlert tone="warning">
            <Clock className="mr-1 inline h-4 w-4 text-warning" /> The best prices for this market were last updated {freshness.label}. Re-check odds at the bookmakers before acting.
          </InlineAlert>
        )}
        {started && o.status === "active" && <InlineAlert tone="warning">This event appears to have started. Pre-match prices are probably no longer available.</InlineAlert>}
        {movements.map(({ leg, prev, movement }) => (
          <InlineAlert key={leg.outcome} tone="warning">
            <AlertTriangle className="mr-1 inline h-4 w-4 text-warning" /> {leg.outcome}: {formatOdds(prev.odds)} → {formatOdds(leg.odds)} at {leg.bookmakerName}. {movement.warning}
          </InlineAlert>
        ))}
      </div>

      <Card>
        <CardHeader title="Odds comparison" description="Latest stored price per bookmaker. Highlighted cells are the best available price for each outcome." action={<FreshnessBadge updatedAt={o.dataUpdatedAt} />} />
        <CardContent>
          <OddsTable detail={detail.data} />
          <div className="mt-3 grid gap-2 text-xs text-muted sm:grid-cols-2 lg:grid-cols-4">
            <p>First seen: {formatDateTime(o.firstSeenAt)}</p>
            <p>Last seen: {formatDateTime(o.lastSeenAt)}</p>
            <p>Odds updated: {formatDateTime(o.dataUpdatedAt)}</p>
            <p>Seen {o.timesSeen}× · source: {o.provider}</p>
          </div>
          <p className="mt-3 text-xs text-muted">
            Liquidity / stake limits: not supplied by the current data provider. Check limits directly at each bookmaker before committing a stake.
            {o.legs.some((l) => detail.data.bookmakers.find((b) => b.key === l.bookmakerKey)?.isExchange) && " One or more legs are exchange prices — commission applies to winnings."}
          </p>
        </CardContent>
      </Card>

      {calc && <ArbCalculator state={calc} onChange={setCalc} defaults={defaults} opportunityId={o.id} title="Stake split for this opportunity" />}

      <p className="flex items-center gap-1 text-xs text-muted">
        <ExternalLink className="h-3.5 w-3.5" /> Prices are informational. Verify at the bookmaker; availability, limits and account restrictions vary by user and jurisdiction.
      </p>
    </div>
  );
}
