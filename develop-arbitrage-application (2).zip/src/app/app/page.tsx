"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Activity, Bell, Bookmark, Building2, Crown, Percent, RefreshCw, Target, Zap } from "lucide-react";
import Link from "next/link";
import { StaleDataBanner } from "@/components/banners";
import { OpportunityCard } from "@/components/opportunity/opportunity-card";
import { Badge } from "@/components/ui/badge";
import { Button, LinkButton } from "@/components/ui/button";
import { Card, CardContent, CardHeader, PageHeader, StatCard } from "@/components/ui/card";
import { EmptyState, ErrorState, ListSkeleton, Skeleton } from "@/components/ui/states";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage } from "@/lib/client/api";
import { useMe } from "@/lib/client/hooks";
import type { DashboardResponse } from "@/lib/types";
import { formatDateTime, formatPct, formatRelative } from "@/lib/utils";

const ACTIVITY_LABELS: Record<string, string> = {
  calculation_saved: "Saved a calculation",
  opportunity_viewed: "Viewed opportunity",
  watchlist_added: "Added to watchlist",
  watchlist_removed: "Removed from watchlist",
  alert_rule_created: "Created alert rule",
  bookmaker_enabled: "Enabled bookmaker",
  bookmaker_disabled: "Disabled bookmaker",
  export_csv: "Exported CSV",
  trial_started: "Started Premium trial",
};

export default function DashboardPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe();
  const dashboard = useQuery({ queryKey: ["dashboard"], queryFn: () => api<DashboardResponse>("/api/dashboard"), refetchInterval: 60_000 });
  const refresh = useMutation({
    mutationFn: () => api<{ result: { skipped: boolean; reason?: string; error?: string; nextAllowedAt?: string } }>("/api/scan/refresh", { method: "POST" }),
    onSuccess: ({ result }) => {
      if (result.error) toast.error("Refresh failed", result.error);
      else if (result.skipped) toast.info("Data is already fresh", result.nextAllowedAt ? `Next provider refresh ${formatRelative(result.nextAllowedAt)}.` : undefined);
      else toast.success("Odds refreshed");
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
      void qc.invalidateQueries({ queryKey: ["opportunities"] });
    },
    onError: (err) => toast.error("Refresh failed", errorMessage(err)),
  });

  const data = dashboard.data;
  const prefs = me.data?.preferences;
  const widgets = data?.widgets ?? ["opportunities", "margin", "bookmakers", "activity", "subscription"];

  return (
    <div className="space-y-5">
      <PageHeader
        title={`Hello, ${me.data?.user.displayName.split(" ")[0] ?? "there"}`}
        description="Your arbitrage workspace at a glance. All figures are theoretical and depend on current odds and limits."
        action={
          <>
            <Button variant="outline" size="sm" loading={refresh.isPending} onClick={() => refresh.mutate()}>
              <RefreshCw className="h-4 w-4" /> Refresh odds
            </Button>
            <LinkButton href="/app/scanner" size="sm">
              <Zap className="h-4 w-4" /> Open scanner
            </LinkButton>
          </>
        }
      />

      {dashboard.isError ? (
        <ErrorState error={dashboard.error} onRetry={() => dashboard.refetch()} />
      ) : !data ? (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
          <ListSkeleton count={3} />
        </>
      ) : (
        <>
          <StaleDataBanner provider={data.provider} />

          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <StatCard label="Active opportunities" value={data.stats.activeOpportunities} hint={`${data.stats.expiredLast24h} expired in 24h`} icon={<Target className="h-4 w-4" />} tone="profit" />
            <StatCard label="Average margin" value={formatPct(data.stats.averageMarginPct)} hint={`Best ${formatPct(data.stats.bestMarginPct)}`} icon={<Percent className="h-4 w-4" />} />
            <StatCard label="My bookmakers" value={`${data.stats.savedBookmakers}/${data.stats.totalBookmakers}`} hint="Marked as available" icon={<Building2 className="h-4 w-4" />} />
            <StatCard label="Watchlist" value={data.stats.watchlistCount} hint={`${data.stats.unreadNotifications} unread alerts`} icon={<Bookmark className="h-4 w-4" />} tone="info" />
          </div>

          <div className="grid gap-4 lg:grid-cols-3">
            <Card className="lg:col-span-2">
              <CardHeader title="Data source" description={data.provider.isDemo ? "Seeded demo data — connect a licensed provider for real markets." : data.provider.name} action={<Badge variant={data.provider.isDemo ? "info" : "profit"}>{data.provider.isDemo ? "DEMO" : "LIVE"}</Badge>} />
              <CardContent className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
                <Info label="Last updated" value={data.provider.lastSuccessAt ? formatRelative(data.provider.lastSuccessAt) : "never"} />
                <Info label="Next refresh" value={data.provider.nextRefreshAt ? formatRelative(data.provider.nextRefreshAt) : "—"} />
                <Info label="Interval" value={`${Math.round(data.provider.intervalSec / 60)} min`} />
                <Info label="Status" value={data.provider.stale ? "Stale" : data.provider.lastStatus ?? "—"} tone={data.provider.stale ? "danger" : "profit"} />
              </CardContent>
            </Card>
            {widgets.includes("subscription") && (
              <Card>
                <CardHeader title="Subscription" action={<Crown className={`h-4 w-4 ${data.entitlements.plan === "premium" ? "text-warning" : "text-muted"}`} />} />
                <CardContent>
                  <p className="text-lg font-semibold">{data.entitlements.planName}</p>
                  <p className="text-xs text-muted">
                    {data.entitlements.isTrial ? "Trial" : data.entitlements.status}
                    {data.entitlements.periodEnd ? ` · until ${formatDateTime(data.entitlements.periodEnd)}` : ""}
                  </p>
                  <LinkButton href="/app/settings?tab=subscription" variant={data.entitlements.plan === "premium" ? "outline" : "primary"} size="sm" className="mt-3">
                    {data.entitlements.plan === "premium" ? "Manage plan" : "Upgrade to Premium"}
                  </LinkButton>
                </CardContent>
              </Card>
            )}
          </div>

          {widgets.includes("opportunities") && (
            <section>
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-base font-semibold">Top opportunities</h2>
                <Link href="/app/scanner" className="text-sm font-medium text-primary hover:underline">
                  View all
                </Link>
              </div>
              {data.topOpportunities.length === 0 ? (
                <EmptyState title="No active opportunities" description="The scanner refreshes automatically. Lower your minimum margin or check back after the next provider update." action={<Button variant="outline" size="sm" onClick={() => refresh.mutate()}>Refresh now</Button>} />
              ) : (
                <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                  {data.topOpportunities.map((o) => (
                    <OpportunityCard key={o.id} opportunity={o} stake={prefs?.defaultStake ?? 100} currency={prefs?.currency ?? "EUR"} />
                  ))}
                </div>
              )}
            </section>
          )}

          <div className="grid gap-4 lg:grid-cols-2">
            {widgets.includes("activity") && (
              <Card>
                <CardHeader title="Recent activity" action={<Activity className="h-4 w-4 text-muted" />} />
                <CardContent>
                  {data.recentActivity.length === 0 ? (
                    <p className="text-sm text-muted">Nothing yet. Calculations, watchlist changes and exports will show up here.</p>
                  ) : (
                    <ul className="divide-y divide-border text-sm">
                      {data.recentActivity.map((a) => (
                        <li key={a.id} className="flex items-center justify-between gap-3 py-2">
                          <span className="truncate">
                            {ACTIVITY_LABELS[a.action] ?? a.action}
                            {typeof a.metadata.title === "string" && <span className="text-muted"> · {a.metadata.title}</span>}
                            {typeof a.metadata.name === "string" && <span className="text-muted"> · {a.metadata.name}</span>}
                          </span>
                          <time className="shrink-0 text-xs text-muted">{formatRelative(a.createdAt)}</time>
                        </li>
                      ))}
                    </ul>
                  )}
                </CardContent>
              </Card>
            )}
            <Card>
              <CardHeader title="Latest alerts" action={<Link href="/app/alerts" className="text-xs font-medium text-primary hover:underline"><Bell className="mr-1 inline h-3.5 w-3.5" />Inbox</Link>} />
              <CardContent>
                {data.recentNotifications.length === 0 ? (
                  <p className="text-sm text-muted">No alerts yet. Create a rule to get notified about new opportunities.</p>
                ) : (
                  <ul className="divide-y divide-border text-sm">
                    {data.recentNotifications.map((n) => (
                      <li key={n.id} className="py-2">
                        <Link href={n.opportunityId ? `/app/opportunities/${n.opportunityId}` : "/app/alerts"} className="block hover:underline">
                          <span className={n.readAt ? "text-muted" : "font-medium"}>{n.title}</span>
                        </Link>
                        <p className="text-xs text-muted">{formatRelative(n.createdAt)}</p>
                      </li>
                    ))}
                  </ul>
                )}
              </CardContent>
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function Info({ label, value, tone }: { label: string; value: string; tone?: "danger" | "profit" }) {
  return (
    <div>
      <p className="text-[11px] uppercase tracking-wide text-muted">{label}</p>
      <p className={`mt-0.5 font-medium capitalize ${tone === "danger" ? "text-danger" : tone === "profit" ? "text-profit" : ""}`}>{value}</p>
    </div>
  );
}
