"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Crown, Filter, Lock, RefreshCw, Save, Search, X } from "lucide-react";
import Link from "next/link";
import { useMemo, useState } from "react";
import { StaleDataBanner } from "@/components/banners";
import { OpportunityCard } from "@/components/opportunity/opportunity-card";
import { Badge } from "@/components/ui/badge";
import { Button, LinkButton } from "@/components/ui/button";
import { Card, CardContent, CardHeader, PageHeader } from "@/components/ui/card";
import { Checkbox, Chip, Field, Input, Select } from "@/components/ui/input";
import { EmptyState, ErrorState, InlineAlert, ListSkeleton } from "@/components/ui/states";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage, isPlanError } from "@/lib/client/api";
import { useMe } from "@/lib/client/hooks";
import type { OpportunityListResponse, SavedFilterDTO } from "@/lib/types";
import { formatRelative } from "@/lib/utils";
import type { SortOption } from "@/lib/validation";

interface Filters {
  q: string;
  sports: string[];
  markets: string[];
  leagues: string[];
  bookmakers: string[];
  countries: string[];
  minMargin: string;
  minNetProfit: string;
  minOdds: string;
  maxOdds: string;
  startsWithinHours: string;
  outcomeCount: string;
  freshness: "any" | "fresh" | "aging";
  sort: SortOption;
  dir: "asc" | "desc";
}

const DEFAULT_FILTERS: Filters = {
  q: "",
  sports: [],
  markets: [],
  leagues: [],
  bookmakers: [],
  countries: [],
  minMargin: "",
  minNetProfit: "",
  minOdds: "",
  maxOdds: "",
  startsWithinHours: "",
  outcomeCount: "",
  freshness: "any",
  sort: "margin",
  dir: "desc",
};

const MARKET_LABELS: Record<string, string> = { h2h: "Match winner / 1X2", totals: "Totals", spreads: "Handicap" };

function toQuery(f: Filters, stake: number): string {
  const p = new URLSearchParams();
  if (f.q) p.set("q", f.q);
  for (const k of ["sports", "markets", "leagues", "bookmakers", "countries"] as const) if (f[k].length) p.set(k, f[k].join(","));
  for (const k of ["minMargin", "minNetProfit", "minOdds", "maxOdds", "startsWithinHours", "outcomeCount"] as const) if (f[k] !== "") p.set(k, f[k]);
  if (f.freshness !== "any") p.set("freshness", f.freshness);
  p.set("sort", f.sort);
  p.set("dir", f.dir);
  p.set("stake", String(stake));
  return p.toString();
}

export default function ScannerPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe();
  const [filters, setFilters] = useState<Filters>(DEFAULT_FILTERS);
  const [showFilters, setShowFilters] = useState(false);
  const [saveName, setSaveName] = useState("");
  const stake = me.data?.preferences.defaultStake ?? 100;
  const currency = me.data?.preferences.currency ?? "EUR";
  const premium = me.data?.entitlements.limits.advancedFilters ?? false;
  const qs = useMemo(() => toQuery(filters, stake), [filters, stake]);

  const list = useQuery({
    queryKey: ["opportunities", qs],
    queryFn: () => api<OpportunityListResponse>(`/api/opportunities?${qs}`),
    refetchInterval: 60_000,
    placeholderData: (prev) => prev,
  });
  const saved = useQuery({ queryKey: ["saved-filters"], queryFn: () => api<{ items: SavedFilterDTO[]; limit: number }>("/api/saved-filters") });

  const refresh = useMutation({
    mutationFn: () => api<{ result: { skipped: boolean; error?: string; nextAllowedAt?: string } }>("/api/scan/refresh", { method: "POST" }),
    onSuccess: ({ result }) => {
      if (result.error) toast.error("Refresh failed", result.error);
      else if (result.skipped) toast.info("Already up to date", result.nextAllowedAt ? `Provider refresh allowed ${formatRelative(result.nextAllowedAt)} (respecting provider terms).` : undefined);
      else toast.success("Odds refreshed");
      void qc.invalidateQueries({ queryKey: ["opportunities"] });
    },
    onError: (err) => toast.error("Refresh failed", errorMessage(err)),
  });

  const saveFilter = useMutation({
    mutationFn: () => api<SavedFilterDTO>("/api/saved-filters", { method: "POST", json: { name: saveName.trim() || "My filter", filters } }),
    onSuccess: () => {
      toast.success("Filter saved");
      setSaveName("");
      void qc.invalidateQueries({ queryKey: ["saved-filters"] });
    },
    onError: (err) => toast.error(isPlanError(err) ? "Plan limit reached" : "Could not save filter", errorMessage(err)),
  });
  const deleteFilter = useMutation({
    mutationFn: (id: string) => api(`/api/saved-filters/${id}`, { method: "DELETE" }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["saved-filters"] }),
  });

  const data = list.data;
  const facets = data?.facets;
  const toggle = (key: "sports" | "markets" | "leagues" | "bookmakers" | "countries", value: string) =>
    setFilters((f) => ({ ...f, [key]: f[key].includes(value) ? f[key].filter((v) => v !== value) : [...f[key], value] }));
  const activeCount = [filters.sports, filters.markets, filters.leagues, filters.bookmakers, filters.countries].reduce((a, l) => a + l.length, 0) + ["minMargin", "minNetProfit", "minOdds", "maxOdds", "startsWithinHours", "outcomeCount"].filter((k) => filters[k as keyof Filters] !== "").length + (filters.freshness !== "any" ? 1 : 0);

  return (
    <div className="space-y-4">
      <PageHeader
        title="Live scanner"
        description={data ? `${data.total} theoretical opportunit${data.total === 1 ? "y" : "ies"} · data ${data.provider.lastSuccessAt ? formatRelative(data.provider.lastSuccessAt) : "pending"} · auto-refresh every minute` : "Searchable, filterable opportunities ranked by margin."}
        action={
          <>
            <Button variant="outline" size="sm" onClick={() => setShowFilters((s) => !s)} aria-expanded={showFilters}>
              <Filter className="h-4 w-4" /> Filters {activeCount > 0 && <Badge variant="primary">{activeCount}</Badge>}
            </Button>
            <Button size="sm" loading={refresh.isPending} onClick={() => refresh.mutate()}>
              <RefreshCw className="h-4 w-4" /> Refresh
            </Button>
          </>
        }
      />

      {data && <StaleDataBanner provider={data.provider} />}

      <div className="flex flex-col gap-2 sm:flex-row">
        <div className="relative flex-1">
          <Search className="pointer-events-none absolute top-1/2 left-3 h-4 w-4 -translate-y-1/2 text-muted" />
          <Input value={filters.q} onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))} placeholder="Search teams or leagues" className="pl-9" aria-label="Search" />
          {filters.q && (
            <button type="button" onClick={() => setFilters((f) => ({ ...f, q: "" }))} className="absolute top-1/2 right-2 -translate-y-1/2 text-muted" aria-label="Clear search">
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <div className="flex gap-2">
          <Select value={filters.sort} onChange={(e) => setFilters((f) => ({ ...f, sort: e.target.value as SortOption }))} aria-label="Sort by" className="w-40">
            <option value="margin">Sort: margin</option>
            <option value="profit">Sort: est. profit</option>
            <option value="event_time">Sort: event time</option>
            <option value="updated">Sort: updated</option>
          </Select>
          <Select value={filters.dir} onChange={(e) => setFilters((f) => ({ ...f, dir: e.target.value as "asc" | "desc" }))} aria-label="Direction" className="w-24">
            <option value="desc">Desc</option>
            <option value="asc">Asc</option>
          </Select>
        </div>
      </div>

      <div className="scrollbar-thin flex gap-2 overflow-x-auto pb-1">
        <Chip active={filters.sports.length === 0} onClick={() => setFilters((f) => ({ ...f, sports: [] }))}>
          All sports
        </Chip>
        {facets?.sports.map((s) => (
          <Chip key={s.key} active={filters.sports.includes(s.key)} onClick={() => toggle("sports", s.key)}>
            {s.title}
          </Chip>
        ))}
        <span className="mx-1 w-px shrink-0 bg-border" />
        {(facets?.markets.length ? facets.markets : ["h2h", "totals"]).map((m) => (
          <Chip key={m} active={filters.markets.includes(m)} onClick={() => toggle("markets", m)}>
            {MARKET_LABELS[m] ?? m}
          </Chip>
        ))}
        <span className="mx-1 w-px shrink-0 bg-border" />
        {["0.5", "1", "2"].map((m) => (
          <Chip key={m} active={filters.minMargin === m} onClick={() => setFilters((f) => ({ ...f, minMargin: f.minMargin === m ? "" : m }))}>
            ≥ {m}%
          </Chip>
        ))}
      </div>

      {showFilters && (
        <Card>
          <CardHeader
            title="Filters"
            description="Bookmaker and league filters require every leg to match."
            action={
              <Button variant="ghost" size="sm" onClick={() => setFilters({ ...DEFAULT_FILTERS, q: filters.q })}>
                Reset
              </Button>
            }
          />
          <CardContent className="space-y-5">
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Field label="Min margin %">
                <Input type="number" inputMode="decimal" step="0.1" min="0" value={filters.minMargin} onChange={(e) => setFilters((f) => ({ ...f, minMargin: e.target.value }))} />
              </Field>
              <Field label={`Min net profit (${currency} @ ${stake})`}>
                <Input type="number" inputMode="decimal" step="0.5" min="0" value={filters.minNetProfit} onChange={(e) => setFilters((f) => ({ ...f, minNetProfit: e.target.value }))} />
              </Field>
              <Field label="Starts within">
                <Select value={filters.startsWithinHours} onChange={(e) => setFilters((f) => ({ ...f, startsWithinHours: e.target.value }))}>
                  <option value="">Any time</option>
                  <option value="3">3 hours</option>
                  <option value="12">12 hours</option>
                  <option value="24">24 hours</option>
                  <option value="72">3 days</option>
                </Select>
              </Field>
              <Field label="League">
                <Select value="" onChange={(e) => e.target.value && toggle("leagues", e.target.value)}>
                  <option value="">Add league…</option>
                  {facets?.leagues.filter((l) => !filters.leagues.includes(l)).map((l) => (
                    <option key={l} value={l}>
                      {l}
                    </option>
                  ))}
                </Select>
              </Field>
            </div>
            {filters.leagues.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {filters.leagues.map((l) => (
                  <Chip key={l} active onClick={() => toggle("leagues", l)}>
                    {l} ×
                  </Chip>
                ))}
              </div>
            )}

            <div>
              <p className="mb-2 text-xs font-medium text-muted">Bookmakers (all legs must use selected bookmakers)</p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 lg:grid-cols-4">
                {facets?.bookmakers.map((b) => (
                  <Checkbox key={b.key} checked={filters.bookmakers.includes(b.key)} onChange={() => toggle("bookmakers", b.key)} label={b.name} />
                ))}
              </div>
            </div>

            <div className={`rounded-xl border border-border p-4 ${premium ? "" : "opacity-80"}`}>
              <div className="mb-3 flex items-center justify-between">
                <p className="flex items-center gap-2 text-sm font-semibold">
                  <Crown className="h-4 w-4 text-warning" /> Advanced filters
                </p>
                {!premium && (
                  <Link href="/app/settings?tab=subscription" className="flex items-center gap-1 text-xs font-medium text-primary hover:underline">
                    <Lock className="h-3.5 w-3.5" /> Premium
                  </Link>
                )}
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Field label="Min odds">
                  <Input type="number" inputMode="decimal" step="0.05" min="1" disabled={!premium} value={filters.minOdds} onChange={(e) => setFilters((f) => ({ ...f, minOdds: e.target.value }))} />
                </Field>
                <Field label="Max odds">
                  <Input type="number" inputMode="decimal" step="0.05" min="1" disabled={!premium} value={filters.maxOdds} onChange={(e) => setFilters((f) => ({ ...f, maxOdds: e.target.value }))} />
                </Field>
                <Field label="Outcomes">
                  <Select disabled={!premium} value={filters.outcomeCount} onChange={(e) => setFilters((f) => ({ ...f, outcomeCount: e.target.value }))}>
                    <option value="">Any</option>
                    <option value="2">2-way</option>
                    <option value="3">3-way</option>
                  </Select>
                </Field>
                <Field label="Data freshness">
                  <Select disabled={!premium} value={filters.freshness} onChange={(e) => setFilters((f) => ({ ...f, freshness: e.target.value as Filters["freshness"] }))}>
                    <option value="any">Any</option>
                    <option value="fresh">Fresh only (&lt; 3 min)</option>
                    <option value="aging">Fresh or aging (&lt; 15 min)</option>
                  </Select>
                </Field>
              </div>
              <div className="mt-3">
                <p className="mb-2 text-xs font-medium text-muted">Bookmaker country</p>
                <div className="flex flex-wrap gap-2">
                  {facets?.countries.map((c) => (
                    <Chip key={c} active={filters.countries.includes(c)} onClick={() => premium && toggle("countries", c)}>
                      {c}
                    </Chip>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex flex-col gap-2 border-t border-border pt-4 sm:flex-row sm:items-end">
              <Field label="Saved filters" className="flex-1">
                <div className="flex flex-wrap gap-2">
                  {saved.data?.items.length ? (
                    saved.data.items.map((s) => (
                      <span key={s.id} className="inline-flex items-center overflow-hidden rounded-full border border-border text-xs">
                        <button type="button" className="px-3 py-1.5 hover:bg-surface-2" onClick={() => setFilters({ ...DEFAULT_FILTERS, ...(s.filters as Partial<Filters>) })}>
                          {s.name}
                        </button>
                        <button type="button" className="border-l border-border px-2 py-1.5 text-muted hover:text-danger" onClick={() => deleteFilter.mutate(s.id)} aria-label={`Delete ${s.name}`}>
                          <X className="h-3 w-3" />
                        </button>
                      </span>
                    ))
                  ) : (
                    <span className="text-xs text-muted">None saved yet ({saved.data?.limit ?? 1} allowed on your plan).</span>
                  )}
                </div>
              </Field>
              <div className="flex gap-2">
                <Input value={saveName} onChange={(e) => setSaveName(e.target.value)} placeholder="Filter name" className="w-40" aria-label="Filter name" />
                <Button variant="secondary" size="md" loading={saveFilter.isPending} onClick={() => saveFilter.mutate()}>
                  <Save className="h-4 w-4" /> Save
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {data && !data.advancedFiltersApplied && (
        <InlineAlert tone="warning">
          Advanced filters (odds range, outcomes, freshness, country) are a Premium feature and were not applied.{" "}
          <Link href="/app/settings?tab=subscription" className="font-medium underline">
            Upgrade
          </Link>
        </InlineAlert>
      )}

      {list.isError ? (
        <ErrorState error={list.error} onRetry={() => list.refetch()} />
      ) : !data ? (
        <ListSkeleton count={6} />
      ) : data.items.length === 0 ? (
        <EmptyState
          title={data.total === 0 && activeCount === 0 && !filters.q ? "No active opportunities right now" : "No opportunities match your filters"}
          description={data.total === 0 && activeCount === 0 ? "Opportunities appear when the best available prices across bookmakers imply a total probability below 100%. Try refreshing or wait for the next provider update." : "Loosen the margin, bookmaker or league filters to see more."}
          action={
            activeCount > 0 || filters.q ? (
              <Button variant="outline" size="sm" onClick={() => setFilters(DEFAULT_FILTERS)}>
                Clear filters
              </Button>
            ) : (
              <Button variant="outline" size="sm" loading={refresh.isPending} onClick={() => refresh.mutate()}>
                Refresh now
              </Button>
            )
          }
        />
      ) : (
        <>
          <div className={`grid gap-3 md:grid-cols-2 xl:grid-cols-3 ${list.isFetching ? "opacity-80" : ""}`}>
            {data.items.map((o) => (
              <OpportunityCard key={o.id} opportunity={o} stake={stake} currency={currency} />
            ))}
          </div>
          {data.limited && (
            <Card className="border-primary/40 bg-primary/5">
              <CardContent className="flex flex-col items-start gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <p className="text-sm font-semibold">Showing {data.items.length} of {data.total} opportunities</p>
                  <p className="text-xs text-muted">The Free plan shows the top {data.limit}. Premium unlocks the full scanner, advanced filters and exports.</p>
                </div>
                <LinkButton href="/app/settings?tab=subscription" size="sm">
                  <Crown className="h-4 w-4" /> See Premium
                </LinkButton>
              </CardContent>
            </Card>
          )}
        </>
      )}
    </div>
  );
}
