"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Check, Crown, KeyRound, LogOut, Smartphone, Trash2 } from "lucide-react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useState } from "react";
import { useForm } from "react-hook-form";
import { useTheme } from "@/components/theme";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, PageHeader } from "@/components/ui/card";
import { Checkbox, Field, Input, Select, Switch } from "@/components/ui/input";
import { CardSkeleton, InlineAlert } from "@/components/ui/states";
import { Tabs } from "@/components/ui/tabs";
import { useToast } from "@/components/ui/toast";
import { PLANS, type PlanLimits } from "@/lib/plans";
import { api, errorMessage } from "@/lib/client/api";
import { useLogout, useMe } from "@/lib/client/hooks";
import type { EntitlementsDTO, MeResponse, SessionDTO } from "@/lib/types";
import { formatDateTime, formatRelative } from "@/lib/utils";
import { changePasswordSchema, preferencesSchema, profileSchema, type ChangePasswordInput, type PreferencesInput, type ProfileInput } from "@/lib/validation";

type Tab = "profile" | "preferences" | "security" | "subscription" | "help" | "responsible";
const TABS: { value: Tab; label: string }[] = [
  { value: "profile", label: "Profile" },
  { value: "preferences", label: "Preferences" },
  { value: "security", label: "Security" },
  { value: "subscription", label: "Subscription" },
  { value: "help", label: "Help" },
  { value: "responsible", label: "Responsible use" },
];

function SettingsInner() {
  const params = useSearchParams();
  const router = useRouter();
  const me = useMe();
  const tabParam = params.get("tab") as Tab | null;
  const tab: Tab = TABS.some((t) => t.value === tabParam) ? (tabParam as Tab) : "profile";
  const setTab = (t: Tab) => router.replace(`/app/settings?tab=${t}`);

  if (!me.data) return <CardSkeleton rows={5} />;
  return (
    <div className="space-y-4">
      <PageHeader title="Settings" description="Profile, trading preferences, security, subscription and support." />
      <Tabs items={TABS} value={tab} onChange={setTab} />
      {tab === "profile" && <ProfileTab me={me.data} />}
      {tab === "preferences" && <PreferencesTab me={me.data} />}
      {tab === "security" && <SecurityTab me={me.data} />}
      {tab === "subscription" && <SubscriptionTab />}
      {tab === "help" && <HelpTab />}
      {tab === "responsible" && <ResponsibleTab me={me.data} />}
    </div>
  );
}

export default function SettingsPage() {
  return (
    <Suspense fallback={<CardSkeleton rows={5} />}>
      <SettingsInner />
    </Suspense>
  );
}

function ProfileTab({ me }: { me: MeResponse }) {
  const qc = useQueryClient();
  const toast = useToast();
  const logout = useLogout();
  const form = useForm<ProfileInput>({ resolver: zodResolver(profileSchema), defaultValues: { displayName: me.user.displayName } });
  const save = useMutation({
    mutationFn: (v: ProfileInput) => api("/api/profile", { method: "PATCH", json: v }),
    onSuccess: () => {
      toast.success("Profile updated");
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err) => toast.error("Could not save", errorMessage(err)),
  });
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="Profile" />
        <CardContent>
          <form className="space-y-4" onSubmit={form.handleSubmit((v) => save.mutate(v))} noValidate>
            <Field label="Display name" htmlFor="displayName" error={form.formState.errors.displayName?.message}>
              <Input id="displayName" {...form.register("displayName")} />
            </Field>
            <Field label="E-mail">
              <div className="flex items-center gap-2">
                <Input value={me.user.email} readOnly disabled />
                <Badge variant={me.user.emailVerified ? "profit" : "warning"}>{me.user.emailVerified ? "Verified" : "Unverified"}</Badge>
              </div>
            </Field>
            <Button type="submit" loading={save.isPending}>
              Save changes
            </Button>
          </form>
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Account" description={`Member since ${formatDateTime(me.user.createdAt)} · role: ${me.user.role}`} />
        <CardContent className="space-y-3">
          <Button variant="outline" onClick={() => logout.mutate()} loading={logout.isPending}>
            <LogOut className="h-4 w-4" /> Sign out
          </Button>
          <p className="text-xs text-muted">To delete your account and all associated data, contact support from the Help tab. Deletion is processed within 30 days.</p>
        </CardContent>
      </Card>
    </div>
  );
}

const WIDGETS = [
  { key: "opportunities", label: "Top opportunities" },
  { key: "activity", label: "Recent activity" },
  { key: "subscription", label: "Subscription status" },
];
const SPORTS = ["soccer", "basketball", "tennis", "icehockey", "americanfootball"];
const MARKETS = ["h2h", "totals", "spreads"];

function PreferencesTab({ me }: { me: MeResponse }) {
  const qc = useQueryClient();
  const toast = useToast();
  const { setTheme } = useTheme();
  const p = me.preferences;
  const form = useForm<PreferencesInput>({
    resolver: zodResolver(preferencesSchema),
    defaultValues: { ...p, telegramChatId: p.telegramChatId ?? null },
  });
  const save = useMutation({
    mutationFn: (v: PreferencesInput) => api("/api/preferences", { method: "PATCH", json: v }),
    onSuccess: (_d, v) => {
      setTheme(v.theme);
      toast.success("Preferences saved");
      void qc.invalidateQueries({ queryKey: ["me"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (err) => toast.error("Could not save", errorMessage(err)),
  });
  const limits = me.entitlements.limits;
  const arr = (k: "preferredSports" | "preferredMarkets" | "dashboardWidgets") => form.watch(k);
  const toggle = (k: "preferredSports" | "preferredMarkets" | "dashboardWidgets", v: string) => {
    const cur = arr(k);
    form.setValue(k, cur.includes(v) ? cur.filter((x) => x !== v) : [...cur, v]);
  };
  const err = form.formState.errors;
  const num = (name: keyof PreferencesInput) => form.register(name, { valueAsNumber: true });

  return (
    <form onSubmit={form.handleSubmit((v) => save.mutate(v))} noValidate className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="Calculator defaults" description="Used by the scanner's profit estimates and pre-filled in every calculator." />
        <CardContent className="grid grid-cols-2 gap-3">
          <Field label="Currency" error={err.currency?.message}>
            <Input maxLength={3} {...form.register("currency")} className="uppercase" />
          </Field>
          <Field label="Default stake" error={err.defaultStake?.message}>
            <Input type="number" min="1" step="1" {...num("defaultStake")} />
          </Field>
          <Field label="Commission %" error={err.defaultCommissionPct?.message}>
            <Input type="number" min="0" step="0.1" {...num("defaultCommissionPct")} />
          </Field>
          <Field label="FX / payment %" error={err.defaultFxPct?.message}>
            <Input type="number" min="0" step="0.1" {...num("defaultFxPct")} />
          </Field>
          <Field label="Fixed costs" error={err.defaultFixedCosts?.message}>
            <Input type="number" min="0" step="0.5" {...num("defaultFixedCosts")} />
          </Field>
          <Field label="Rounding step" hint="0 disables rounding" error={err.roundingStep?.message}>
            <Input type="number" min="0" step="0.5" {...num("roundingStep")} />
          </Field>
          <Field label="Default min margin %" error={err.minMarginPct?.message}>
            <Input type="number" min="0" step="0.1" {...num("minMarginPct")} />
          </Field>
          <Field label="Theme">
            <Select {...form.register("theme")}>
              <option value="system">System</option>
              <option value="dark">Dark</option>
              <option value="light">Light</option>
            </Select>
          </Field>
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Interests & dashboard" />
        <CardContent className="space-y-4">
          <div>
            <p className="mb-1.5 text-xs font-medium text-muted">Preferred sports</p>
            <div className="flex flex-wrap gap-3">
              {SPORTS.map((s) => (
                <Checkbox key={s} checked={arr("preferredSports").includes(s)} onChange={() => toggle("preferredSports", s)} label={s} />
              ))}
            </div>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-medium text-muted">Preferred markets</p>
            <div className="flex flex-wrap gap-3">
              {MARKETS.map((m) => (
                <Checkbox key={m} checked={arr("preferredMarkets").includes(m)} onChange={() => toggle("preferredMarkets", m)} label={m} />
              ))}
            </div>
          </div>
          <div>
            <p className="mb-1.5 flex items-center gap-1 text-xs font-medium text-muted">
              Dashboard widgets {!limits.dashboardCustomization && <Crown className="h-3 w-3 text-warning" />}
            </p>
            <div className="flex flex-wrap gap-3">
              {WIDGETS.map((w) => (
                <Checkbox key={w.key} disabled={!limits.dashboardCustomization} checked={arr("dashboardWidgets").includes(w.key)} onChange={() => toggle("dashboardWidgets", w.key)} label={w.label} />
              ))}
            </div>
          </div>
          <div className="space-y-2 border-t border-border pt-4">
            <p className="text-xs font-medium text-muted">External alert channels {!limits.externalChannels && "(Premium)"}</p>
            <Switch checked={form.watch("emailAlerts")} disabled={!limits.externalChannels || !me.config.emailDelivery} onChange={(v) => form.setValue("emailAlerts", v)} label={`E-mail alerts${me.config.emailDelivery ? "" : " — not configured on this server"}`} />
            <Switch checked={form.watch("telegramAlerts")} disabled={!limits.externalChannels || !me.config.telegram} onChange={(v) => form.setValue("telegramAlerts", v)} label={`Telegram alerts${me.config.telegram ? "" : " — not configured on this server"}`} />
            <Field label="Telegram chat ID" error={err.telegramChatId?.message}>
              <Input disabled={!me.config.telegram} {...form.register("telegramChatId", { setValueAs: (v) => (typeof v === "string" && v.trim() === "" ? null : v) })} placeholder="e.g. 123456789" />
            </Field>
          </div>
          <Button type="submit" loading={save.isPending}>
            Save preferences
          </Button>
        </CardContent>
      </Card>
    </form>
  );
}

function SecurityTab({ me }: { me: MeResponse }) {
  const qc = useQueryClient();
  const toast = useToast();
  const pw = useForm<ChangePasswordInput>({ resolver: zodResolver(changePasswordSchema), defaultValues: { currentPassword: "", newPassword: "", confirmPassword: "" } });
  const changePw = useMutation({
    mutationFn: (v: ChangePasswordInput) => api("/api/auth/change-password", { method: "POST", json: v }),
    onSuccess: () => {
      toast.success("Password changed", "Other sessions were signed out.");
      pw.reset();
      void qc.invalidateQueries({ queryKey: ["sessions"] });
    },
    onError: (err) => toast.error("Could not change password", errorMessage(err)),
  });

  const [setup, setSetup] = useState<{ secret: string; otpauthUrl: string; qrDataUrl: string } | null>(null);
  const [code, setCode] = useState("");
  const [disablePw, setDisablePw] = useState("");
  const startSetup = useMutation({
    mutationFn: () => api<{ secret: string; otpauthUrl: string; qrDataUrl: string }>("/api/auth/mfa/setup", { method: "POST" }),
    onSuccess: setSetup,
    onError: (err) => toast.error("Could not start setup", errorMessage(err)),
  });
  const enable = useMutation({
    mutationFn: () => api("/api/auth/mfa/enable", { method: "POST", json: { code } }),
    onSuccess: () => {
      toast.success("Two-factor authentication enabled");
      setSetup(null);
      setCode("");
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err) => toast.error("Invalid code", errorMessage(err)),
  });
  const disable = useMutation({
    mutationFn: () => api("/api/auth/mfa/disable", { method: "POST", json: { password: disablePw, code } }),
    onSuccess: () => {
      toast.success("Two-factor authentication disabled");
      setCode("");
      setDisablePw("");
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err) => toast.error("Could not disable", errorMessage(err)),
  });

  const sessions = useQuery({ queryKey: ["sessions"], queryFn: () => api<{ sessions: SessionDTO[] }>("/api/auth/sessions") });
  const revoke = useMutation({
    mutationFn: (id: string) => api(`/api/auth/sessions/${id}`, { method: "DELETE" }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["sessions"] }),
  });

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="Change password" description="Passwords are stored as salted scrypt hashes." />
        <CardContent>
          <form className="space-y-3" onSubmit={pw.handleSubmit((v) => changePw.mutate(v))} noValidate>
            <Field label="Current password" error={pw.formState.errors.currentPassword?.message}>
              <Input type="password" autoComplete="current-password" {...pw.register("currentPassword")} />
            </Field>
            <Field label="New password" error={pw.formState.errors.newPassword?.message}>
              <Input type="password" autoComplete="new-password" {...pw.register("newPassword")} />
            </Field>
            <Field label="Confirm new password" error={pw.formState.errors.confirmPassword?.message}>
              <Input type="password" autoComplete="new-password" {...pw.register("confirmPassword")} />
            </Field>
            <Button type="submit" loading={changePw.isPending}>
              <KeyRound className="h-4 w-4" /> Update password
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader title="Two-factor authentication" description="Time-based one-time codes (TOTP) from any authenticator app." action={<Badge variant={me.user.mfaEnabled ? "profit" : "outline"}>{me.user.mfaEnabled ? "Enabled" : "Off"}</Badge>} />
        <CardContent className="space-y-3">
          {me.user.mfaEnabled ? (
            <>
              <Field label="Password">
                <Input type="password" value={disablePw} onChange={(e) => setDisablePw(e.target.value)} autoComplete="current-password" />
              </Field>
              <Field label="Authenticator code">
                <Input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} className="font-mono" />
              </Field>
              <Button variant="danger" loading={disable.isPending} disabled={code.length !== 6 || !disablePw} onClick={() => disable.mutate()}>
                Disable 2FA
              </Button>
            </>
          ) : setup ? (
            <>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={setup.qrDataUrl} alt="Scan this QR code with your authenticator app" className="mx-auto h-44 w-44 rounded-xl bg-white p-2" />
              <p className="text-center text-xs text-muted">
                Or enter the key manually: <span className="font-mono break-all select-all">{setup.secret}</span>
              </p>
              <Field label="Enter the 6-digit code to confirm">
                <Input inputMode="numeric" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/\D/g, ""))} className="font-mono" autoFocus />
              </Field>
              <div className="flex gap-2">
                <Button loading={enable.isPending} disabled={code.length !== 6} onClick={() => enable.mutate()}>
                  <Check className="h-4 w-4" /> Enable 2FA
                </Button>
                <Button variant="ghost" onClick={() => setSetup(null)}>
                  Cancel
                </Button>
              </div>
            </>
          ) : (
            <>
              <p className="text-sm text-muted">Add a second factor to protect your account. Keep a backup of the setup key — an administrator can reset 2FA if you lose access.</p>
              <Button variant="outline" loading={startSetup.isPending} onClick={() => startSetup.mutate()}>
                <Smartphone className="h-4 w-4" /> Set up authenticator app
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader title="Active sessions" description="Sign out devices you do not recognise." />
        <CardContent className="p-0">
          <ul className="divide-y divide-border text-sm">
            {sessions.data?.sessions.map((s) => (
              <li key={s.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <p className="truncate font-medium">
                    {s.userAgent ? s.userAgent.split(") ")[0].replace("(", "· ").slice(0, 80) : "Unknown device"} {s.current && <Badge variant="profit">This device</Badge>}
                  </p>
                  <p className="text-xs text-muted">
                    IP {s.ip ?? "—"} · last active {formatRelative(s.lastSeenAt)} · expires {formatDateTime(s.expiresAt)}
                  </p>
                </div>
                {!s.current && (
                  <Button variant="ghost" size="sm" onClick={() => revoke.mutate(s.id)} aria-label="Revoke session">
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

const FEATURE_ROWS: { label: string; get: (l: PlanLimits) => string }[] = [
  { label: "Scanner results", get: (l) => (l.scannerLimit === null ? "Unlimited" : `Top ${l.scannerLimit}`) },
  { label: "Advanced filters", get: (l) => (l.advancedFilters ? "Yes" : "—") },
  { label: "Alert rules", get: (l) => String(l.maxAlertRules) },
  { label: "E-mail / Telegram alerts", get: (l) => (l.externalChannels ? "Yes (when configured)" : "—") },
  { label: "Watchlist size", get: (l) => String(l.maxWatchlist) },
  { label: "Saved filters", get: (l) => String(l.maxSavedFilters) },
  { label: "History retention", get: (l) => `${l.historyDays} days` },
  { label: "CSV export", get: (l) => (l.csvExport ? "Yes" : "—") },
  { label: "Parallel calculators", get: (l) => String(l.maxCalculators) },
  { label: "Dashboard customisation", get: (l) => (l.dashboardCustomization ? "Yes" : "—") },
];

function SubscriptionTab() {
  const qc = useQueryClient();
  const toast = useToast();
  const sub = useQuery({ queryKey: ["subscription"], queryFn: () => api<{ entitlements: EntitlementsDTO; trialDays: number; trialEnabled: boolean; paymentsEnabled: boolean }>("/api/subscription") });
  const act = useMutation({
    mutationFn: (action: "start_trial" | "cancel" | "resume" | "checkout") => api("/api/subscription", { method: "POST", json: { action } }),
    onSuccess: (_d, action) => {
      toast.success(action === "start_trial" ? "Premium trial activated" : action === "cancel" ? "Cancellation scheduled" : "Subscription resumed");
      void qc.invalidateQueries({ queryKey: ["subscription"] });
      void qc.invalidateQueries({ queryKey: ["me"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (err) => toast.error("Not available", errorMessage(err)),
  });
  if (!sub.data) return <CardSkeleton rows={4} />;
  const e = sub.data.entitlements;
  return (
    <div className="space-y-4">
      <Card>
        <CardHeader title="Current plan" action={<Badge variant={e.plan === "premium" ? "profit" : "outline"}>{e.planName}</Badge>} />
        <CardContent className="space-y-3 text-sm">
          <p className="text-muted">
            Status: <span className="font-medium text-fg capitalize">{e.status}</span>
            {e.periodEnd && ` · ${e.cancelAtPeriodEnd ? "ends" : "renews"} ${formatDateTime(e.periodEnd)}`}
            {e.source === "admin" && " · staff entitlement"}
          </p>
          <div className="flex flex-wrap gap-2">
            {e.plan === "free" && e.trialEligible && sub.data.trialEnabled && (
              <Button loading={act.isPending} onClick={() => act.mutate("start_trial")}>
                <Crown className="h-4 w-4" /> Start {sub.data.trialDays}-day Premium trial
              </Button>
            )}
            {e.plan === "free" && (
              <Button variant="outline" loading={act.isPending} onClick={() => act.mutate("checkout")} title={sub.data.paymentsEnabled ? "" : "Payments are not configured yet"}>
                Subscribe ({PLANS.premium.priceLabel})
              </Button>
            )}
            {e.plan === "premium" && e.source === "subscription" && !e.cancelAtPeriodEnd && (
              <Button variant="outline" loading={act.isPending} onClick={() => act.mutate("cancel")}>
                Cancel at period end
              </Button>
            )}
            {e.plan === "premium" && e.source === "subscription" && e.cancelAtPeriodEnd && (
              <Button loading={act.isPending} onClick={() => act.mutate("resume")}>
                Keep Premium
              </Button>
            )}
          </div>
          {!sub.data.paymentsEnabled && <InlineAlert tone="info">Online payments are not enabled in this deployment. A payment provider will be integrated only after its availability and legal requirements are verified. Premium can be granted by an administrator or via the trial.</InlineAlert>}
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Compare plans" />
        <CardContent className="p-0">
          <table className="w-full text-sm">
            <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
              <tr>
                <th className="px-4 py-2 text-left font-medium">Feature</th>
                <th className="px-4 py-2 text-right font-medium">Free</th>
                <th className="px-4 py-2 text-right font-medium">Premium</th>
              </tr>
            </thead>
            <tbody>
              {FEATURE_ROWS.map((r) => (
                <tr key={r.label} className="border-t border-border">
                  <td className="px-4 py-2">{r.label}</td>
                  <td className="px-4 py-2 text-right text-muted">{r.get(PLANS.free.limits)}</td>
                  <td className="px-4 py-2 text-right font-medium text-profit">{r.get(PLANS.premium.limits)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </CardContent>
      </Card>
    </div>
  );
}

const FAQ = [
  ["What is a theoretical arbitrage?", "When the best available decimal odds for every outcome of a market imply a combined probability below 100% (S = Σ 1/oᵢ < 1). The margin is (1 − S) × 100%. It is theoretical because odds move, stakes get limited and bets can be voided."],
  ["How are stakes allocated?", "Each stake is proportional to the implied probability of its outcome: stakeᵢ = T × (1/oᵢ) / S. This equalises the gross return across outcomes before rounding."],
  ["Why is my net profit lower than the margin suggests?", "Commission (exchanges), currency conversion, payment fees and rounding all reduce the worst-case return. Configure them in Preferences so estimates reflect your real costs."],
  ["What does the freshness indicator mean?", "Fresh: odds updated under 3 minutes ago. Aging: under 15 minutes. Stale: older than that, or the provider has not refreshed recently — always re-check at the bookmaker."],
  ["Where does the data come from?", "A licensed odds provider through a server-side adapter. Without provider credentials the app runs on clearly-labelled demo data. We never scrape bookmaker sites."],
  ["Is profit guaranteed?", "No. This is an analysis tool. Execution risk, limits, voided bets, errors and timing all matter. Only stake what you can afford to lose."],
];

function HelpTab() {
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2">
        <CardHeader title="Frequently asked questions" />
        <CardContent className="divide-y divide-border p-0">
          {FAQ.map(([q, a]) => (
            <details key={q} className="group px-4 py-3">
              <summary className="cursor-pointer list-none text-sm font-medium marker:hidden">{q}</summary>
              <p className="mt-2 text-sm text-muted">{a}</p>
            </details>
          ))}
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Support" />
        <CardContent className="space-y-2 text-sm text-muted">
          <p>Questions, bugs or data issues? Reach us at <span className="font-medium text-fg">support@arbitragefinder.pro</span>.</p>
          <p>Include your account e-mail and, for odds issues, the opportunity link and timestamps shown on the details screen.</p>
          <p className="text-xs">Install the app: open the browser menu and choose “Add to Home screen” to use Arbitrage Finder Pro as a PWA on Android or desktop.</p>
        </CardContent>
      </Card>
    </div>
  );
}

function ResponsibleTab({ me }: { me: MeResponse }) {
  const qc = useQueryClient();
  const toast = useToast();
  const [checked, setChecked] = useState(() => Boolean(me.preferences.responsibleUseAckAt));
  const ack = useMutation({
    mutationFn: () => api("/api/profile", { method: "PATCH", json: { acknowledgeResponsibleUse: true } }),
    onSuccess: () => {
      toast.success("Thank you for acknowledging");
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
  });
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHeader title="Responsible use" />
        <CardContent className="space-y-3 text-sm text-muted">
          <p>Arbitrage Finder Pro provides analysis of publicly quoted odds. It does not place bets, hold funds or guarantee any outcome.</p>
          <ul className="list-disc space-y-1 pl-5">
            <li>Odds can change between the time an opportunity is shown and the time bets are placed.</li>
            <li>Bookmakers may limit stakes, void bets, or restrict accounts engaging in arbitrage.</li>
            <li>Only bet with money you can afford to lose and never chase losses.</li>
            <li>You are responsible for complying with the laws of your jurisdiction and bookmaker terms.</li>
          </ul>
          <Checkbox checked={checked} onChange={setChecked} label="I have read and understood this notice." />
          <Button disabled={!checked || Boolean(me.preferences.responsibleUseAckAt)} loading={ack.isPending} onClick={() => ack.mutate()}>
            {me.preferences.responsibleUseAckAt ? `Acknowledged ${formatDateTime(me.preferences.responsibleUseAckAt)}` : "Acknowledge"}
          </Button>
        </CardContent>
      </Card>
      <Card>
        <CardHeader title="Need help with gambling?" />
        <CardContent className="space-y-2 text-sm text-muted">
          <p>If betting stops being fun or feels out of control, support is available:</p>
          <ul className="space-y-1">
            <li>
              <a className="text-primary hover:underline" href="https://www.begambleaware.org" target="_blank" rel="noreferrer noopener">
                BeGambleAware (UK)
              </a>
            </li>
            <li>
              <a className="text-primary hover:underline" href="https://www.gamblersanonymous.org" target="_blank" rel="noreferrer noopener">
                Gamblers Anonymous
              </a>
            </li>
            <li>
              <a className="text-primary hover:underline" href="https://www.ncpgambling.org" target="_blank" rel="noreferrer noopener">
                National Council on Problem Gambling (US)
              </a>
            </li>
          </ul>
          <p className="text-xs">Many bookmakers also offer deposit limits, time-outs and self-exclusion tools.</p>
        </CardContent>
      </Card>
    </div>
  );
}
