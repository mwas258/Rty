"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bookmark, Trash2 } from "lucide-react";
import { OpportunityCard } from "@/components/opportunity/opportunity-card";
import { Button, LinkButton } from "@/components/ui/button";
import { PageHeader } from "@/components/ui/card";
import { EmptyState, ErrorState, ListSkeleton } from "@/components/ui/states";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage } from "@/lib/client/api";
import { useMe } from "@/lib/client/hooks";
import type { WatchlistItemDTO } from "@/lib/types";
import { formatPct, formatRelative } from "@/lib/utils";

export default function WatchlistPage() {
  const qc = useQueryClient();
  const toast = useToast();
  const me = useMe();
  const list = useQuery({ queryKey: ["watchlist"], queryFn: () => api<{ items: WatchlistItemDTO[]; limit: number }>("/api/watchlist"), refetchInterval: 60_000 });
  const remove = useMutation({
    mutationFn: (opportunityId: string) => api(`/api/watchlist/${opportunityId}`, { method: "DELETE" }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["watchlist"] });
      void qc.invalidateQueries({ queryKey: ["opportunities"] });
    },
    onError: (err) => toast.error("Could not remove", errorMessage(err)),
  });

  const items = list.data?.items ?? [];
  const active = items.filter((i) => i.opportunity.status === "active");
  const expired = items.filter((i) => i.opportunity.status !== "active");

  return (
    <div className="space-y-4">
      <PageHeader
        title="Watchlist"
        description={list.data ? `${items.length} of ${list.data.limit} saved opportunities · ${active.length} still active` : "Saved opportunities with their current status."}
        action={
          <LinkButton href="/app/scanner" size="sm" variant="outline">
            Find more
          </LinkButton>
        }
      />
      {list.isError ? (
        <ErrorState error={list.error} onRetry={() => list.refetch()} />
      ) : list.isLoading ? (
        <ListSkeleton />
      ) : items.length === 0 ? (
        <EmptyState icon={<Bookmark className="h-6 w-6" />} title="Nothing saved yet" description="Use the bookmark button on any opportunity to track it here. You will be alerted when a saved opportunity disappears." action={<LinkButton href="/app/scanner" size="sm">Open scanner</LinkButton>} />
      ) : (
        <>
          {[
            { title: "Active", rows: active },
            { title: "Expired", rows: expired },
          ].map(
            (group) =>
              group.rows.length > 0 && (
                <section key={group.title}>
                  <h2 className="mb-2 text-sm font-semibold text-muted">
                    {group.title} ({group.rows.length})
                  </h2>
                  <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
                    {group.rows.map((item) => (
                      <div key={item.id} className="flex flex-col gap-2">
                        <OpportunityCard opportunity={item.opportunity} stake={me.data?.preferences.defaultStake} currency={me.data?.preferences.currency} compact />
                        <div className="flex items-center justify-between rounded-xl border border-border bg-surface px-3 py-2 text-xs text-muted">
                          <span>
                            Saved {formatRelative(item.createdAt)} at {formatPct(item.marginAtSave)}
                            {item.opportunity.status === "active" && (
                              <>
                                {" "}
                                → now{" "}
                                <span className={item.opportunity.marginPct >= item.marginAtSave ? "text-profit" : "text-danger"}>{formatPct(item.opportunity.marginPct)}</span>
                              </>
                            )}
                          </span>
                          <Button variant="ghost" size="sm" onClick={() => remove.mutate(item.opportunity.id)} aria-label="Remove from watchlist">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              ),
          )}
        </>
      )}
    </div>
  );
}
