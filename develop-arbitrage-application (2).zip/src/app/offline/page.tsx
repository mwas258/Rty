import { WifiOff } from "lucide-react";
import Link from "next/link";

export const metadata = { title: "Offline" };

export default function OfflinePage() {
  return (
    <main className="grid min-h-screen place-items-center bg-bg px-5 text-center text-fg">
      <div>
        <WifiOff className="mx-auto h-12 w-12 text-muted" />
        <h1 className="mt-4 text-xl font-semibold">You are offline</h1>
        <p className="mt-2 max-w-sm text-sm text-muted">Arbitrage Finder Pro needs a connection to load fresh odds. Previously loaded screens may still be available in the app.</p>
        <Link href="/app" className="mt-6 inline-flex h-10 items-center rounded-xl bg-primary px-4 text-sm font-medium text-primary-fg">
          Retry
        </Link>
      </div>
    </main>
  );
}
