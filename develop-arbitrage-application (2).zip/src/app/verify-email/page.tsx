"use client";

import { useQueryClient } from "@tanstack/react-query";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { LinkButton } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { api, errorMessage } from "@/lib/client/api";

function VerifyEmail() {
  const token = useSearchParams().get("token");
  const qc = useQueryClient();
  const [state, setState] = useState<{ status: "loading" | "success" | "error"; message?: string }>({ status: token ? "loading" : "error", message: token ? undefined : "Missing token." });

  useEffect(() => {
    if (!token) return;
    let cancelled = false;
    api("/api/auth/verify-email", { method: "POST", json: { token } })
      .then(() => {
        if (cancelled) return;
        setState({ status: "success" });
        void qc.invalidateQueries({ queryKey: ["me"] });
      })
      .catch((err) => !cancelled && setState({ status: "error", message: errorMessage(err) }));
    return () => {
      cancelled = true;
    };
  }, [token, qc]);

  return (
    <main className="grid min-h-screen place-items-center bg-bg px-5 text-fg">
      <Card className="w-full max-w-md">
        <CardContent className="space-y-4 p-6 text-center">
          {state.status === "loading" && <Loader2 className="mx-auto h-10 w-10 animate-spin text-primary" />}
          {state.status === "success" && <CheckCircle2 className="mx-auto h-10 w-10 text-profit" />}
          {state.status === "error" && <XCircle className="mx-auto h-10 w-10 text-danger" />}
          <h1 className="text-xl font-semibold">
            {state.status === "loading" ? "Verifying your e-mail…" : state.status === "success" ? "E-mail verified" : "Verification failed"}
          </h1>
          <p className="text-sm text-muted">
            {state.status === "success" ? "Thanks! Alerts and account recovery are now enabled." : state.status === "error" ? state.message : "One moment."}
          </p>
          {state.status !== "loading" && (
            <LinkButton href="/app" className="w-full">
              Continue to the app
            </LinkButton>
          )}
        </CardContent>
      </Card>
    </main>
  );
}

export default function VerifyEmailPage() {
  return (
    <Suspense fallback={null}>
      <VerifyEmail />
    </Suspense>
  );
}
