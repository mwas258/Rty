"use client";

import { useMutation } from "@tanstack/react-query";
import { Database, MailWarning, WifiOff, Clock } from "lucide-react";
import Link from "next/link";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { api, errorMessage } from "@/lib/client/api";
import { useOnline } from "@/lib/client/hooks";
import type { ProviderStatusDTO } from "@/lib/types";
import { formatRelative } from "@/lib/utils";

export function OfflineBanner() {
  const online = useOnline();
  if (online) return null;
  return (
    <div className="flex items-center gap-2 bg-warning-bg px-4 py-2 text-xs font-medium text-fg" role="status">
      <WifiOff className="h-4 w-4 text-warning" /> You are offline. Showing the last loaded data; actions will fail until you reconnect.
    </div>
  );
}

export function DemoBanner({ providerName }: { providerName: string }) {
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-border bg-info-bg px-4 py-2 text-xs text-fg" role="status">
      <Database className="h-4 w-4 text-info" />
      <span>
        <strong>Demo mode:</strong> showing seeded sample odds ({providerName}). Connect a licensed odds provider (ODDS_API_KEY) to analyse real markets.
      </span>
    </div>
  );
}

export function StaleDataBanner({ provider }: { provider: ProviderStatusDTO }) {
  if (!provider.stale) return null;
  return (
    <div className="flex flex-wrap items-center gap-2 rounded-xl border border-warning/30 bg-warning-bg px-3 py-2 text-xs" role="alert">
      <Clock className="h-4 w-4 text-warning" />
      <span>
        <strong>Stale data:</strong> last successful refresh {provider.lastSuccessAt ? formatRelative(provider.lastSuccessAt) : "never"}.
        {provider.lastError ? ` Provider error: ${provider.lastError}` : ""} Treat all opportunities with caution.
      </span>
    </div>
  );
}

export function VerifyEmailBanner({ email }: { email: string }) {
  const toast = useToast();
  const [link, setLink] = useState<string | null>(null);
  const resend = useMutation({
    mutationFn: () => api<{ emailSent: boolean; devVerificationLink: string | null }>("/api/auth/verify-email", { method: "PUT" }),
    onSuccess: (data) => {
      if (data.emailSent) toast.success("Verification e-mail sent", `Check ${email}.`);
      else {
        setLink(data.devVerificationLink);
        toast.info("E-mail delivery is not configured", "Use the verification link shown in the banner.");
      }
    },
    onError: (err) => toast.error("Could not resend", errorMessage(err)),
  });
  return (
    <div className="flex flex-wrap items-center gap-2 border-b border-border bg-warning-bg px-4 py-2 text-xs" role="status">
      <MailWarning className="h-4 w-4 text-warning" />
      <span className="flex-1">
        Please verify <strong>{email}</strong> to enable alerts and account recovery.
        {link && (
          <>
            {" "}
            <Link href={link} className="font-semibold underline">
              Open verification link
            </Link>
          </>
        )}
      </span>
      <Button size="sm" variant="outline" loading={resend.isPending} onClick={() => resend.mutate()}>
        Resend
      </Button>
    </div>
  );
}
