"use client";

import { useMutation } from "@tanstack/react-query";
import { AlertTriangle, Minus, Plus, RotateCcw, Save } from "lucide-react";
import { useMemo, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Field, Input, Select } from "@/components/ui/input";
import { InlineAlert } from "@/components/ui/states";
import { useToast } from "@/components/ui/toast";
import { calculateArbitrage, type RoundingMode } from "@/lib/arb/engine";
import { api, errorMessage } from "@/lib/client/api";
import { cn, formatMoney, formatPct } from "@/lib/utils";

export interface CalcLegInput {
  label: string;
  odds: string;
  bookmaker: string;
}

export interface CalculatorDefaults {
  stake: number;
  commissionPct: number;
  fxPct: number;
  fixedCosts: number;
  roundingStep: number;
  currency: string;
}

export interface CalculatorState {
  legs: CalcLegInput[];
  stake: string;
  commissionPct: string;
  fxPct: string;
  fixedCosts: string;
  roundingStep: string;
  roundingMode: RoundingMode;
  minStake: string;
}

export function emptyLegs(n: number): CalcLegInput[] {
  const labels = n === 3 ? ["Home", "Draw", "Away"] : ["Outcome 1", "Outcome 2", "Outcome 3", "Outcome 4"];
  return Array.from({ length: n }, (_, i) => ({ label: labels[i] ?? `Outcome ${i + 1}`, odds: "", bookmaker: "" }));
}

export function initialCalculatorState(defaults: CalculatorDefaults, legs?: CalcLegInput[], stake?: number): CalculatorState {
  return {
    legs: legs && legs.length >= 2 ? legs : emptyLegs(2),
    stake: String(stake ?? defaults.stake),
    commissionPct: String(defaults.commissionPct),
    fxPct: String(defaults.fxPct),
    fixedCosts: String(defaults.fixedCosts),
    roundingStep: String(defaults.roundingStep),
    roundingMode: defaults.roundingStep > 0 ? "nearest" : "none",
    minStake: "",
  };
}

const num = (v: string) => (v.trim() === "" ? Number.NaN : Number(v));

export function ArbCalculator({
  state,
  onChange,
  defaults,
  opportunityId,
  title = "Arbitrage calculator",
}: {
  state: CalculatorState;
  onChange: (s: CalculatorState) => void;
  defaults: CalculatorDefaults;
  opportunityId?: string | null;
  title?: string;
}) {
  const toast = useToast();
  const [showFees, setShowFees] = useState(defaults.commissionPct > 0 || defaults.fxPct > 0 || defaults.fixedCosts > 0);

  const result = useMemo(
    () =>
      calculateArbitrage(
        state.legs.map((l) => ({ label: l.label || "Outcome", odds: num(l.odds), bookmaker: l.bookmaker || null })),
        {
          totalStake: num(state.stake),
          fees: { commissionPct: Number(state.commissionPct) || 0, fxPct: Number(state.fxPct) || 0, fixedCosts: Number(state.fixedCosts) || 0 },
          roundingStep: Number(state.roundingStep) || 0,
          roundingMode: state.roundingMode,
          minStake: Number(state.minStake) || undefined,
        },
      ),
    [state],
  );

  const touched = state.legs.some((l) => l.odds.trim() !== "");
  const update = (patch: Partial<CalculatorState>) => onChange({ ...state, ...patch });
  const updateLeg = (i: number, patch: Partial<CalcLegInput>) => update({ legs: state.legs.map((l, idx) => (idx === i ? { ...l, ...patch } : l)) });
  const setLegCount = (n: number) => {
    const next = [...state.legs];
    while (next.length < n) next.push({ label: `Outcome ${next.length + 1}`, odds: "", bookmaker: "" });
    update({ legs: next.slice(0, n) });
  };

  const save = useMutation({
    mutationFn: () =>
      api("/api/activity", {
        method: "POST",
        json: {
          action: "calculation_saved",
          entityType: opportunityId ? "opportunity" : "calculator",
          entityId: opportunityId ?? undefined,
          metadata: {
            legs: result.legs.map((l) => ({ label: l.label, odds: l.odds, stake: l.stake, bookmaker: l.bookmaker })),
            totalStake: result.totalStaked,
            marginPct: result.marginPct,
            netProfit: result.netProfit,
          },
        },
      }),
    onSuccess: () => toast.success("Calculation saved to your history"),
    onError: (err) => toast.error("Could not save", errorMessage(err)),
  });

  const cur = defaults.currency;

  return (
    <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      <Card>
        <CardHeader
          title={title}
          description="Enter decimal odds for every outcome. Stakes are allocated proportionally to implied probability."
          action={
            <div className="flex gap-1">
              {[2, 3].map((n) => (
                <Button key={n} size="sm" variant={state.legs.length === n ? "primary" : "outline"} onClick={() => setLegCount(n)}>
                  {n}-way
                </Button>
              ))}
            </div>
          }
        />
        <CardContent className="space-y-4">
          <div className="space-y-2">
            {state.legs.map((leg, i) => (
              <div key={i} className="grid grid-cols-[1fr_88px_auto] items-end gap-2 sm:grid-cols-[1fr_1fr_96px_auto]">
                <Field label={i === 0 ? "Outcome" : undefined} className="min-w-0">
                  <Input value={leg.label} onChange={(e) => updateLeg(i, { label: e.target.value })} placeholder={`Outcome ${i + 1}`} aria-label={`Outcome ${i + 1} label`} />
                </Field>
                <Field label={i === 0 ? "Bookmaker" : undefined} className="hidden min-w-0 sm:block">
                  <Input value={leg.bookmaker} onChange={(e) => updateLeg(i, { bookmaker: e.target.value })} placeholder="Optional" aria-label={`Outcome ${i + 1} bookmaker`} />
                </Field>
                <Field label={i === 0 ? "Odds" : undefined}>
                  <Input
                    inputMode="decimal"
                    type="number"
                    step="0.01"
                    min="1.01"
                    value={leg.odds}
                    onChange={(e) => updateLeg(i, { odds: e.target.value })}
                    placeholder="2.10"
                    className="font-mono"
                    aria-label={`Outcome ${i + 1} odds`}
                    aria-invalid={touched && (!Number.isFinite(num(leg.odds)) || num(leg.odds) <= 1)}
                  />
                </Field>
                <Button variant="ghost" size="icon" onClick={() => setLegCount(state.legs.length - 1)} disabled={state.legs.length <= 2} aria-label="Remove outcome" className="mb-0">
                  <Minus className="h-4 w-4" />
                </Button>
              </div>
            ))}
            <Button variant="outline" size="sm" onClick={() => setLegCount(state.legs.length + 1)} disabled={state.legs.length >= 12}>
              <Plus className="h-4 w-4" /> Add outcome
            </Button>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <Field label={`Total stake (${cur})`}>
              <Input inputMode="decimal" type="number" min="1" step="1" value={state.stake} onChange={(e) => update({ stake: e.target.value })} className="font-mono" />
            </Field>
            <Field label="Round stakes to">
              <div className="flex gap-2">
                <Input inputMode="decimal" type="number" min="0" step="0.5" value={state.roundingStep} onChange={(e) => update({ roundingStep: e.target.value })} className="font-mono" aria-label="Rounding step" />
                <Select value={state.roundingMode} onChange={(e) => update({ roundingMode: e.target.value as RoundingMode })} aria-label="Rounding mode" className="w-28">
                  <option value="nearest">Nearest</option>
                  <option value="down">Down</option>
                  <option value="up">Up</option>
                  <option value="none">None</option>
                </Select>
              </div>
            </Field>
          </div>

          <button type="button" onClick={() => setShowFees((s) => !s)} className="text-xs font-medium text-primary hover:underline">
            {showFees ? "Hide" : "Show"} fees, commission & minimum stake
          </button>
          {showFees && (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Field label="Commission %" hint="On winnings">
                <Input inputMode="decimal" type="number" min="0" step="0.1" value={state.commissionPct} onChange={(e) => update({ commissionPct: e.target.value })} className="font-mono" />
              </Field>
              <Field label="FX / payment %" hint="On total stake">
                <Input inputMode="decimal" type="number" min="0" step="0.1" value={state.fxPct} onChange={(e) => update({ fxPct: e.target.value })} className="font-mono" />
              </Field>
              <Field label={`Fixed costs (${cur})`}>
                <Input inputMode="decimal" type="number" min="0" step="0.5" value={state.fixedCosts} onChange={(e) => update({ fixedCosts: e.target.value })} className="font-mono" />
              </Field>
              <Field label={`Min stake (${cur})`}>
                <Input inputMode="decimal" type="number" min="0" step="1" value={state.minStake} onChange={(e) => update({ minStake: e.target.value })} className="font-mono" placeholder="—" />
              </Field>
            </div>
          )}

          <div className="flex gap-2">
            <Button variant="ghost" size="sm" onClick={() => onChange(initialCalculatorState(defaults, emptyLegs(state.legs.length)))}>
              <RotateCcw className="h-4 w-4" /> Reset
            </Button>
            <Button variant="secondary" size="sm" disabled={!result.ok} loading={save.isPending} onClick={() => save.mutate()}>
              <Save className="h-4 w-4" /> Save to history
            </Button>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader
          title="Result"
          description="Theoretical figures before real-world execution risk."
          action={
            touched && result.ok ? (
              <Badge variant={result.isArbitrage ? "profit" : "danger"} className="text-sm">
                {result.isArbitrage ? "Theoretical arbitrage" : "No arbitrage"}
              </Badge>
            ) : null
          }
        />
        <CardContent className="space-y-4">
          {!touched ? (
            <p className="text-sm text-muted">Enter odds to see the stake split, worst-case profit and the net estimate after fees.</p>
          ) : !result.ok ? (
            <InlineAlert tone="danger">
              <ul className="list-disc space-y-0.5 pl-4">
                {result.errors.map((e) => (
                  <li key={e}>{e}</li>
                ))}
              </ul>
            </InlineAlert>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
                <Metric label="Implied sum" value={formatPct(result.impliedSum * 100)} />
                <Metric label="Margin" value={formatPct(result.marginPct)} tone={result.isArbitrage ? "profit" : "danger"} />
                <Metric label="Min. gross profit" value={formatMoney(result.minProfit, cur)} tone={result.minProfit > 0 ? "profit" : "danger"} />
                <Metric label="Est. net profit" value={formatMoney(result.netProfit, cur)} tone={result.netProfit > 0 ? "profit" : "danger"} hint={`${formatPct(result.netRoiPct)} ROI`} />
              </div>

              <div className="scrollbar-thin overflow-x-auto rounded-xl border border-border">
                <table className="w-full min-w-[420px] text-sm">
                  <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
                    <tr>
                      <th className="px-3 py-2 text-left font-medium">Outcome</th>
                      <th className="px-3 py-2 text-right font-medium">Odds</th>
                      <th className="px-3 py-2 text-right font-medium">Stake</th>
                      <th className="px-3 py-2 text-right font-medium">Gross return</th>
                      <th className="px-3 py-2 text-right font-medium">Profit</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.legs.map((l, i) => (
                      <tr key={i} className="border-t border-border">
                        <td className="px-3 py-2">
                          <p className="font-medium">{l.label}</p>
                          {l.bookmaker && <p className="text-xs text-muted">{l.bookmaker}</p>}
                        </td>
                        <td className="px-3 py-2 text-right font-mono tabular">{l.odds.toFixed(2)}</td>
                        <td className="px-3 py-2 text-right font-mono font-semibold tabular">{formatMoney(l.stake, cur)}</td>
                        <td className="px-3 py-2 text-right font-mono tabular">{formatMoney(l.grossReturn, cur)}</td>
                        <td className={cn("px-3 py-2 text-right font-mono tabular", l.profit >= 0 ? "text-profit" : "text-danger")}>{formatMoney(l.profit, cur)}</td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot className="border-t border-border bg-surface-2 text-xs">
                    <tr>
                      <td className="px-3 py-2 font-medium" colSpan={2}>
                        Total staked
                      </td>
                      <td className="px-3 py-2 text-right font-mono font-semibold tabular">{formatMoney(result.totalStaked, cur)}</td>
                      <td className="px-3 py-2 text-right text-muted" colSpan={2}>
                        Fees: {formatMoney(result.fees.total, cur)} (commission {formatMoney(result.fees.commission, cur)}, FX {formatMoney(result.fees.fx, cur)}, fixed {formatMoney(result.fees.fixed, cur)})
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>

              {result.warnings.length > 0 && (
                <InlineAlert tone="warning">
                  <ul className="space-y-1">
                    {result.warnings.map((w) => (
                      <li key={w} className="flex gap-2">
                        <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0 text-warning" /> {w}
                      </li>
                    ))}
                  </ul>
                </InlineAlert>
              )}
              <p className="text-xs text-muted">
                Theoretical estimate only. Odds can change before all bets are placed, bookmakers may limit or void bets, and payment or currency costs vary. No outcome is guaranteed.
              </p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Metric({ label, value, hint, tone = "default" }: { label: string; value: string; hint?: string; tone?: "default" | "profit" | "danger" }) {
  return (
    <div className="rounded-xl bg-surface-2 p-3">
      <p className="text-[11px] font-medium uppercase tracking-wide text-muted">{label}</p>
      <p className={cn("mt-1 text-lg font-semibold tabular", tone === "profit" && "text-profit", tone === "danger" && "text-danger")}>{value}</p>
      {hint && <p className="text-xs text-muted">{hint}</p>}
    </div>
  );
}
