"use client";

import { AlertTriangle } from "lucide-react";
import { Component, type ErrorInfo, type ReactNode } from "react";
import { Button } from "@/components/ui/button";

interface State {
  error: Error | null;
}

export class ErrorBoundary extends Component<{ children: ReactNode; fallback?: ReactNode }, State> {
  state: State = { error: null };

  static getDerivedStateFromError(error: Error): State {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Log without user data; the server-side logger handles persistence for API errors.
    console.error("[ui] boundary caught", error.message, info.componentStack?.split("\n")[1]);
  }

  render() {
    if (!this.state.error) return this.props.children;
    if (this.props.fallback) return this.props.fallback;
    return (
      <div className="m-4 flex flex-col items-center rounded-2xl border border-danger/30 bg-danger-bg/40 p-8 text-center" role="alert">
        <AlertTriangle className="mb-3 h-8 w-8 text-danger" />
        <h2 className="text-base font-semibold">This section failed to render</h2>
        <p className="mt-1 max-w-md text-sm text-muted">{this.state.error.message}</p>
        <Button className="mt-4" variant="outline" onClick={() => this.setState({ error: null })}>
          Try again
        </Button>
      </div>
    );
  }
}
