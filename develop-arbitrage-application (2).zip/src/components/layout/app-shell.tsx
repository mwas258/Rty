"use client";

import {
  Bell,
  Bookmark,
  Building2,
  Calculator,
  ChevronLeft,
  ChevronRight,
  History,
  LayoutDashboard,
  LogOut,
  Menu,
  Moon,
  Radar,
  Settings,
  Shield,
  Sun,
  TrendingUp,
  X,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState, type ReactNode } from "react";
import { DemoBanner, OfflineBanner, VerifyEmailBanner } from "@/components/banners";
import { useTheme } from "@/components/theme";
import { Badge } from "@/components/ui/badge";
import { useLogout, useMe, useStoredValue, useUnreadCount } from "@/lib/client/hooks";
import type { AuthUserDTO } from "@/lib/types";
import { cn } from "@/lib/utils";

type NavItem = { href: string; label: string; icon: typeof LayoutDashboard; exact?: boolean };

const NAV: NavItem[] = [
  { href: "/app", label: "Dashboard", icon: LayoutDashboard, exact: true },
  { href: "/app/scanner", label: "Scanner", icon: Radar },
  { href: "/app/calculator", label: "Calculator", icon: Calculator },
  { href: "/app/watchlist", label: "Watchlist", icon: Bookmark },
  { href: "/app/alerts", label: "Alerts", icon: Bell },
  { href: "/app/bookmakers", label: "Bookmakers", icon: Building2 },
  { href: "/app/history", label: "History", icon: History },
  { href: "/app/settings", label: "Settings", icon: Settings },
];
const ADMIN_NAV: NavItem = { href: "/admin", label: "Admin", icon: Shield };

function isActive(pathname: string, href: string, exact?: boolean) {
  return exact ? pathname === href : pathname === href || pathname.startsWith(`${href}/`);
}

export function AppShell({ user, children }: { user: AuthUserDTO; children: ReactNode }) {
  const pathname = usePathname();
  const [sidebar, setSidebar] = useStoredValue("afp_sidebar", "expanded");
  const collapsed = sidebar === "collapsed";
  const [moreOpen, setMoreOpen] = useState(false);
  const { resolved, toggle } = useTheme();
  const me = useMe();
  const unread = useUnreadCount();
  const logout = useLogout();

  const toggleCollapsed = () => setSidebar(collapsed ? "expanded" : "collapsed");

  const items = user.role === "admin" ? [...NAV, ADMIN_NAV] : NAV;
  const current: { label: string } = items.find((i) => isActive(pathname, i.href, i.exact)) ?? (pathname.startsWith("/app/opportunities") ? { label: "Opportunity" } : { label: "Arbitrage Finder Pro" });
  const unreadCount = unread.data?.unread ?? me.data?.unreadNotifications ?? 0;
  const emailVerified = me.data?.user.emailVerified ?? user.emailVerified;
  const config = me.data?.config;
  const plan = me.data?.entitlements;
  const initials = user.displayName
    .split(" ")
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  const navLink = (item: NavItem, compact: boolean) => {
    const active = isActive(pathname, item.href, item.exact);
    const Icon = item.icon;
    return (
      <Link
        key={item.href}
        href={item.href}
        aria-current={active ? "page" : undefined}
        title={item.label}
        onClick={() => setMoreOpen(false)}
        className={cn(
          "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition",
          active ? "bg-primary/15 text-fg" : "text-muted hover:bg-surface-2 hover:text-fg",
          compact && "justify-center px-0",
        )}
      >
        <Icon className={cn("h-5 w-5 shrink-0", active && "text-primary")} />
        {!compact && <span className="truncate">{item.label}</span>}
        {!compact && item.href === "/app/alerts" && unreadCount > 0 && (
          <span className="ml-auto rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-fg">{unreadCount > 99 ? "99+" : unreadCount}</span>
        )}
      </Link>
    );
  };

  return (
    <div className="flex min-h-screen bg-bg text-fg">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "sticky top-0 hidden h-screen shrink-0 flex-col border-r border-border bg-bg-elevated transition-[width] duration-200 lg:flex",
          collapsed ? "w-[72px]" : "w-64",
        )}
      >
        <div className={cn("flex h-16 items-center gap-2 border-b border-border px-4", collapsed && "justify-center px-0")}>
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
            <TrendingUp className="h-5 w-5" />
          </span>
          {!collapsed && (
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold leading-tight">Arbitrage Finder Pro</p>
              <p className="text-[11px] text-muted">{config?.demoMode ? "Demo data" : config?.providerName ?? "Odds analysis"}</p>
            </div>
          )}
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto p-3" aria-label="Main">
          {items.map((i) => navLink(i, collapsed))}
        </nav>
        <div className="border-t border-border p-3">
          {!collapsed && plan && (
            <div className="mb-3 rounded-xl bg-surface-2 p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs text-muted">Plan</span>
                <Badge variant={plan.plan === "premium" ? "profit" : "outline"}>{plan.planName}</Badge>
              </div>
              {plan.plan === "free" && (
                <Link href="/app/settings?tab=subscription" className="mt-2 block text-xs font-medium text-primary hover:underline">
                  Upgrade for unlimited scanner →
                </Link>
              )}
            </div>
          )}
          <button
            type="button"
            onClick={toggleCollapsed}
            className="flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2 text-xs text-muted hover:bg-surface-2 hover:text-fg"
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
            {!collapsed && "Collapse"}
          </button>
        </div>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-40 border-b border-border bg-bg/85 backdrop-blur">
          <div className="flex h-14 items-center gap-3 px-4 sm:h-16 sm:px-6">
            <Link href="/app" className="grid h-9 w-9 place-items-center rounded-xl bg-primary/15 text-primary lg:hidden" aria-label="Dashboard">
              <TrendingUp className="h-5 w-5" />
            </Link>
            <h1 className="min-w-0 flex-1 truncate text-base font-semibold sm:text-lg">{current.label}</h1>
            {config && (
              <Badge variant={config.demoMode ? "info" : "profit"} className="hidden sm:inline-flex">
                {config.demoMode ? "DEMO DATA" : "LIVE"}
              </Badge>
            )}
            <button type="button" onClick={toggle} className="rounded-xl p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label="Toggle theme">
              {resolved === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <Link href="/app/alerts" className="relative rounded-xl p-2 text-muted hover:bg-surface-2 hover:text-fg" aria-label={`Notifications (${unreadCount} unread)`}>
              <Bell className="h-5 w-5" />
              {unreadCount > 0 && <span className="absolute top-1 right-1 h-2.5 w-2.5 rounded-full bg-primary ring-2 ring-bg" />}
            </Link>
            <Link href="/app/settings" className="grid h-9 w-9 place-items-center rounded-full bg-surface-2 text-xs font-semibold" aria-label="Account settings">
              {initials}
            </Link>
          </div>
          <OfflineBanner />
          {config?.demoMode && <DemoBanner providerName={config.providerName} />}
          {!emailVerified && <VerifyEmailBanner email={user.email} />}
        </header>

        <main className="mx-auto w-full max-w-7xl flex-1 px-4 pt-5 pb-28 sm:px-6 lg:pb-10">{children}</main>

        {/* Mobile bottom navigation */}
        <nav className="safe-bottom fixed inset-x-0 bottom-0 z-40 border-t border-border bg-bg-elevated/95 backdrop-blur lg:hidden" aria-label="Primary">
          <div className="grid grid-cols-5">
            {NAV.slice(0, 4).map((item) => {
              const active = isActive(pathname, item.href, item.exact);
              const Icon = item.icon;
              return (
                <Link key={item.href} href={item.href} aria-current={active ? "page" : undefined} className={cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", active ? "text-primary" : "text-muted")}>
                  <Icon className="h-5 w-5" />
                  {item.label}
                </Link>
              );
            })}
            <button type="button" onClick={() => setMoreOpen(true)} className={cn("flex flex-col items-center gap-1 py-2.5 text-[11px] font-medium", moreOpen ? "text-primary" : "text-muted")} aria-haspopup="dialog" aria-expanded={moreOpen}>
              <span className="relative">
                <Menu className="h-5 w-5" />
                {unreadCount > 0 && <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-primary" />}
              </span>
              More
            </button>
          </div>
        </nav>

        {moreOpen && (
          <div className="fixed inset-0 z-50 bg-black/60 lg:hidden" onClick={() => setMoreOpen(false)} role="presentation">
            <div className="safe-bottom absolute inset-x-0 bottom-0 rounded-t-2xl border-t border-border bg-bg-elevated p-4" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="More navigation">
              <div className="mb-3 flex items-center justify-between">
                <p className="text-sm font-semibold">{user.displayName}</p>
                <button type="button" onClick={() => setMoreOpen(false)} className="rounded-lg p-1 text-muted" aria-label="Close">
                  <X className="h-5 w-5" />
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {items.slice(4).map((i) => navLink(i, false))}
                <button type="button" onClick={toggle} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-muted hover:bg-surface-2">
                  {resolved === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />} {resolved === "dark" ? "Light theme" : "Dark theme"}
                </button>
                <button type="button" onClick={() => logout.mutate()} className="flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-danger hover:bg-surface-2">
                  <LogOut className="h-5 w-5" /> Sign out
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
