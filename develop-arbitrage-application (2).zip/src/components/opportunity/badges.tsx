"use client";

import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Bookmark, BookmarkCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/toast";
import { dataFreshness } from "@/lib/arb/engine";
import { api, errorMessage, isPlanError } from "@/lib/client/api";
import { useNow } from "@/lib/client/hooks";
import { cn, formatPct } from "@/lib/utils";

export function MarginBadge({ value, size = "md" }: { value: number; size?: "sm" | "md" | "lg" }) {
  const tone = value >= 2 ? "profit" : value >= 0.75 ? "info" : value > 0 ? "default" : "danger";
  return (
    <Badge variant={tone} className={cn("tabular", size === "lg" && "px-3 py-1 text-base", size === "md" && "text-sm")}>
      {value > 0 ? "+" : ""}
      {formatPct(value)}
    </Badge>
  );
}

export function FreshnessBadge({ updatedAt, showLabel = true }: { updatedAt: string; showLabel?: boolean }) {
  const now = useNow();
  const f = dataFreshness(updatedAt, now);
  const colors = { fresh: "bg-profit", aging: "bg-warning", stale: "bg-danger" };
  const labels = { fresh: "Fresh", aging: "Aging", stale: "Stale" };
  return (
    <span className="inline-flex items-center gap-1.5 text-xs text-muted" title={`Odds updated ${f.label}`}>
      <span className={cn("h-2 w-2 rounded-full", colors[f.level])} aria-hidden />
      {showLabel && (
        <span>
          {labels[f.level]} · {f.label}
        </span>
      )}
    </span>
  );
}

export function WatchButton({ opportunityId, watched, size = "sm", label = false }: { opportunityId: string; watched: boolean; size?: "sm" | "md"; label?: boolean }) {
  const qc = useQueryClient();
  const toast = useToast();
  const mutation = useMutation({
    mutationFn: () =>
      watched
        ? api(`/api/watchlist/${opportunityId}`, { method: "DELETE" })
        : api("/api/watchlist", { method: "POST", json: { opportunityId } }),
    onSuccess: () => {
      toast.success(watched ? "Removed from watchlist" : "Saved to watchlist");
      void qc.invalidateQueries({ queryKey: ["opportunities"] });
      void qc.invalidateQueries({ queryKey: ["opportunity", opportunityId] });
      void qc.invalidateQueries({ queryKey: ["watchlist"] });
      void qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
    onError: (err) => toast.error(isPlanError(err) ? "Plan limit reached" : "Could not update watchlist", errorMessage(err)),
  });
  return (
    <Button
      variant={watched ? "secondary" : "outline"}
      size={size}
      loading={mutation.isPending}
      onClick={() => mutation.mutate()}
      aria-pressed={watched}
      aria-label={watched ? "Remove from watchlist" : "Save to watchlist"}
    >
      {watched ? <BookmarkCheck className="h-4 w-4 text-profit" /> : <Bookmark className="h-4 w-4" />}
      {label && (watched ? "Watching" : "Watch")}
    </Button>
  );
}
