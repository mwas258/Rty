"use client";

import { Badge } from "@/components/ui/badge";
import type { OpportunityDetailResponse } from "@/lib/types";
import { cn, formatOdds, formatRelative } from "@/lib/utils";

export function OddsTable({ detail }: { detail: OpportunityDetailResponse }) {
  const { outcomes, bookmakers, matrix } = detail;
  if (!bookmakers.length) return <p className="text-sm text-muted">No bookmaker prices stored for this market yet.</p>;
  return (
    <div className="scrollbar-thin overflow-x-auto rounded-xl border border-border">
      <table className="w-full min-w-[520px] text-sm">
        <thead className="bg-surface-2 text-xs uppercase tracking-wide text-muted">
          <tr>
            <th className="px-3 py-2 text-left font-medium">Bookmaker</th>
            {outcomes.map((o) => (
              <th key={o} className="px-3 py-2 text-right font-medium">
                {o}
              </th>
            ))}
            <th className="px-3 py-2 text-right font-medium">Updated</th>
          </tr>
        </thead>
        <tbody>
          {bookmakers.map((b) => {
            const row = matrix[b.key] ?? {};
            const updated = Object.values(row)[0]?.updatedAt;
            return (
              <tr key={b.key} className="border-t border-border">
                <td className="px-3 py-2">
                  <div className="flex flex-wrap items-center gap-1.5">
                    <span className="font-medium">{b.name}</span>
                    {b.isExchange && <Badge variant="outline">Exchange {b.commissionPct}%</Badge>}
                    {b.available === true && <Badge variant="profit">My account</Badge>}
                    {b.available === false && <Badge variant="danger">Unavailable</Badge>}
                  </div>
                  {b.country && <p className="text-[11px] text-muted">{b.country}</p>}
                </td>
                {outcomes.map((o) => {
                  const cell = row[o];
                  return (
                    <td key={o} className="px-3 py-2 text-right">
                      {cell ? (
                        <span className={cn("inline-block rounded-md px-1.5 py-0.5 font-mono tabular", cell.isBest ? "bg-profit-bg font-semibold text-profit" : "")} title={cell.isBest ? "Best available price" : undefined}>
                          {formatOdds(cell.price)}
                        </span>
                      ) : (
                        <span className="text-muted">—</span>
                      )}
                    </td>
                  );
                })}
                <td className="px-3 py-2 text-right text-xs text-muted">{updated ? formatRelative(updated) : "—"}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
