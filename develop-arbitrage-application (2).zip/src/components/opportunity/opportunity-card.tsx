"use client";

import { Calculator, ChevronRight } from "lucide-react";
import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import { LinkButton } from "@/components/ui/button";
import type { OpportunityDTO } from "@/lib/types";
import { formatDateTime, formatMoney, formatOdds, sportIcon } from "@/lib/utils";
import { FreshnessBadge, MarginBadge, WatchButton } from "./badges";

export function calculatorHref(o: OpportunityDTO, stake?: number) {
  const legs = o.legs.map((l) => [l.outcome, l.odds, l.bookmakerName].map((p) => encodeURIComponent(String(p))).join("@")).join("|");
  return `/app/calculator?legs=${legs}${stake ? `&stake=${stake}` : ""}&opp=${o.id}`;
}

export function OpportunityCard({ opportunity: o, stake = 100, currency = "EUR", compact = false }: { opportunity: OpportunityDTO; stake?: number; currency?: string; compact?: boolean }) {
  const estProfit = (stake * o.marginPct) / 100;
  const expired = o.status === "expired";
  return (
    <article className={`flex flex-col rounded-2xl border bg-surface p-4 transition hover:border-border-strong ${expired ? "border-border opacity-80" : "border-border"}`}>
      <header className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-xs text-muted">
            <span aria-hidden>{sportIcon(o.sportKey)}</span>
            <span className="truncate">{o.league}</span>
            <span aria-hidden>·</span>
            <time dateTime={o.commenceTime}>{formatDateTime(o.commenceTime)}</time>
          </div>
          <h3 className="mt-1 truncate text-sm font-semibold sm:text-base">
            <Link href={`/app/opportunities/${o.id}`} className="hover:underline">
              {o.homeTeam} vs {o.awayTeam}
            </Link>
          </h3>
          <p className="text-xs text-muted">
            {o.marketLabel} · {o.outcomeCount}-way
          </p>
        </div>
        <div className="flex flex-col items-end gap-1">
          <MarginBadge value={o.marginPct} />
          {expired ? <Badge variant="danger">Expired</Badge> : o.isDemo ? <Badge variant="outline">Demo</Badge> : null}
        </div>
      </header>

      <ul className="mt-3 grid gap-1.5">
        {o.legs.map((leg) => (
          <li key={leg.outcome} className="flex items-center justify-between gap-2 rounded-lg bg-surface-2 px-2.5 py-1.5 text-sm">
            <span className="truncate">{leg.outcome}</span>
            <span className="flex items-center gap-2">
              <span className="max-w-[110px] truncate text-xs text-muted">{leg.bookmakerName}</span>
              <span className="font-mono font-semibold tabular">{formatOdds(leg.odds)}</span>
            </span>
          </li>
        ))}
      </ul>

      <footer className="mt-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted">
          <FreshnessBadge updatedAt={o.dataUpdatedAt} />
          <span>
            ≈ <span className="font-semibold text-profit">{formatMoney(estProfit, currency)}</span> per {formatMoney(stake, currency, 0)}
          </span>
        </div>
        {!compact && (
          <div className="flex items-center gap-1.5">
            <WatchButton opportunityId={o.id} watched={o.watched} />
            <LinkButton href={calculatorHref(o, stake)} variant="outline" size="sm" aria-label="Open in calculator">
              <Calculator className="h-4 w-4" />
            </LinkButton>
            <LinkButton href={`/app/opportunities/${o.id}`} variant="secondary" size="sm">
              Details <ChevronRight className="h-4 w-4" />
            </LinkButton>
          </div>
        )}
      </footer>
    </article>
  );
}
