import type { HTMLAttributes } from "react";
import { cn } from "@/lib/utils";

type Variant = "default" | "profit" | "danger" | "warning" | "info" | "outline" | "primary";

const variants: Record<Variant, string> = {
  default: "bg-surface-2 text-fg",
  profit: "bg-profit-bg text-profit",
  danger: "bg-danger-bg text-danger",
  warning: "bg-warning-bg text-warning",
  info: "bg-info-bg text-info",
  outline: "border border-border text-muted",
  primary: "bg-primary/15 text-primary",
};

export function Badge({ variant = "default", className, ...props }: HTMLAttributes<HTMLSpanElement> & { variant?: Variant }) {
  return <span className={cn("inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[11px] font-semibold tracking-wide whitespace-nowrap", variants[variant], className)} {...props} />;
}
