"use client";

import { AlertTriangle, Inbox, Loader2, RefreshCw, WifiOff } from "lucide-react";
import type { ReactNode } from "react";
import { errorMessage } from "@/lib/client/api";
import { cn } from "@/lib/utils";
import { Button } from "./button";

export function Skeleton({ className }: { className?: string }) {
  return <div className={cn("skeleton rounded-lg", className)} aria-hidden />;
}

export function CardSkeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-4">
      <Skeleton className="h-4 w-1/3" />
      <Skeleton className="mt-3 h-5 w-2/3" />
      <div className="mt-4 space-y-2">
        {Array.from({ length: rows }).map((_, i) => (
          <Skeleton key={i} className="h-8 w-full" />
        ))}
      </div>
    </div>
  );
}

export function ListSkeleton({ count = 4, rows = 3 }: { count?: number; rows?: number }) {
  return (
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3" role="status" aria-label="Loading">
      {Array.from({ length: count }).map((_, i) => (
        <CardSkeleton key={i} rows={rows} />
      ))}
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return <Loader2 className={cn("h-5 w-5 animate-spin text-muted", className)} aria-label="Loading" />;
}

export function LoadingState({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-2 py-12 text-sm text-muted" role="status">
      <Spinner /> {label}
    </div>
  );
}

export function EmptyState({ title, description, action, icon }: { title: string; description?: ReactNode; action?: ReactNode; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border px-6 py-12 text-center">
      <div className="mb-3 rounded-full bg-surface-2 p-3 text-muted">{icon ?? <Inbox className="h-6 w-6" />}</div>
      <h3 className="text-sm font-semibold">{title}</h3>
      {description && <p className="mt-1 max-w-sm text-sm text-muted">{description}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

export function ErrorState({ error, onRetry, title = "Something went wrong" }: { error?: unknown; onRetry?: () => void; title?: string }) {
  const offline = typeof navigator !== "undefined" && !navigator.onLine;
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-danger/30 bg-danger-bg/40 px-6 py-10 text-center" role="alert">
      <div className="mb-3 rounded-full bg-surface p-3 text-danger">{offline ? <WifiOff className="h-6 w-6" /> : <AlertTriangle className="h-6 w-6" />}</div>
      <h3 className="text-sm font-semibold">{offline ? "You are offline" : title}</h3>
      <p className="mt-1 max-w-sm text-sm text-muted">{offline ? "Reconnect to load fresh data." : errorMessage(error)}</p>
      {onRetry && (
        <Button variant="outline" size="sm" className="mt-4" onClick={onRetry}>
          <RefreshCw className="h-3.5 w-3.5" /> Try again
        </Button>
      )}
    </div>
  );
}

export function InlineAlert({ tone = "info", children, className }: { tone?: "info" | "warning" | "danger" | "success"; children: ReactNode; className?: string }) {
  const tones = {
    info: "border-info/30 bg-info-bg text-fg",
    warning: "border-warning/30 bg-warning-bg text-fg",
    danger: "border-danger/30 bg-danger-bg text-fg",
    success: "border-profit/30 bg-profit-bg text-fg",
  };
  return (
    <div className={cn("rounded-xl border px-3 py-2.5 text-sm", tones[tone], className)} role={tone === "danger" ? "alert" : "status"}>
      {children}
    </div>
  );
}
