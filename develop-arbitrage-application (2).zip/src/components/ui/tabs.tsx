"use client";

import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export interface TabItem<T extends string> {
  value: T;
  label: ReactNode;
  badge?: ReactNode;
}

export function Tabs<T extends string>({ items, value, onChange, className }: { items: TabItem<T>[]; value: T; onChange: (v: T) => void; className?: string }) {
  return (
    <div role="tablist" className={cn("scrollbar-thin flex gap-1 overflow-x-auto rounded-xl border border-border bg-surface p-1", className)}>
      {items.map((item) => {
        const active = item.value === value;
        return (
          <button
            key={item.value}
            role="tab"
            type="button"
            aria-selected={active}
            onClick={() => onChange(item.value)}
            className={cn(
              "flex h-9 shrink-0 items-center gap-1.5 rounded-lg px-3 text-sm font-medium transition",
              active ? "bg-primary text-primary-fg shadow-sm" : "text-muted hover:bg-surface-2 hover:text-fg",
            )}
          >
            {item.label}
            {item.badge !== undefined && item.badge !== null && (
              <span className={cn("rounded-full px-1.5 text-[10px]", active ? "bg-white/20" : "bg-surface-2")}>{item.badge}</span>
            )}
          </button>
        );
      })}
    </div>
  );
}
