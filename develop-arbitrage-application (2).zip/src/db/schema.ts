import { sql } from "drizzle-orm";
import {
  bigserial,
  boolean,
  doublePrecision,
  index,
  integer,
  jsonb,
  pgTable,
  primaryKey,
  serial,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from "drizzle-orm/pg-core";

const ts = (name: string) => timestamp(name, { withTimezone: true, mode: "date" });
const createdAt = () => ts("created_at").notNull().defaultNow();
const updatedAt = () => ts("updated_at").notNull().defaultNow();
const textArray = (name: string) =>
  text(name)
    .array()
    .notNull()
    .default(sql`'{}'::text[]`);

// ---------------------------------------------------------------------------
// Identity & security
// ---------------------------------------------------------------------------
export const profiles = pgTable(
  "profiles",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    email: text("email").notNull(),
    passwordHash: text("password_hash"),
    displayName: text("display_name").notNull(),
    avatarUrl: text("avatar_url"),
    role: text("role", { enum: ["user", "admin"] }).notNull().default("user"),
    status: text("status", { enum: ["active", "disabled"] }).notNull().default("active"),
    emailVerifiedAt: ts("email_verified_at"),
    mfaEnabled: boolean("mfa_enabled").notNull().default(false),
    mfaSecretEnc: text("mfa_secret_enc"),
    mfaPendingSecretEnc: text("mfa_pending_secret_enc"),
    googleId: text("google_id"),
    lastLoginAt: ts("last_login_at"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    uniqueIndex("profiles_email_lower_idx").on(sql`lower(${t.email})`),
    uniqueIndex("profiles_google_id_idx").on(t.googleId),
  ],
);

export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    tokenHash: text("token_hash").notNull(),
    userAgent: text("user_agent"),
    ip: text("ip"),
    expiresAt: ts("expires_at").notNull(),
    lastSeenAt: ts("last_seen_at").notNull().defaultNow(),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("sessions_token_hash_idx").on(t.tokenHash), index("sessions_user_idx").on(t.userId)],
);

export const authTokens = pgTable(
  "auth_tokens",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    type: text("type", { enum: ["verify_email", "reset_password", "mfa_challenge"] }).notNull(),
    tokenHash: text("token_hash").notNull(),
    attempts: integer("attempts").notNull().default(0),
    expiresAt: ts("expires_at").notNull(),
    usedAt: ts("used_at"),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("auth_tokens_hash_idx").on(t.tokenHash), index("auth_tokens_user_type_idx").on(t.userId, t.type)],
);

export const userPreferences = pgTable("user_preferences", {
  userId: uuid("user_id")
    .primaryKey()
    .references(() => profiles.id, { onDelete: "cascade" }),
  theme: text("theme", { enum: ["system", "dark", "light"] }).notNull().default("system"),
  currency: text("currency").notNull().default("EUR"),
  defaultStake: doublePrecision("default_stake").notNull().default(100),
  defaultCommissionPct: doublePrecision("default_commission_pct").notNull().default(0),
  defaultFxPct: doublePrecision("default_fx_pct").notNull().default(0),
  defaultFixedCosts: doublePrecision("default_fixed_costs").notNull().default(0),
  roundingStep: doublePrecision("rounding_step").notNull().default(1),
  minMarginPct: doublePrecision("min_margin_pct").notNull().default(0.5),
  preferredSports: textArray("preferred_sports"),
  preferredMarkets: textArray("preferred_markets"),
  telegramChatId: text("telegram_chat_id"),
  emailAlerts: boolean("email_alerts").notNull().default(false),
  telegramAlerts: boolean("telegram_alerts").notNull().default(false),
  dashboardWidgets: jsonb("dashboard_widgets").$type<string[]>().notNull().default(sql`'["opportunities","margin","bookmakers","activity","subscription"]'::jsonb`),
  responsibleUseAckAt: ts("responsible_use_ack_at"),
  updatedAt: updatedAt(),
});

// ---------------------------------------------------------------------------
// Reference data
// ---------------------------------------------------------------------------
export const bookmakers = pgTable(
  "bookmakers",
  {
    id: serial("id").primaryKey(),
    key: text("key").notNull(),
    name: text("name").notNull(),
    country: text("country"),
    currency: text("currency"),
    website: text("website"),
    supportedMarkets: textArray("supported_markets"),
    isExchange: boolean("is_exchange").notNull().default(false),
    commissionPct: doublePrecision("commission_pct").notNull().default(0),
    active: boolean("active").notNull().default(true),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("bookmakers_key_idx").on(t.key)],
);

export const userBookmakers = pgTable(
  "user_bookmakers",
  {
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    bookmakerId: integer("bookmaker_id")
      .notNull()
      .references(() => bookmakers.id, { onDelete: "cascade" }),
    available: boolean("available").notNull().default(true),
    notes: text("notes"),
    updatedAt: updatedAt(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.bookmakerId] })],
);

export const sports = pgTable(
  "sports",
  {
    id: serial("id").primaryKey(),
    key: text("key").notNull(),
    title: text("title").notNull(),
    groupName: text("group_name").notNull(),
    active: boolean("active").notNull().default(true),
  },
  (t) => [uniqueIndex("sports_key_idx").on(t.key)],
);

// ---------------------------------------------------------------------------
// Odds data
// ---------------------------------------------------------------------------
export const events = pgTable(
  "events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    provider: text("provider").notNull(),
    externalId: text("external_id").notNull(),
    fingerprint: text("fingerprint").notNull(),
    sportId: integer("sport_id")
      .notNull()
      .references(() => sports.id),
    sportKey: text("sport_key").notNull(),
    league: text("league").notNull(),
    homeTeam: text("home_team").notNull(),
    awayTeam: text("away_team").notNull(),
    commenceTime: ts("commence_time").notNull(),
    status: text("status", { enum: ["upcoming", "live", "finished", "cancelled"] }).notNull().default("upcoming"),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [
    uniqueIndex("events_fingerprint_idx").on(t.fingerprint),
    index("events_provider_external_idx").on(t.provider, t.externalId),
    index("events_sport_commence_idx").on(t.sportKey, t.commenceTime),
  ],
);

export const markets = pgTable(
  "markets",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventId: uuid("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    marketKey: text("market_key").notNull(),
    line: doublePrecision("line").notNull().default(0),
    outcomeCount: integer("outcome_count").notNull(),
    outcomes: textArray("outcomes"),
    updatedAt: updatedAt(),
  },
  (t) => [uniqueIndex("markets_event_key_line_idx").on(t.eventId, t.marketKey, t.line)],
);

export const oddsSnapshots = pgTable(
  "odds_snapshots",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    marketId: uuid("market_id")
      .notNull()
      .references(() => markets.id, { onDelete: "cascade" }),
    bookmakerId: integer("bookmaker_id")
      .notNull()
      .references(() => bookmakers.id),
    outcomeName: text("outcome_name").notNull(),
    price: doublePrecision("price").notNull(),
    isLatest: boolean("is_latest").notNull().default(true),
    providerUpdatedAt: ts("provider_updated_at").notNull(),
    capturedAt: ts("captured_at").notNull().defaultNow(),
  },
  (t) => [
    index("odds_market_latest_idx").on(t.marketId, t.isLatest),
    index("odds_captured_idx").on(t.capturedAt),
  ],
);

export type OpportunityLeg = {
  outcome: string;
  bookmakerKey: string;
  bookmakerName: string;
  odds: number;
  updatedAt: string;
};

export const opportunities = pgTable(
  "opportunities",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    eventId: uuid("event_id")
      .notNull()
      .references(() => events.id, { onDelete: "cascade" }),
    marketId: uuid("market_id")
      .notNull()
      .references(() => markets.id, { onDelete: "cascade" }),
    sportKey: text("sport_key").notNull(),
    marketKey: text("market_key").notNull(),
    line: doublePrecision("line").notNull().default(0),
    status: text("status", { enum: ["active", "expired"] }).notNull().default("active"),
    impliedSum: doublePrecision("implied_sum").notNull(),
    marginPct: doublePrecision("margin_pct").notNull(),
    peakMarginPct: doublePrecision("peak_margin_pct").notNull(),
    outcomeCount: integer("outcome_count").notNull(),
    legs: jsonb("legs").$type<OpportunityLeg[]>().notNull(),
    provider: text("provider").notNull(),
    isDemo: boolean("is_demo").notNull().default(false),
    timesSeen: integer("times_seen").notNull().default(1),
    firstSeenAt: ts("first_seen_at").notNull().defaultNow(),
    lastSeenAt: ts("last_seen_at").notNull().defaultNow(),
    expiredAt: ts("expired_at"),
    expiredReason: text("expired_reason"),
    dataUpdatedAt: ts("data_updated_at").notNull(),
  },
  (t) => [
    uniqueIndex("opportunities_market_idx").on(t.marketId),
    index("opportunities_status_margin_idx").on(t.status, t.marginPct),
    index("opportunities_sport_idx").on(t.sportKey),
    index("opportunities_expired_idx").on(t.expiredAt),
  ],
);

// ---------------------------------------------------------------------------
// User data
// ---------------------------------------------------------------------------
export const watchlist = pgTable(
  "watchlist",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    opportunityId: uuid("opportunity_id")
      .notNull()
      .references(() => opportunities.id, { onDelete: "cascade" }),
    marginAtSave: doublePrecision("margin_at_save").notNull(),
    note: text("note"),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex("watchlist_user_opp_idx").on(t.userId, t.opportunityId)],
);

export const alertRules = pgTable(
  "alert_rules",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    minMarginPct: doublePrecision("min_margin_pct").notNull().default(1),
    minNetProfit: doublePrecision("min_net_profit"),
    sports: textArray("sports"),
    markets: textArray("markets"),
    bookmakers: textArray("bookmakers"),
    channels: textArray("channels"),
    enabled: boolean("enabled").notNull().default(true),
    lastTriggeredAt: ts("last_triggered_at"),
    createdAt: createdAt(),
  },
  (t) => [index("alert_rules_user_idx").on(t.userId)],
);

export const notifications = pgTable(
  "notifications",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    ruleId: uuid("rule_id").references(() => alertRules.id, { onDelete: "set null" }),
    opportunityId: uuid("opportunity_id").references(() => opportunities.id, { onDelete: "set null" }),
    type: text("type", {
      enum: ["new_opportunity", "odds_change", "opportunity_expired", "stale_data", "system", "security"],
    }).notNull(),
    title: text("title").notNull(),
    body: text("body").notNull(),
    data: jsonb("data").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
    dedupeKey: text("dedupe_key").notNull(),
    readAt: ts("read_at"),
    createdAt: createdAt(),
  },
  (t) => [
    uniqueIndex("notifications_user_dedupe_idx").on(t.userId, t.dedupeKey),
    index("notifications_user_created_idx").on(t.userId, t.createdAt),
  ],
);

export const subscriptions = pgTable(
  "subscriptions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    plan: text("plan", { enum: ["free", "premium"] }).notNull(),
    status: text("status", { enum: ["active", "trialing", "canceled", "past_due", "expired"] }).notNull(),
    provider: text("provider", { enum: ["manual", "demo_trial", "stripe"] }).notNull().default("manual"),
    providerCustomerId: text("provider_customer_id"),
    providerSubscriptionId: text("provider_subscription_id"),
    currentPeriodStart: ts("current_period_start").notNull().defaultNow(),
    currentPeriodEnd: ts("current_period_end"),
    cancelAtPeriodEnd: boolean("cancel_at_period_end").notNull().default(false),
    createdAt: createdAt(),
    updatedAt: updatedAt(),
  },
  (t) => [index("subscriptions_user_idx").on(t.userId)],
);

export const savedFilters = pgTable(
  "saved_filters",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    name: text("name").notNull(),
    filters: jsonb("filters").$type<Record<string, unknown>>().notNull(),
    createdAt: createdAt(),
  },
  (t) => [index("saved_filters_user_idx").on(t.userId)],
);

export const userActivity = pgTable(
  "user_activity",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    userId: uuid("user_id")
      .notNull()
      .references(() => profiles.id, { onDelete: "cascade" }),
    action: text("action").notNull(),
    entityType: text("entity_type"),
    entityId: text("entity_id"),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
    createdAt: createdAt(),
  },
  (t) => [index("user_activity_user_created_idx").on(t.userId, t.createdAt)],
);

// ---------------------------------------------------------------------------
// Operations
// ---------------------------------------------------------------------------
export const auditLogs = pgTable(
  "audit_logs",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    actorId: uuid("actor_id").references(() => profiles.id, { onDelete: "set null" }),
    action: text("action").notNull(),
    targetType: text("target_type"),
    targetId: text("target_id"),
    metadata: jsonb("metadata").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
    ip: text("ip"),
    createdAt: createdAt(),
  },
  (t) => [index("audit_logs_created_idx").on(t.createdAt), index("audit_logs_actor_idx").on(t.actorId)],
);

export const featureFlags = pgTable("feature_flags", {
  key: text("key").primaryKey(),
  enabled: boolean("enabled").notNull().default(false),
  description: text("description").notNull().default(""),
  updatedAt: updatedAt(),
});

export const providerRuns = pgTable(
  "provider_runs",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    provider: text("provider").notNull(),
    trigger: text("trigger").notNull(),
    status: text("status", { enum: ["running", "success", "error"] }).notNull(),
    startedAt: ts("started_at").notNull().defaultNow(),
    finishedAt: ts("finished_at"),
    durationMs: integer("duration_ms"),
    eventsCount: integer("events_count").notNull().default(0),
    opportunitiesCount: integer("opportunities_count").notNull().default(0),
    requestsUsed: integer("requests_used"),
    requestsRemaining: integer("requests_remaining"),
    error: text("error"),
  },
  (t) => [index("provider_runs_provider_started_idx").on(t.provider, t.startedAt)],
);

export const errorLogs = pgTable(
  "error_logs",
  {
    id: bigserial("id", { mode: "number" }).primaryKey(),
    level: text("level", { enum: ["error", "warn"] }).notNull().default("error"),
    message: text("message").notNull(),
    path: text("path"),
    context: jsonb("context").$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
    createdAt: createdAt(),
  },
  (t) => [index("error_logs_created_idx").on(t.createdAt)],
);

export type Profile = typeof profiles.$inferSelect;
export type UserPreferences = typeof userPreferences.$inferSelect;
export type Bookmaker = typeof bookmakers.$inferSelect;
export type Sport = typeof sports.$inferSelect;
export type EventRow = typeof events.$inferSelect;
export type MarketRow = typeof markets.$inferSelect;
export type OpportunityRow = typeof opportunities.$inferSelect;
export type AlertRule = typeof alertRules.$inferSelect;
export type NotificationRow = typeof notifications.$inferSelect;
export type SubscriptionRow = typeof subscriptions.$inferSelect;
export type ProviderRun = typeof providerRuns.$inferSelect;
