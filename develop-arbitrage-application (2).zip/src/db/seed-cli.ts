// Usage: npm run db:seed  (applies migrations, seeds reference data and refreshes odds once)
import "dotenv/config";
import path from "node:path";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { db, pool } from "@/db";
import { seedAll } from "@/db/seed";
import { runSync } from "@/lib/services/sync";

async function main() {
  await migrate(db, { migrationsFolder: path.join(process.cwd(), "drizzle") });
  await seedAll();
  const result = await runSync({ trigger: "cli", force: true });
  console.log("Seed complete", result);
  await pool.end();
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
