import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { alertRules, bookmakers, events, markets, opportunities, profiles, sports, userBookmakers, userPreferences } from "@/db/schema";
import { hashPassword } from "@/lib/auth/password";
import { seedConfig } from "@/lib/env";
import { ensureDefaultFlags } from "@/lib/flags";
import { logInfo } from "@/lib/logger";
import { DEMO_BOOKMAKERS } from "@/lib/providers/demo";

const BOOKMAKER_DIRECTORY: Array<{
  key: string;
  name: string;
  country: string;
  currency: string;
  website: string;
  supportedMarkets: string[];
  isExchange?: boolean;
  commissionPct?: number;
}> = [
  { key: "pinnacle", name: "Pinnacle", country: "Curaçao", currency: "USD", website: "https://www.pinnacle.com", supportedMarkets: ["h2h", "totals", "spreads"] },
  { key: "bet365", name: "bet365", country: "United Kingdom", currency: "GBP", website: "https://www.bet365.com", supportedMarkets: ["h2h", "totals", "spreads"] },
  { key: "betfair_ex_eu", name: "Betfair Exchange", country: "United Kingdom", currency: "GBP", website: "https://www.betfair.com/exchange", supportedMarkets: ["h2h", "totals"], isExchange: true, commissionPct: 5 },
  { key: "unibet_eu", name: "Unibet", country: "Malta", currency: "EUR", website: "https://www.unibet.com", supportedMarkets: ["h2h", "totals", "spreads"] },
  { key: "williamhill", name: "William Hill", country: "United Kingdom", currency: "GBP", website: "https://www.williamhill.com", supportedMarkets: ["h2h", "totals"] },
  { key: "betway", name: "Betway", country: "Malta", currency: "EUR", website: "https://www.betway.com", supportedMarkets: ["h2h", "totals", "spreads"] },
  { key: "bwin", name: "bwin", country: "Gibraltar", currency: "EUR", website: "https://www.bwin.com", supportedMarkets: ["h2h", "totals"] },
  { key: "draftkings", name: "DraftKings", country: "United States", currency: "USD", website: "https://sportsbook.draftkings.com", supportedMarkets: ["h2h", "totals", "spreads"] },
  { key: "fanduel", name: "FanDuel", country: "United States", currency: "USD", website: "https://sportsbook.fanduel.com", supportedMarkets: ["h2h", "totals", "spreads"] },
  { key: "marathonbet", name: "Marathon Bet", country: "United Kingdom", currency: "EUR", website: "https://www.marathonbet.com", supportedMarkets: ["h2h", "totals"] },
  { key: "betsson", name: "Betsson", country: "Sweden", currency: "EUR", website: "https://www.betsson.com", supportedMarkets: ["h2h", "totals"] },
];

export async function seedReferenceData(): Promise<void> {
  await ensureDefaultFlags();
  for (const b of BOOKMAKER_DIRECTORY) {
    await db
      .insert(bookmakers)
      .values({ ...b, isExchange: b.isExchange ?? false, commissionPct: b.commissionPct ?? 0 })
      .onConflictDoUpdate({
        target: bookmakers.key,
        set: { name: b.name, country: b.country, currency: b.currency, website: b.website, supportedMarkets: b.supportedMarkets },
      });
  }
  // Make sure every demo bookmaker exists even if the directory above changes.
  for (const b of DEMO_BOOKMAKERS) {
    await db.insert(bookmakers).values({ key: b.key, name: b.title, supportedMarkets: ["h2h", "totals"] }).onConflictDoNothing();
  }
}

export async function seedUsersIfEmpty(): Promise<void> {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(profiles);
  if (count > 0) return;
  const cfg = seedConfig();
  const now = new Date();

  const [admin] = await db
    .insert(profiles)
    .values({ email: cfg.adminEmail, passwordHash: await hashPassword(cfg.adminPassword), displayName: "Admin", role: "admin", emailVerifiedAt: now })
    .returning();
  const [demo] = await db
    .insert(profiles)
    .values({ email: cfg.demoEmail, passwordHash: await hashPassword(cfg.demoPassword), displayName: "Demo Trader", role: "user", emailVerifiedAt: now })
    .returning();

  await db.insert(userPreferences).values([{ userId: admin.id }, { userId: demo.id, preferredSports: ["soccer", "tennis"], preferredMarkets: ["h2h"] }]);

  const books = await db.select({ id: bookmakers.id, key: bookmakers.key }).from(bookmakers);
  const demoBooks = books.filter((b) => ["pinnacle", "bet365", "betfair_ex_eu", "unibet_eu", "betway"].includes(b.key));
  if (demoBooks.length) {
    await db.insert(userBookmakers).values(demoBooks.map((b) => ({ userId: demo.id, bookmakerId: b.id, available: true })));
  }
  await db.insert(alertRules).values({
    userId: demo.id,
    name: "Soccer & tennis ≥ 1%",
    minMarginPct: 1,
    sports: ["soccer", "tennis"],
    markets: [],
    bookmakers: [],
    channels: ["in_app"],
    enabled: true,
  });
  logInfo("Seeded admin and demo accounts", { adminEmail: cfg.adminEmail, demoEmail: cfg.demoEmail });
}

/** A handful of historical (expired) demo opportunities so the history screen is meaningful on first run. */
export async function seedDemoHistoryIfEmpty(): Promise<void> {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(opportunities).where(eq(opportunities.status, "expired"));
  if (count > 0) return;
  const [soccer] = await db
    .insert(sports)
    .values({ key: "soccer_epl", title: "English Premier League", groupName: "Soccer", active: true })
    .onConflictDoUpdate({ target: sports.key, set: { active: true } })
    .returning();
  const samples = [
    { home: "Brentford", away: "Crystal Palace", daysAgo: 1, margin: 1.84, legs: [["Brentford", "pinnacle", "Pinnacle", 2.62], ["Draw", "betway", "Betway", 3.75], ["Crystal Palace", "unibet_eu", "Unibet", 3.3]] },
    { home: "Nottingham Forest", away: "Bournemouth", daysAgo: 2, margin: 0.92, legs: [["Nottingham Forest", "bet365", "bet365", 2.55], ["Draw", "pinnacle", "Pinnacle", 3.6], ["Bournemouth", "williamhill", "William Hill", 3.45]] },
    { home: "Leicester", away: "Ipswich", daysAgo: 3, margin: 2.41, legs: [["Leicester", "betfair_ex_eu", "Betfair Exchange", 2.3], ["Draw", "bwin", "bwin", 3.9], ["Ipswich", "marathonbet", "Marathon Bet", 4.1]] },
    { home: "Southampton", away: "Leeds", daysAgo: 5, margin: 1.12, legs: [["Southampton", "unibet_eu", "Unibet", 2.9], ["Draw", "betsson", "Betsson", 3.55], ["Leeds", "pinnacle", "Pinnacle", 2.95]] },
  ] as const;
  for (const s of samples) {
    const commence = new Date(Date.now() - s.daysAgo * 86_400_000);
    const [ev] = await db
      .insert(events)
      .values({
        provider: "demo",
        externalId: `demo-history-${s.home}-${s.away}`,
        fingerprint: `soccer_epl|${s.home.toLowerCase()}|${s.away.toLowerCase()}|${commence.toISOString().slice(0, 13)}`,
        sportId: soccer.id,
        sportKey: "soccer_epl",
        league: "English Premier League",
        homeTeam: s.home,
        awayTeam: s.away,
        commenceTime: commence,
        status: "finished",
      })
      .onConflictDoNothing()
      .returning();
    if (!ev) continue;
    const [market] = await db
      .insert(markets)
      .values({ eventId: ev.id, marketKey: "h2h", line: 0, outcomeCount: 3, outcomes: s.legs.map((l) => l[0]) })
      .returning();
    const legs = s.legs.map(([outcome, bookmakerKey, bookmakerName, odds]) => ({ outcome, bookmakerKey, bookmakerName, odds, updatedAt: commence.toISOString() }));
    const impliedSum = legs.reduce((a, l) => a + 1 / l.odds, 0);
    await db.insert(opportunities).values({
      eventId: ev.id,
      marketId: market.id,
      sportKey: "soccer_epl",
      marketKey: "h2h",
      status: "expired",
      impliedSum,
      marginPct: (1 - impliedSum) * 100,
      peakMarginPct: s.margin,
      outcomeCount: 3,
      legs,
      provider: "demo",
      isDemo: true,
      firstSeenAt: new Date(commence.getTime() - 5 * 3600_000),
      lastSeenAt: new Date(commence.getTime() - 20 * 60_000),
      expiredAt: new Date(commence.getTime() - 15 * 60_000),
      expiredReason: "odds_moved",
      dataUpdatedAt: new Date(commence.getTime() - 20 * 60_000),
    });
  }
}

export async function seedAll(): Promise<void> {
  await seedReferenceData();
  await seedUsersIfEmpty();
  await seedDemoHistoryIfEmpty();
}
