import type { NextRequest } from "next/server";
import { ZodError, type ZodType } from "zod";
import { getSessionUser, type AuthUser } from "@/lib/auth/session";
import { HttpError } from "@/lib/http-error";
import { logError } from "@/lib/logger";

export { HttpError };

export type RouteContext = { params: Promise<Record<string, string>> };
type Handler = (req: NextRequest, ctx: RouteContext) => Promise<Response>;

/** Wrap a route handler with consistent error handling and logging (no sensitive data). */
export function handle(fn: Handler): Handler {
  return async (req, ctx) => {
    try {
      return await fn(req, ctx);
    } catch (err) {
      if (err instanceof HttpError) {
        const headers: Record<string, string> = {};
        const retry = (err.details as { retryAfterSec?: number } | undefined)?.retryAfterSec;
        if (err.status === 429 && retry) headers["Retry-After"] = String(retry);
        return Response.json({ error: err.message, code: err.code, details: err.details ?? null }, { status: err.status, headers });
      }
      if (err instanceof ZodError) {
        return Response.json({ error: firstIssue(err), code: "validation", details: err.issues }, { status: 400 });
      }
      await logError("Unhandled API error", err, { path: req.nextUrl.pathname, method: req.method });
      return Response.json({ error: "Something went wrong on our side. Please try again.", code: "internal" }, { status: 500 });
    }
  };
}

export function firstIssue(err: ZodError): string {
  const issue = err.issues[0];
  if (!issue) return "Validation failed";
  const path = issue.path.length ? `${issue.path.join(".")}: ` : "";
  return `${path}${issue.message}`;
}

export async function requireUser(): Promise<AuthUser> {
  const user = await getSessionUser();
  if (!user) throw new HttpError(401, "Please sign in to continue.", "unauthorized");
  return user;
}

export async function requireAdmin(): Promise<AuthUser> {
  const user = await requireUser();
  if (user.role !== "admin") throw new HttpError(403, "Administrator access required.", "forbidden");
  return user;
}

export function requireVerified(user: AuthUser): void {
  if (!user.emailVerified) throw new HttpError(403, "Please verify your e-mail address to use this feature.", "email_unverified");
}

export async function parseBody<T>(req: Request, schema: ZodType<T>): Promise<T> {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    throw new HttpError(400, "Invalid JSON body.", "bad_json");
  }
  const result = schema.safeParse(body);
  if (!result.success) throw new HttpError(400, firstIssue(result.error), "validation", result.error.issues);
  return result.data;
}

export function parseQuery<T>(req: NextRequest, schema: ZodType<T>): T {
  const obj: Record<string, string> = {};
  req.nextUrl.searchParams.forEach((v, k) => {
    obj[k] = v;
  });
  const result = schema.safeParse(obj);
  if (!result.success) throw new HttpError(400, firstIssue(result.error), "validation", result.error.issues);
  return result.data;
}

export function ok<T>(data: T, init?: ResponseInit): Response {
  return Response.json(data, init);
}
