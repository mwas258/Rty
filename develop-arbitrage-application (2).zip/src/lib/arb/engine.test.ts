import { describe, expect, it } from "vitest";
import {
  allocateStakes,
  breakEvenOdds,
  calculateArbitrage,
  dataFreshness,
  detectBestOdds,
  impliedSum,
  marginFromSum,
  oddsMovement,
  roundStake,
  validateOdds,
} from "./engine";

describe("implied probabilities and margin", () => {
  it("computes the implied sum and margin for a two-way market", () => {
    const sum = impliedSum([2.1, 2.1]);
    expect(sum).toBeCloseTo(0.952381, 5);
    expect(marginFromSum(sum)).toBeCloseTo(4.7619, 3);
  });

  it("treats an implied sum of exactly 1 as no arbitrage (boundary)", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 2 },
        { label: "B", odds: 2 },
      ],
      { totalStake: 100 },
    );
    expect(result.ok).toBe(true);
    expect(result.impliedSum).toBeCloseTo(1, 10);
    expect(result.marginPct).toBeCloseTo(0, 10);
    expect(result.isArbitrage).toBe(false);
    expect(result.minProfit).toBeCloseTo(0, 2);
    expect(result.warnings.join(" ")).toMatch(/No theoretical arbitrage/);
  });

  it("flags a losing book (S > 1) as not an arbitrage with a negative profit", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 1.9 },
        { label: "B", odds: 1.9 },
      ],
      { totalStake: 100 },
    );
    expect(result.isArbitrage).toBe(false);
    expect(result.minProfit).toBeLessThan(0);
  });
});

describe("two-way calculation", () => {
  it("allocates stakes proportionally and returns equal profit on each outcome", () => {
    const result = calculateArbitrage(
      [
        { label: "Home", odds: 2.1, bookmaker: "A" },
        { label: "Away", odds: 2.1, bookmaker: "B" },
      ],
      { totalStake: 100 },
    );
    expect(result.ok).toBe(true);
    expect(result.isArbitrage).toBe(true);
    expect(result.legs[0].stake).toBeCloseTo(50, 2);
    expect(result.legs[1].stake).toBeCloseTo(50, 2);
    expect(result.legs[0].grossReturn).toBeCloseTo(105, 2);
    expect(result.minProfit).toBeCloseTo(5, 2);
    expect(result.maxProfit).toBeCloseTo(5, 2);
    expect(result.netProfit).toBeCloseTo(5, 2);
    expect(result.totalStaked).toBeCloseTo(100, 2);
  });

  it("uses the formula stake_i = T * (1/o_i) / S", () => {
    const stakes = allocateStakes([1.95, 2.35], 1000);
    const s = 1 / 1.95 + 1 / 2.35;
    expect(stakes[0]).toBeCloseTo((1000 * (1 / 1.95)) / s, 6);
    expect(stakes[1]).toBeCloseTo((1000 * (1 / 2.35)) / s, 6);
    expect(stakes[0] + stakes[1]).toBeCloseTo(1000, 6);
  });
});

describe("three-way calculation", () => {
  it("handles 1X2 markets", () => {
    const result = calculateArbitrage(
      [
        { label: "Home", odds: 2.7 },
        { label: "Draw", odds: 3.6 },
        { label: "Away", odds: 3.4 },
      ],
      { totalStake: 300 },
    );
    const s = 1 / 2.7 + 1 / 3.6 + 1 / 3.4;
    expect(result.ok).toBe(true);
    expect(result.isArbitrage).toBe(true);
    expect(result.impliedSum).toBeCloseTo(s, 8);
    expect(result.marginPct).toBeCloseTo((1 - s) * 100, 6);
    expect(result.legs).toHaveLength(3);
    // every outcome returns roughly the same gross amount
    const returns = result.legs.map((l) => l.grossReturn);
    expect(Math.max(...returns) - Math.min(...returns)).toBeLessThan(0.05);
    expect(result.minProfit).toBeGreaterThan(0);
    expect(result.minProfit).toBeCloseTo(300 / s - 300, 1);
  });
});

describe("validation", () => {
  it("rejects fewer than two outcomes", () => {
    expect(validateOdds([{ label: "A", odds: 2 }])).toContain("At least two outcomes are required.");
    expect(calculateArbitrage([{ label: "A", odds: 2 }], { totalStake: 100 }).ok).toBe(false);
  });

  it("rejects odds of 1.00, zero, negative and non-numeric values", () => {
    const errors = validateOdds([
      { label: "A", odds: 1 },
      { label: "B", odds: 0 },
      { label: "C", odds: -3 },
      { label: "D", odds: Number.NaN },
    ]);
    expect(errors).toHaveLength(4);
  });

  it("rejects a non-positive total stake", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 2.2 },
        { label: "B", odds: 2.2 },
      ],
      { totalStake: 0 },
    );
    expect(result.ok).toBe(false);
    expect(result.errors.join(" ")).toMatch(/Total stake/);
  });
});

describe("rounding adjustments", () => {
  it("rounds stakes to the configured step and recomputes profit from the rounded outlay", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 1.95 },
        { label: "B", odds: 2.35 },
      ],
      { totalStake: 100, roundingStep: 1, roundingMode: "nearest" },
    );
    expect(result.legs[0].stake).toBe(55);
    expect(result.legs[1].stake).toBe(45);
    expect(result.totalStaked).toBe(100);
    expect(result.legs[0].profit).toBeCloseTo(55 * 1.95 - 100, 2);
    expect(result.legs[1].profit).toBeCloseTo(45 * 2.35 - 100, 2);
    expect(result.minProfit).toBeCloseTo(5.75, 2);
  });

  it("supports rounding down/up and warns when the total changes", () => {
    expect(roundStake(54.65, 5, "down")).toBe(50);
    expect(roundStake(54.65, 5, "up")).toBe(55);
    const result = calculateArbitrage(
      [
        { label: "A", odds: 1.95 },
        { label: "B", odds: 2.35 },
      ],
      { totalStake: 100, roundingStep: 10, roundingMode: "down" },
    );
    expect(result.totalStaked).toBe(90);
    expect(result.warnings.some((w) => w.includes("Rounding"))).toBe(true);
  });

  it("warns about minimum stake rules", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 2.1 },
        { label: "B", odds: 2.1 },
      ],
      { totalStake: 100, minStake: 60 },
    );
    expect(result.warnings.some((w) => w.includes("below the minimum stake"))).toBe(true);
  });
});

describe("fees and net profit", () => {
  it("subtracts commission, FX and fixed costs from the worst-case profit", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 2.1 },
        { label: "B", odds: 2.1 },
      ],
      { totalStake: 100, fees: { commissionPct: 5, fxPct: 1, fixedCosts: 0.5 } },
    );
    // winnings per leg = 105 - 50 = 55 -> 5% commission = 2.75
    expect(result.legs[0].commission).toBeCloseTo(2.75, 2);
    expect(result.fees.fx).toBeCloseTo(1, 2);
    expect(result.fees.fixed).toBeCloseTo(0.5, 2);
    expect(result.netProfit).toBeCloseTo(5 - 2.75 - 1 - 0.5, 2);
    expect(result.netRoiPct).toBeCloseTo(0.75, 2);
  });

  it("warns when fees wipe out the edge", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 2.02 },
        { label: "B", odds: 2.02 },
      ],
      { totalStake: 100, fees: { commissionPct: 10 } },
    );
    expect(result.isArbitrage).toBe(true);
    expect(result.netProfit).toBeLessThanOrEqual(0);
    expect(result.warnings.some((w) => w.includes("remove the theoretical edge"))).toBe(true);
  });

  it("ignores negative or absurd fee inputs", () => {
    const result = calculateArbitrage(
      [
        { label: "A", odds: 2.1 },
        { label: "B", odds: 2.1 },
      ],
      { totalStake: 100, fees: { commissionPct: -5, fxPct: Number.NaN } },
    );
    expect(result.netProfit).toBeCloseTo(5, 2);
  });
});

describe("detection helpers", () => {
  it("selects the best price per outcome and detects an arbitrage", () => {
    const res = detectBestOdds(["Home", "Away"], {
      Home: [
        { bookmakerKey: "a", bookmakerName: "A", price: 1.9, updatedAt: "2025-01-01T00:00:00Z" },
        { bookmakerKey: "b", bookmakerName: "B", price: 2.12, updatedAt: "2025-01-01T00:00:00Z" },
      ],
      Away: [
        { bookmakerKey: "a", bookmakerName: "A", price: 2.08, updatedAt: "2025-01-01T00:00:00Z" },
        { bookmakerKey: "b", bookmakerName: "B", price: 1.85, updatedAt: "2025-01-01T00:00:00Z" },
      ],
    });
    expect(res.complete).toBe(true);
    expect(res.legs.map((l) => l.bookmakerKey)).toEqual(["b", "a"]);
    expect(res.isArbitrage).toBe(true);
    expect(res.marginPct).toBeGreaterThan(0);
  });

  it("returns incomplete when an outcome has no valid price", () => {
    const res = detectBestOdds(["Home", "Away"], { Home: [{ bookmakerKey: "a", bookmakerName: "A", price: 2, updatedAt: "" }] });
    expect(res.complete).toBe(false);
  });

  it("computes break-even odds for the remaining outcome", () => {
    expect(breakEvenOdds([2])).toBeCloseTo(2, 6);
    expect(breakEvenOdds([1.5])).toBeCloseTo(3, 6);
    expect(breakEvenOdds([1.2, 1.2])).toBeNull();
  });
});

describe("warnings", () => {
  it("classifies data freshness", () => {
    const now = new Date("2025-01-01T12:00:00Z");
    expect(dataFreshness(new Date("2025-01-01T11:59:00Z"), now).level).toBe("fresh");
    expect(dataFreshness(new Date("2025-01-01T11:50:00Z"), now).level).toBe("aging");
    expect(dataFreshness(new Date("2025-01-01T10:00:00Z"), now).level).toBe("stale");
  });

  it("raises an odds movement warning past the threshold", () => {
    expect(oddsMovement(2.0, 2.01).warning).toBeNull();
    expect(oddsMovement(2.0, 1.9).warning).toMatch(/moved down/);
    expect(oddsMovement(2.0, 2.2).direction).toBe("up");
  });
});
