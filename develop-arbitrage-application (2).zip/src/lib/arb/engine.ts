/**
 * Arbitrage Finder Pro – core arbitrage engine.
 *
 * Pure, dependency-free TypeScript so it can be shared with a future React Native app.
 *
 * Definitions (decimal odds o1..on):
 *   implied probability   p_i = 1 / o_i
 *   implied sum           S   = Σ p_i
 *   theoretical arbitrage exists when S < 1 (before fees and real-world costs)
 *   margin %              (1 - S) * 100
 *   stake allocation      stake_i = T * p_i / S
 *   gross return          stake_i * o_i
 *   profit per outcome    gross return - total staked
 *
 * IMPORTANT: results describe *theoretical* opportunities. Odds move, bets get
 * limited or voided, and fees apply. Nothing here is a guaranteed return.
 */

export type RoundingMode = "none" | "nearest" | "down" | "up";

export interface ArbLegInput {
  label: string;
  odds: number;
  bookmaker?: string | null;
}

export interface FeeConfig {
  /** Commission charged on net winnings of the winning leg (exchange style), percent. */
  commissionPct?: number;
  /** Currency conversion / payment cost applied to the total outlay, percent. */
  fxPct?: number;
  /** Fixed costs (withdrawal fees, etc.) in stake currency. */
  fixedCosts?: number;
}

export interface ArbCalcOptions {
  totalStake: number;
  fees?: FeeConfig;
  roundingStep?: number;
  roundingMode?: RoundingMode;
  minStake?: number;
}

export interface ArbLegResult {
  label: string;
  bookmaker: string | null;
  odds: number;
  impliedProbability: number;
  /** Share of the implied sum (p_i / S). */
  weight: number;
  stake: number;
  grossReturn: number;
  profit: number;
  commission: number;
  netProfit: number;
}

export interface ArbCalcResult {
  ok: boolean;
  errors: string[];
  warnings: string[];
  impliedSum: number;
  marginPct: number;
  isArbitrage: boolean;
  totalStake: number;
  totalStaked: number;
  legs: ArbLegResult[];
  minProfit: number;
  maxProfit: number;
  minRoiPct: number;
  fees: { commission: number; fx: number; fixed: number; total: number };
  netProfit: number;
  netRoiPct: number;
}

export const MAX_LEGS = 12;
export const MIN_ODDS = 1.0;
export const MAX_ODDS = 1000;

export function round2(value: number): number {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

export function impliedProbability(odds: number): number {
  return 1 / odds;
}

export function impliedSum(odds: number[]): number {
  return odds.reduce((acc, o) => acc + 1 / o, 0);
}

export function marginFromSum(sum: number): number {
  return (1 - sum) * 100;
}

export function validateOdds(legs: ArbLegInput[]): string[] {
  const errors: string[] = [];
  if (!Array.isArray(legs) || legs.length < 2) {
    errors.push("At least two outcomes are required.");
    return errors;
  }
  if (legs.length > MAX_LEGS) errors.push(`At most ${MAX_LEGS} outcomes are supported.`);
  legs.forEach((leg, i) => {
    const o = leg.odds;
    if (typeof o !== "number" || !Number.isFinite(o)) {
      errors.push(`Outcome ${i + 1}: odds must be a valid number.`);
    } else if (o <= MIN_ODDS) {
      errors.push(`Outcome ${i + 1}: decimal odds must be greater than ${MIN_ODDS.toFixed(2)}.`);
    } else if (o > MAX_ODDS) {
      errors.push(`Outcome ${i + 1}: odds above ${MAX_ODDS} are not supported.`);
    }
  });
  return errors;
}

export function roundStake(value: number, step: number, mode: RoundingMode): number {
  if (!step || step <= 0 || mode === "none") return round2(value);
  const units = value / step;
  const rounded = mode === "down" ? Math.floor(units) : mode === "up" ? Math.ceil(units) : Math.round(units);
  return round2(rounded * step);
}

/** Allocate stakes proportionally to implied probabilities (unrounded). */
export function allocateStakes(odds: number[], totalStake: number): number[] {
  const sum = impliedSum(odds);
  return odds.map((o) => (totalStake * (1 / o)) / sum);
}

export function calculateArbitrage(legs: ArbLegInput[], options: ArbCalcOptions): ArbCalcResult {
  const errors = validateOdds(legs);
  const warnings: string[] = [];
  const totalStake = Number(options.totalStake);
  if (!Number.isFinite(totalStake) || totalStake <= 0) errors.push("Total stake must be greater than zero.");

  const fees = {
    commissionPct: clampPct(options.fees?.commissionPct),
    fxPct: clampPct(options.fees?.fxPct),
    fixedCosts: Math.max(0, Number(options.fees?.fixedCosts) || 0),
  };

  if (errors.length) {
    return emptyResult(errors, totalStake);
  }

  const odds = legs.map((l) => l.odds);
  const sum = impliedSum(odds);
  const marginPct = marginFromSum(sum);
  const isArbitrage = sum < 1;
  if (!isArbitrage) {
    warnings.push("No theoretical arbitrage: the implied probabilities add up to 100% or more.");
  }

  const step = options.roundingStep ?? 0;
  const mode = options.roundingMode ?? (step > 0 ? "nearest" : "none");
  const rawStakes = allocateStakes(odds, totalStake);
  const stakes = rawStakes.map((s) => roundStake(s, step, mode));
  const totalStaked = round2(stakes.reduce((a, b) => a + b, 0));

  if (step > 0 && Math.abs(totalStaked - totalStake) > 0.005) {
    warnings.push(
      `Rounding to ${step} changed the total outlay from ${round2(totalStake)} to ${totalStaked}. Profits below use the rounded total.`,
    );
  }

  const fx = round2((totalStaked * fees.fxPct) / 100);
  const fixed = round2(fees.fixedCosts);

  const legResults: ArbLegResult[] = legs.map((leg, i) => {
    const stake = stakes[i];
    const grossReturn = round2(stake * leg.odds);
    const profit = round2(grossReturn - totalStaked);
    const commission = round2((Math.max(0, grossReturn - stake) * fees.commissionPct) / 100);
    const netProfit = round2(profit - commission - fx - fixed);
    if (stake <= 0) warnings.push(`Outcome ${i + 1} (${leg.label}) rounds to a zero stake. Increase the total stake or reduce the rounding step.`);
    if (options.minStake && stake > 0 && stake < options.minStake) {
      warnings.push(`Outcome ${i + 1} (${leg.label}) stake ${stake} is below the minimum stake of ${options.minStake}.`);
    }
    return {
      label: leg.label,
      bookmaker: leg.bookmaker ?? null,
      odds: leg.odds,
      impliedProbability: 1 / leg.odds,
      weight: 1 / leg.odds / sum,
      stake,
      grossReturn,
      profit,
      commission,
      netProfit,
    };
  });

  const minProfit = Math.min(...legResults.map((l) => l.profit));
  const maxProfit = Math.max(...legResults.map((l) => l.profit));
  const worstLeg = legResults.reduce((w, l) => (l.netProfit < w.netProfit ? l : w), legResults[0]);
  const netProfit = worstLeg.netProfit;
  const commission = worstLeg.commission;

  if (isArbitrage && netProfit <= 0) {
    warnings.push("Fees and costs remove the theoretical edge: the estimated net profit is zero or negative.");
  }

  return {
    ok: true,
    errors: [],
    warnings,
    impliedSum: sum,
    marginPct,
    isArbitrage,
    totalStake,
    totalStaked,
    legs: legResults,
    minProfit,
    maxProfit,
    minRoiPct: totalStaked > 0 ? (minProfit / totalStaked) * 100 : 0,
    fees: { commission, fx, fixed, total: round2(commission + fx + fixed) },
    netProfit,
    netRoiPct: totalStaked > 0 ? (netProfit / totalStaked) * 100 : 0,
  };
}

function clampPct(value: number | undefined): number {
  const n = Number(value);
  if (!Number.isFinite(n) || n < 0) return 0;
  return Math.min(n, 100);
}

function emptyResult(errors: string[], totalStake: number): ArbCalcResult {
  return {
    ok: false,
    errors,
    warnings: [],
    impliedSum: 0,
    marginPct: 0,
    isArbitrage: false,
    totalStake: Number.isFinite(totalStake) ? totalStake : 0,
    totalStaked: 0,
    legs: [],
    minProfit: 0,
    maxProfit: 0,
    minRoiPct: 0,
    fees: { commission: 0, fx: 0, fixed: 0, total: 0 },
    netProfit: 0,
    netRoiPct: 0,
  };
}

// ---------------------------------------------------------------------------
// Opportunity detection helpers (used by the server-side sync service)
// ---------------------------------------------------------------------------
export interface PricedOutcome {
  bookmakerKey: string;
  bookmakerName: string;
  price: number;
  updatedAt: string;
}

export interface BestLeg extends PricedOutcome {
  outcome: string;
}

export interface DetectionResult {
  complete: boolean;
  legs: BestLeg[];
  impliedSum: number;
  marginPct: number;
  isArbitrage: boolean;
}

/**
 * Given the prices offered per outcome by several bookmakers, select the best
 * price for each outcome and evaluate whether a theoretical arbitrage exists.
 */
export function detectBestOdds(outcomes: string[], pricesByOutcome: Record<string, PricedOutcome[]>): DetectionResult {
  const legs: BestLeg[] = [];
  for (const outcome of outcomes) {
    const prices = (pricesByOutcome[outcome] ?? []).filter((p) => Number.isFinite(p.price) && p.price > MIN_ODDS && p.price <= MAX_ODDS);
    if (!prices.length) {
      return { complete: false, legs: [], impliedSum: 0, marginPct: 0, isArbitrage: false };
    }
    const best = prices.reduce((b, p) => (p.price > b.price ? p : b), prices[0]);
    legs.push({ outcome, ...best });
  }
  if (legs.length < 2) return { complete: false, legs: [], impliedSum: 0, marginPct: 0, isArbitrage: false };
  const sum = impliedSum(legs.map((l) => l.price));
  return { complete: true, legs, impliedSum: sum, marginPct: marginFromSum(sum), isArbitrage: sum < 1 };
}

// ---------------------------------------------------------------------------
// Warnings: odds movement & data freshness
// ---------------------------------------------------------------------------
export type FreshnessLevel = "fresh" | "aging" | "stale";

export interface Freshness {
  ageSec: number;
  level: FreshnessLevel;
  label: string;
}

export const FRESHNESS_THRESHOLDS = { freshSec: 180, agingSec: 900 };

export function dataFreshness(updatedAt: string | Date | number, now: Date | number = Date.now(), thresholds = FRESHNESS_THRESHOLDS): Freshness {
  const t = typeof updatedAt === "number" ? updatedAt : new Date(updatedAt).getTime();
  const n = typeof now === "number" ? now : now.getTime();
  const ageSec = Math.max(0, Math.floor((n - t) / 1000));
  if (!Number.isFinite(t)) return { ageSec: Number.POSITIVE_INFINITY, level: "stale", label: "unknown age" };
  const level: FreshnessLevel = ageSec < thresholds.freshSec ? "fresh" : ageSec < thresholds.agingSec ? "aging" : "stale";
  return { ageSec, level, label: formatAge(ageSec) };
}

export function formatAge(ageSec: number): string {
  if (!Number.isFinite(ageSec)) return "unknown";
  if (ageSec < 60) return `${ageSec}s ago`;
  if (ageSec < 3600) return `${Math.floor(ageSec / 60)}m ago`;
  if (ageSec < 86400) return `${Math.floor(ageSec / 3600)}h ago`;
  return `${Math.floor(ageSec / 86400)}d ago`;
}

export interface OddsMovement {
  changedPct: number;
  direction: "up" | "down" | "flat";
  warning: string | null;
}

export function oddsMovement(previousOdds: number, currentOdds: number, thresholdPct = 1): OddsMovement {
  if (!Number.isFinite(previousOdds) || !Number.isFinite(currentOdds) || previousOdds <= 0) {
    return { changedPct: 0, direction: "flat", warning: null };
  }
  const changedPct = ((currentOdds - previousOdds) / previousOdds) * 100;
  const direction = Math.abs(changedPct) < 1e-9 ? "flat" : changedPct > 0 ? "up" : "down";
  const warning =
    Math.abs(changedPct) >= thresholdPct
      ? `Odds moved ${changedPct > 0 ? "up" : "down"} ${Math.abs(changedPct).toFixed(1)}% since the last snapshot. Re-check before placing bets.`
      : null;
  return { changedPct, direction, warning };
}

/** Minimum odds required on the remaining outcome(s) for a theoretical arbitrage. */
export function breakEvenOdds(otherOdds: number[]): number | null {
  const rest = impliedSum(otherOdds);
  if (rest >= 1) return null;
  return 1 / (1 - rest);
}

export const MARKET_LABELS: Record<string, string> = {
  h2h: "Match winner",
  h2h_3_way: "1X2",
  totals: "Totals (over/under)",
  spreads: "Handicap",
};

export function marketLabel(marketKey: string, outcomeCount?: number, line?: number): string {
  const base = marketKey === "h2h" && outcomeCount === 3 ? "1X2 (home/draw/away)" : MARKET_LABELS[marketKey] ?? marketKey;
  if ((marketKey === "totals" || marketKey === "spreads") && line !== undefined && line !== 0) return `${base} ${line}`;
  return base;
}
