import { db } from "@/db";
import { auditLogs, userActivity } from "@/db/schema";

export async function recordAudit(input: {
  actorId: string | null;
  action: string;
  targetType?: string;
  targetId?: string | null;
  metadata?: Record<string, unknown>;
  ip?: string | null;
}): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      actorId: input.actorId,
      action: input.action,
      targetType: input.targetType ?? null,
      targetId: input.targetId ?? null,
      metadata: input.metadata ?? {},
      ip: input.ip ?? null,
    });
  } catch (err) {
    console.error("[audit] failed to record", input.action, err instanceof Error ? err.message : err);
  }
}

export async function trackActivity(
  userId: string,
  action: string,
  entity?: { type: string; id: string | null },
  metadata: Record<string, unknown> = {},
): Promise<void> {
  try {
    await db.insert(userActivity).values({
      userId,
      action,
      entityType: entity?.type ?? null,
      entityId: entity?.id ?? null,
      metadata,
    });
  } catch (err) {
    console.error("[activity] failed to record", action, err instanceof Error ? err.message : err);
  }
}
