import { describe, expect, it } from "vitest";
import { decryptSecret, encryptSecret, hashToken, randomToken } from "./crypto";
import { hashPassword, verifyPassword } from "./password";
import { base32Decode, base32Encode, generateTotpSecret, otpauthUrl, totpCode, verifyTotp } from "./totp";

describe("password hashing", () => {
  it("hashes with scrypt and never stores the plain text", async () => {
    const hash = await hashPassword("CorrectHorse1!");
    expect(hash.startsWith("scrypt$")).toBe(true);
    expect(hash).not.toContain("CorrectHorse1!");
    expect(await verifyPassword("CorrectHorse1!", hash)).toBe(true);
    expect(await verifyPassword("wrong-password", hash)).toBe(false);
  });

  it("produces unique salts and rejects malformed/missing hashes", async () => {
    const [a, b] = await Promise.all([hashPassword("SamePass123"), hashPassword("SamePass123")]);
    expect(a).not.toEqual(b);
    expect(await verifyPassword("SamePass123", null)).toBe(false);
    expect(await verifyPassword("SamePass123", "md5$garbage")).toBe(false);
  });
});

describe("tokens & secrets", () => {
  it("generates url-safe random tokens and deterministic hashes", () => {
    const t = randomToken(32);
    expect(t).toMatch(/^[A-Za-z0-9_-]+$/);
    expect(hashToken(t)).toEqual(hashToken(t));
    expect(hashToken(t)).not.toEqual(hashToken(randomToken(32)));
  });

  it("round-trips encrypted secrets with authenticated encryption", () => {
    const enc = encryptSecret("JBSWY3DPEHPK3PXP");
    expect(enc).not.toContain("JBSWY3DPEHPK3PXP");
    expect(decryptSecret(enc)).toBe("JBSWY3DPEHPK3PXP");
    const tampered = enc.slice(0, -2) + (enc.endsWith("A") ? "BB" : "AA");
    expect(() => decryptSecret(tampered)).toThrow();
  });
});

describe("TOTP (RFC 6238)", () => {
  it("encodes/decodes base32", () => {
    const buf = Buffer.from("Hello!");
    expect(base32Encode(buf)).toBe("JBSWY3DPEE");
    expect(base32Decode("JBSWY3DPEE").toString()).toBe("Hello!");
  });

  it("matches the RFC 6238 SHA-1 test vector", () => {
    // Secret "12345678901234567890" at T = 59s -> 94287082 (8 digits); 6-digit suffix 287082
    const secret = base32Encode(Buffer.from("12345678901234567890"));
    expect(totpCode(secret, 59_000, 30, 8)).toBe("94287082");
    expect(totpCode(secret, 59_000)).toBe("287082");
  });

  it("verifies current codes within the window and rejects others", () => {
    const secret = generateTotpSecret();
    expect(secret).toHaveLength(32);
    expect(verifyTotp(secret, totpCode(secret))).toBe(true);
    expect(verifyTotp(secret, totpCode(secret, Date.now() - 30_000))).toBe(true);
    expect(verifyTotp(secret, totpCode(secret, Date.now() - 5 * 60_000))).toBe(false);
    expect(verifyTotp(secret, "abc")).toBe(false);
    expect(otpauthUrl(secret, "user@example.com")).toContain("otpauth://totp/");
  });
});
