import { randomBytes, scrypt as scryptCb, timingSafeEqual } from "node:crypto";

const PARAMS = { N: 16384, r: 8, p: 1 };
const KEY_LEN = 64;

function scrypt(password: string, salt: Buffer, N: number, r: number, p: number): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    scryptCb(password.normalize("NFKC"), salt, KEY_LEN, { N, r, p, maxmem: 64 * 1024 * 1024 }, (err, key) => {
      if (err) reject(err);
      else resolve(key);
    });
  });
}

/** Hash a password with scrypt (never store plain-text passwords). */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomBytes(16);
  const key = await scrypt(password, salt, PARAMS.N, PARAMS.r, PARAMS.p);
  return `scrypt$${PARAMS.N}$${PARAMS.r}$${PARAMS.p}$${salt.toString("base64")}$${key.toString("base64")}`;
}

export async function verifyPassword(password: string, stored: string | null | undefined): Promise<boolean> {
  if (!stored) {
    // Burn comparable CPU time so missing accounts are not distinguishable by timing.
    await scrypt(password, randomBytes(16), PARAMS.N, PARAMS.r, PARAMS.p);
    return false;
  }
  const [algo, N, r, p, saltB64, hashB64] = stored.split("$");
  if (algo !== "scrypt") return false;
  const expected = Buffer.from(hashB64, "base64");
  const actual = await scrypt(password, Buffer.from(saltB64, "base64"), Number(N), Number(r), Number(p));
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
