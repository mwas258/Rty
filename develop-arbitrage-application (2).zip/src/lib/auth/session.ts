import { and, eq, lt, ne } from "drizzle-orm";
import { cookies } from "next/headers";
import { cache } from "react";
import { db } from "@/db";
import { profiles, sessions, type Profile } from "@/db/schema";
import { hashToken, randomToken } from "@/lib/auth/crypto";
import { appUrl } from "@/lib/env";
import type { AuthUserDTO, SessionDTO } from "@/lib/types";

export const SESSION_COOKIE = "afp_session";
const LONG_TTL_MS = 30 * 24 * 60 * 60 * 1000;
const SHORT_TTL_MS = 24 * 60 * 60 * 1000;

export interface AuthUser {
  id: string;
  email: string;
  displayName: string;
  role: "user" | "admin";
  status: "active" | "disabled";
  emailVerified: boolean;
  mfaEnabled: boolean;
  createdAt: Date;
  sessionId: string;
}

export function toAuthUser(p: Profile, sessionId: string): AuthUser {
  return {
    id: p.id,
    email: p.email,
    displayName: p.displayName,
    role: p.role,
    status: p.status,
    emailVerified: Boolean(p.emailVerifiedAt),
    mfaEnabled: p.mfaEnabled,
    createdAt: p.createdAt,
    sessionId,
  };
}

export function toUserDTO(u: AuthUser): AuthUserDTO {
  return {
    id: u.id,
    email: u.email,
    displayName: u.displayName,
    role: u.role,
    emailVerified: u.emailVerified,
    mfaEnabled: u.mfaEnabled,
    createdAt: u.createdAt.toISOString(),
  };
}

export async function createSession(
  userId: string,
  meta: { userAgent?: string | null; ip?: string | null; remember?: boolean },
): Promise<{ token: string; expiresAt: Date; remember: boolean }> {
  const token = randomToken(32);
  const remember = meta.remember !== false;
  const expiresAt = new Date(Date.now() + (remember ? LONG_TTL_MS : SHORT_TTL_MS));
  await db.insert(sessions).values({
    userId,
    tokenHash: hashToken(token),
    userAgent: meta.userAgent?.slice(0, 300) ?? null,
    ip: meta.ip ?? null,
    expiresAt,
  });
  return { token, expiresAt, remember };
}

export async function attachSessionCookie(token: string, expiresAt: Date, remember = true): Promise<void> {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: appUrl().startsWith("https://"),
    path: "/",
    ...(remember ? { expires: expiresAt } : {}),
  });
}

export async function loginUser(userId: string, meta: { userAgent?: string | null; ip?: string | null; remember?: boolean }) {
  const session = await createSession(userId, meta);
  await attachSessionCookie(session.token, session.expiresAt, session.remember);
  await db.update(profiles).set({ lastLoginAt: new Date() }).where(eq(profiles.id, userId));
}

export async function getUserBySessionToken(token: string): Promise<AuthUser | null> {
  const rows = await db
    .select({ session: sessions, profile: profiles })
    .from(sessions)
    .innerJoin(profiles, eq(sessions.userId, profiles.id))
    .where(eq(sessions.tokenHash, hashToken(token)))
    .limit(1);
  if (!rows.length) return null;
  const { session, profile } = rows[0];
  const now = new Date();
  if (session.expiresAt <= now) {
    await db.delete(sessions).where(eq(sessions.id, session.id));
    return null;
  }
  if (profile.status !== "active") return null;
  if (now.getTime() - session.lastSeenAt.getTime() > 5 * 60 * 1000) {
    db.update(sessions).set({ lastSeenAt: now }).where(eq(sessions.id, session.id)).catch(() => undefined);
  }
  return toAuthUser(profile, session.id);
}

/** Memoised per request: safe to call from layouts, pages and route handlers. */
export const getSessionUser = cache(async (): Promise<AuthUser | null> => {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (!token) return null;
  try {
    return await getUserBySessionToken(token);
  } catch {
    return null;
  }
});

export async function destroyCurrentSession(): Promise<void> {
  const jar = await cookies();
  const token = jar.get(SESSION_COOKIE)?.value;
  if (token) await db.delete(sessions).where(eq(sessions.tokenHash, hashToken(token)));
  jar.delete(SESSION_COOKIE);
}

export async function revokeUserSessions(userId: string, exceptSessionId?: string): Promise<void> {
  const where = exceptSessionId ? and(eq(sessions.userId, userId), ne(sessions.id, exceptSessionId)) : eq(sessions.userId, userId);
  await db.delete(sessions).where(where);
}

export async function listUserSessions(userId: string, currentSessionId: string): Promise<SessionDTO[]> {
  await db.delete(sessions).where(and(eq(sessions.userId, userId), lt(sessions.expiresAt, new Date())));
  const rows = await db.select().from(sessions).where(eq(sessions.userId, userId));
  return rows
    .sort((a, b) => b.lastSeenAt.getTime() - a.lastSeenAt.getTime())
    .map((s) => ({
      id: s.id,
      current: s.id === currentSessionId,
      userAgent: s.userAgent,
      ip: s.ip,
      createdAt: s.createdAt.toISOString(),
      lastSeenAt: s.lastSeenAt.toISOString(),
      expiresAt: s.expiresAt.toISOString(),
    }));
}
