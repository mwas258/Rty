import { and, eq, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { authTokens } from "@/db/schema";
import { hashToken, randomToken } from "@/lib/auth/crypto";

export type TokenType = "verify_email" | "reset_password" | "mfa_challenge";

export const TOKEN_TTL: Record<TokenType, number> = {
  verify_email: 24 * 60 * 60 * 1000,
  reset_password: 60 * 60 * 1000,
  mfa_challenge: 5 * 60 * 1000,
};

/** Issue a single-use token; previous unused tokens of the same type are invalidated. */
export async function issueToken(userId: string, type: TokenType): Promise<string> {
  await db
    .update(authTokens)
    .set({ usedAt: new Date() })
    .where(and(eq(authTokens.userId, userId), eq(authTokens.type, type), isNull(authTokens.usedAt)));
  const raw = randomToken(32);
  await db.insert(authTokens).values({ userId, type, tokenHash: hashToken(raw), expiresAt: new Date(Date.now() + TOKEN_TTL[type]) });
  return raw;
}

export async function findValidToken(raw: string, type: TokenType) {
  const [row] = await db
    .select()
    .from(authTokens)
    .where(and(eq(authTokens.tokenHash, hashToken(raw)), eq(authTokens.type, type), isNull(authTokens.usedAt)))
    .limit(1);
  if (!row || row.expiresAt <= new Date()) return null;
  return row;
}

/** Atomically consume a token. Returns the owning user id or null. */
export async function consumeToken(raw: string, type: TokenType): Promise<string | null> {
  const rows = await db
    .update(authTokens)
    .set({ usedAt: new Date() })
    .where(
      and(
        eq(authTokens.tokenHash, hashToken(raw)),
        eq(authTokens.type, type),
        isNull(authTokens.usedAt),
        sql`${authTokens.expiresAt} > now()`,
      ),
    )
    .returning({ userId: authTokens.userId });
  return rows[0]?.userId ?? null;
}

/** Increment attempts for brute-force protection on short codes (MFA). Returns the new count. */
export async function bumpTokenAttempts(id: string): Promise<number> {
  const rows = await db
    .update(authTokens)
    .set({ attempts: sql`${authTokens.attempts} + 1` })
    .where(eq(authTokens.id, id))
    .returning({ attempts: authTokens.attempts });
  return rows[0]?.attempts ?? 0;
}
