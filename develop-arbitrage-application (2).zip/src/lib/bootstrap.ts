import path from "node:path";
import { migrate } from "drizzle-orm/node-postgres/migrator";
import { db } from "@/db";
import { seedAll } from "@/db/seed";
import { logError, logInfo } from "@/lib/logger";
import { runSync } from "@/lib/services/sync";

let started: Promise<void> | null = null;

/** Idempotent startup routine: migrate → seed → warm odds cache (background). */
export function bootstrap(): Promise<void> {
  if (!started) started = run();
  return started;
}

async function run(): Promise<void> {
  try {
    await migrate(db, { migrationsFolder: path.join(process.cwd(), "drizzle") });
    logInfo("Database migrations applied");
  } catch (err) {
    await logError("Database migration failed (run `npm run db:migrate` or `npm run db:push`)", err);
  }
  try {
    await seedAll();
  } catch (err) {
    await logError("Seeding failed", err);
  }
  void runSync({ trigger: "startup", force: true }).catch((err) => logError("Startup sync failed", err));
}
