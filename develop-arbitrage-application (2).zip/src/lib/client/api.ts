export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
    public details?: unknown,
  ) {
    super(message);
  }
}

type Init = Omit<RequestInit, "body"> & { json?: unknown; body?: BodyInit | null };

/** Small fetch wrapper used by TanStack Query hooks. Redirects to login on 401 inside the app. */
export async function api<T>(path: string, init: Init = {}): Promise<T> {
  const { json, headers, ...rest } = init;
  let res: Response;
  try {
    res = await fetch(path, {
      ...rest,
      credentials: "same-origin",
      headers: { Accept: "application/json", ...(json !== undefined ? { "Content-Type": "application/json" } : {}), ...(headers ?? {}) },
      body: json !== undefined ? JSON.stringify(json) : rest.body,
    });
  } catch {
    throw new ApiError(0, typeof navigator !== "undefined" && !navigator.onLine ? "You appear to be offline." : "Network error. Please try again.", "network");
  }
  const text = await res.text();
  let data: unknown = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) {
    const body = (data ?? {}) as { error?: string; code?: string; details?: unknown };
    if (res.status === 401 && typeof window !== "undefined" && !path.startsWith("/api/auth/")) {
      const p = window.location.pathname;
      if (p.startsWith("/app") || p.startsWith("/admin")) window.location.href = `/login?next=${encodeURIComponent(p)}`;
    }
    throw new ApiError(res.status, body.error ?? `Request failed (${res.status})`, body.code, body.details);
  }
  return data as T;
}

export function errorMessage(err: unknown): string {
  if (err instanceof ApiError) return err.message;
  if (err instanceof Error) return err.message;
  return "Something went wrong.";
}

export function isPlanError(err: unknown): boolean {
  return err instanceof ApiError && err.status === 402;
}
