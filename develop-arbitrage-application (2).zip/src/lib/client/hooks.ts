"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import { api } from "@/lib/client/api";
import type { MeResponse } from "@/lib/types";

export function useMe(enabled = true) {
  return useQuery<MeResponse>({ queryKey: ["me"], queryFn: () => api<MeResponse>("/api/auth/me"), staleTime: 60_000, enabled, retry: false });
}

function subscribeOnline(cb: () => void) {
  window.addEventListener("online", cb);
  window.addEventListener("offline", cb);
  return () => {
    window.removeEventListener("online", cb);
    window.removeEventListener("offline", cb);
  };
}

export function useOnline(): boolean {
  return useSyncExternalStore(subscribeOnline, () => navigator.onLine, () => true);
}

export function useNow(intervalMs = 30_000): number {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs);
    return () => clearInterval(id);
  }, [intervalMs]);
  return now;
}

export function useLogout() {
  const qc = useQueryClient();
  const router = useRouter();
  return useMutation({
    mutationFn: () => api("/api/auth/logout", { method: "POST" }),
    onSettled: () => {
      qc.clear();
      router.push("/login");
      router.refresh();
    },
  });
}

export function useUnreadCount() {
  return useQuery<{ unread: number }>({
    queryKey: ["notifications", "unread"],
    queryFn: () => api<{ unread: number }>("/api/notifications?unread=1&limit=1"),
    refetchInterval: 60_000,
    staleTime: 30_000,
  });
}

// Tiny localStorage-backed store so UI preferences survive reloads without hydration mismatches.
const storeListeners = new Set<() => void>();
function subscribeStore(cb: () => void) {
  storeListeners.add(cb);
  window.addEventListener("storage", cb);
  return () => {
    storeListeners.delete(cb);
    window.removeEventListener("storage", cb);
  };
}

export function readStoredValue(key: string): string | null {
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

export function writeStoredValue(key: string, value: string) {
  try {
    window.localStorage.setItem(key, value);
  } catch {
    /* ignore quota / privacy mode */
  }
  storeListeners.forEach((l) => l());
}

export function useStoredValue(key: string, fallback: string): [string, (v: string) => void] {
  const value = useSyncExternalStore(
    subscribeStore,
    () => readStoredValue(key) ?? fallback,
    () => fallback,
  );
  const set = useCallback((v: string) => writeStoredValue(key, v), [key]);
  return [value, set];
}
