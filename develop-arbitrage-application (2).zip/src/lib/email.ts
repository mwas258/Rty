import { isEmailConfigured } from "@/lib/env";
import { logInfo, logWarn } from "@/lib/logger";

export interface EmailMessage {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

/**
 * E-mail adapter. Uses Resend's REST API when RESEND_API_KEY is configured.
 * Without credentials nothing is sent; callers receive `delivered: false` so the
 * UI can fall back to showing the action link directly (demo mode).
 */
export async function sendEmail(message: EmailMessage): Promise<{ delivered: boolean; error?: string }> {
  if (!isEmailConfigured()) {
    logInfo("E-mail delivery not configured; message suppressed", { to: message.to, subject: message.subject });
    return { delivered: false, error: "not_configured" };
  }
  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM || "Arbitrage Finder Pro <no-reply@example.com>",
        to: [message.to],
        subject: message.subject,
        text: message.text,
        html: message.html ?? `<pre style="font-family:sans-serif">${escapeHtml(message.text)}</pre>`,
      }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) {
      logWarn("E-mail provider rejected message", { status: res.status });
      return { delivered: false, error: `provider_${res.status}` };
    }
    return { delivered: true };
  } catch (err) {
    logWarn("E-mail delivery failed", { error: err instanceof Error ? err.message : String(err) });
    return { delivered: false, error: "network" };
  }
}

export function escapeHtml(value: string): string {
  return value.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c] as string);
}
