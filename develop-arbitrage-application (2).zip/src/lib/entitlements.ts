import { and, desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { subscriptions } from "@/db/schema";
import { HttpError } from "@/lib/http-error";
import type { EntitlementsDTO } from "@/lib/types";

import { PLANS, TRIAL_DAYS, type PlanKey, type PlanLimits } from "@/lib/plans";

export { PLANS, TRIAL_DAYS };
export type { PlanKey, PlanLimits };

export async function getEntitlements(user: { id: string; role: string }): Promise<EntitlementsDTO> {
  const rows = await db.select().from(subscriptions).where(eq(subscriptions.userId, user.id)).orderBy(desc(subscriptions.createdAt));
  const now = new Date();

  // Lazily expire finished trials / periods (server-side source of truth).
  for (const row of rows) {
    if ((row.status === "active" || row.status === "trialing") && row.currentPeriodEnd && row.currentPeriodEnd <= now) {
      await db.update(subscriptions).set({ status: "expired", updatedAt: now }).where(and(eq(subscriptions.id, row.id)));
      row.status = "expired";
    }
  }

  const active = rows.find(
    (s) => s.plan === "premium" && (s.status === "active" || s.status === "trialing") && (!s.currentPeriodEnd || s.currentPeriodEnd > now),
  );
  const trialEligible = !rows.some((s) => s.provider === "demo_trial");

  if (active) {
    return {
      plan: "premium",
      planName: PLANS.premium.name,
      status: active.status,
      limits: PLANS.premium.limits,
      periodEnd: active.currentPeriodEnd ? active.currentPeriodEnd.toISOString() : null,
      cancelAtPeriodEnd: active.cancelAtPeriodEnd,
      isTrial: active.status === "trialing",
      trialEligible: false,
      source: "subscription",
    };
  }
  if (user.role === "admin") {
    return {
      plan: "premium",
      planName: `${PLANS.premium.name} (staff)`,
      status: "active",
      limits: PLANS.premium.limits,
      periodEnd: null,
      cancelAtPeriodEnd: false,
      isTrial: false,
      trialEligible: false,
      source: "admin",
    };
  }
  return {
    plan: "free",
    planName: PLANS.free.name,
    status: "active",
    limits: PLANS.free.limits,
    periodEnd: null,
    cancelAtPeriodEnd: false,
    isTrial: false,
    trialEligible,
    source: "none",
  };
}

export function assertWithinLimit(current: number, max: number, what: string): void {
  if (current >= max) {
    throw new HttpError(402, `Your plan allows up to ${max} ${what}. Upgrade to Premium for more.`, "plan_limit", { max, what });
  }
}

export function assertFeature(allowed: boolean, feature: string): void {
  if (!allowed) throw new HttpError(402, `${feature} is a Premium feature.`, "plan_feature", { feature });
}
