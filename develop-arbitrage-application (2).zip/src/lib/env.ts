// Server-only environment helpers. Never import this file from client components.

const DEV_FALLBACK_SECRET = "dev-only-insecure-secret-change-me";

export function appUrl(): string {
  return (process.env.APP_URL || "http://localhost:3000").replace(/\/$/, "");
}

export function authSecret(): string {
  const secret = process.env.AUTH_SECRET;
  if (!secret || secret.length < 16) {
    if (process.env.NODE_ENV === "production" && process.env.ALLOW_INSECURE_DEV_SECRET !== "true") {
      // Fail loudly only when a real deployment forgot to configure it, but keep local previews working.
      console.warn("[security] AUTH_SECRET is missing or too short. Set a strong secret before deploying publicly.");
    }
    return DEV_FALLBACK_SECRET;
  }
  return secret;
}

export function isGoogleConfigured(): boolean {
  return Boolean(process.env.GOOGLE_CLIENT_ID && process.env.GOOGLE_CLIENT_SECRET);
}

export function isEmailConfigured(): boolean {
  return Boolean(process.env.RESEND_API_KEY);
}

export function isTelegramConfigured(): boolean {
  return Boolean(process.env.TELEGRAM_BOT_TOKEN);
}

export function isPaymentsConfigured(): boolean {
  // Reserved: a payment provider is only wired in after legal/availability verification.
  return false;
}

export function providerConfig() {
  const mode = (process.env.ODDS_PROVIDER || "auto").toLowerCase();
  const apiKey = process.env.ODDS_API_KEY?.trim() || "";
  const useLive = mode === "the-odds-api" || (mode === "auto" && apiKey.length > 0);
  return {
    mode,
    useLive: useLive && apiKey.length > 0,
    apiKey,
    sports: (process.env.ODDS_API_SPORTS || "soccer_epl,basketball_nba,tennis_atp,icehockey_nhl")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean),
    regions: process.env.ODDS_API_REGIONS || "eu,uk",
    markets: process.env.ODDS_API_MARKETS || "h2h,totals",
    refreshIntervalSec: Math.max(60, Number(process.env.ODDS_REFRESH_INTERVAL_SEC) || 600),
  };
}

export function cronSecret(): string | null {
  return process.env.CRON_SECRET?.trim() || null;
}

export function seedConfig() {
  return {
    adminEmail: process.env.SEED_ADMIN_EMAIL || "admin@arbitragefinder.pro",
    adminPassword: process.env.SEED_ADMIN_PASSWORD || "Admin12345!",
    demoEmail: process.env.SEED_DEMO_EMAIL || "demo@arbitragefinder.pro",
    demoPassword: process.env.SEED_DEMO_PASSWORD || "Demo12345!",
  };
}
