import { eq } from "drizzle-orm";
import { db } from "@/db";
import { featureFlags } from "@/db/schema";

export const DEFAULT_FLAGS: Array<{ key: string; enabled: boolean; description: string }> = [
  { key: "provider.live_sync", enabled: true, description: "Allow scheduled/background refreshes from the configured odds provider." },
  { key: "billing.trial_enabled", enabled: true, description: "Let users start a one-time 14-day Premium trial while payments are not configured." },
  { key: "scanner.auto_refresh", enabled: true, description: "Scanner polls for new opportunities automatically." },
  { key: "alerts.external_channels", enabled: true, description: "Dispatch e-mail / Telegram alerts when the integrations are configured." },
  { key: "signup.enabled", enabled: true, description: "Allow new account registrations." },
];

type CacheEntry = { value: boolean; at: number };
const cache = new Map<string, CacheEntry>();
const TTL_MS = 30_000;

export async function getFlag(key: string, fallback = false): Promise<boolean> {
  const hit = cache.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value;
  try {
    const [row] = await db.select().from(featureFlags).where(eq(featureFlags.key, key)).limit(1);
    const value = row ? row.enabled : fallback;
    cache.set(key, { value, at: Date.now() });
    return value;
  } catch {
    return fallback;
  }
}

export async function setFlag(key: string, enabled: boolean): Promise<void> {
  await db
    .insert(featureFlags)
    .values({ key, enabled, description: DEFAULT_FLAGS.find((f) => f.key === key)?.description ?? "" })
    .onConflictDoUpdate({ target: featureFlags.key, set: { enabled, updatedAt: new Date() } });
  cache.set(key, { value: enabled, at: Date.now() });
}

export async function ensureDefaultFlags(): Promise<void> {
  for (const flag of DEFAULT_FLAGS) {
    await db.insert(featureFlags).values(flag).onConflictDoNothing();
  }
}
