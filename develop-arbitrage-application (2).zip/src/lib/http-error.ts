/** Framework-agnostic HTTP error used by services, rate limiting and route handlers. */
export class HttpError extends Error {
  constructor(
    public status: number,
    message: string,
    public code: string = "error",
    public details?: unknown,
  ) {
    super(message);
  }
}
