import { db } from "@/db";
import { errorLogs } from "@/db/schema";

const SENSITIVE = /pass(word)?|token|secret|authorization|cookie|api[-_]?key|session/i;

export function redact(value: unknown, depth = 0): unknown {
  if (depth > 4 || value === null || value === undefined) return value;
  if (Array.isArray(value)) return value.map((v) => redact(v, depth + 1));
  if (typeof value === "object") {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      out[k] = SENSITIVE.test(k) ? "[redacted]" : redact(v, depth + 1);
    }
    return out;
  }
  return value;
}

export function logInfo(message: string, context?: Record<string, unknown>) {
  console.info(JSON.stringify({ level: "info", message, ...(redact(context) as object) }));
}

export function logWarn(message: string, context?: Record<string, unknown>) {
  console.warn(JSON.stringify({ level: "warn", message, ...(redact(context) as object) }));
}

export async function logError(message: string, err?: unknown, context?: Record<string, unknown>) {
  const detail = err instanceof Error ? `${message}: ${err.message}` : message;
  const ctx = (redact(context) as Record<string, unknown>) ?? {};
  console.error(JSON.stringify({ level: "error", message: detail, ...ctx, stack: err instanceof Error ? err.stack?.split("\n").slice(0, 4).join(" | ") : undefined }));
  try {
    await db.insert(errorLogs).values({
      level: "error",
      message: detail.slice(0, 2000),
      path: typeof ctx.path === "string" ? ctx.path : null,
      context: ctx,
    });
  } catch {
    // Never let logging failures break the request.
  }
}
