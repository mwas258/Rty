// Client-safe plan catalogue (no server imports). Entitlement checks live in src/lib/entitlements.ts.
export type PlanKey = "free" | "premium";

export interface PlanLimits {
  maxAlertRules: number;
  maxWatchlist: number;
  maxSavedFilters: number;
  historyDays: number;
  csvExport: boolean;
  advancedFilters: boolean;
  maxCalculators: number;
  /** Max opportunities visible in the scanner (null = unlimited). */
  scannerLimit: number | null;
  externalChannels: boolean;
  dashboardCustomization: boolean;
}

export const PLANS: Record<PlanKey, { name: string; priceLabel: string; tagline: string; limits: PlanLimits }> = {
  free: {
    name: "Free",
    priceLabel: "€0",
    tagline: "Explore the scanner and calculator with core limits.",
    limits: {
      maxAlertRules: 2,
      maxWatchlist: 10,
      maxSavedFilters: 1,
      historyDays: 7,
      csvExport: false,
      advancedFilters: false,
      maxCalculators: 1,
      scannerLimit: 15,
      externalChannels: false,
      dashboardCustomization: false,
    },
  },
  premium: {
    name: "Premium",
    priceLabel: "€19 / month",
    tagline: "Unlimited scanner, advanced filters, more alerts and exports.",
    limits: {
      maxAlertRules: 25,
      maxWatchlist: 200,
      maxSavedFilters: 20,
      historyDays: 90,
      csvExport: true,
      advancedFilters: true,
      maxCalculators: 5,
      scannerLimit: null,
      externalChannels: true,
      dashboardCustomization: true,
    },
  },
};

export const TRIAL_DAYS = 14;
