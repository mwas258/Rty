import type { FetchOddsResult, NormalizedBookmakerMarket, NormalizedEvent, OddsProvider, ProviderHealth, ProviderSport } from "./types";

/**
 * Deterministic demo provider. Produces clearly-labelled sample odds that drift a
 * little every 5 minutes so the scanner, alerts and history have realistic state
 * transitions. It never pretends to be live market data.
 */
export const DEMO_BOOKMAKERS = [
  { key: "pinnacle", title: "Pinnacle", margin: 0.025 },
  { key: "bet365", title: "bet365", margin: 0.05 },
  { key: "betfair_ex_eu", title: "Betfair Exchange", margin: 0.015 },
  { key: "unibet_eu", title: "Unibet", margin: 0.055 },
  { key: "williamhill", title: "William Hill", margin: 0.06 },
  { key: "betway", title: "Betway", margin: 0.06 },
  { key: "bwin", title: "bwin", margin: 0.055 },
  { key: "draftkings", title: "DraftKings", margin: 0.05 },
  { key: "fanduel", title: "FanDuel", margin: 0.05 },
  { key: "marathonbet", title: "Marathon Bet", margin: 0.035 },
  { key: "betsson", title: "Betsson", margin: 0.055 },
];

const SPORTS: ProviderSport[] = [
  { key: "soccer_epl", title: "English Premier League", group: "Soccer", active: true },
  { key: "soccer_spain_la_liga", title: "La Liga", group: "Soccer", active: true },
  { key: "basketball_nba", title: "NBA", group: "Basketball", active: true },
  { key: "tennis_atp", title: "ATP Tour", group: "Tennis", active: true },
  { key: "icehockey_nhl", title: "NHL", group: "Ice Hockey", active: true },
  { key: "americanfootball_nfl", title: "NFL", group: "American Football", active: true },
];

type Fixture = { home: string; away: string; threeWay: boolean; totalsLine?: number; offsetHours: number };

const FIXTURES: Record<string, Fixture[]> = {
  soccer_epl: [
    { home: "Arsenal", away: "Chelsea", threeWay: true, totalsLine: 2.5, offsetHours: 3 },
    { home: "Liverpool", away: "Manchester City", threeWay: true, totalsLine: 2.5, offsetHours: 6 },
    { home: "Tottenham", away: "Newcastle", threeWay: true, totalsLine: 2.5, offsetHours: 9 },
    { home: "Aston Villa", away: "Brighton", threeWay: true, offsetHours: 27 },
    { home: "Everton", away: "West Ham", threeWay: true, totalsLine: 2.5, offsetHours: 30 },
    { home: "Fulham", away: "Wolves", threeWay: true, offsetHours: 51 },
  ],
  soccer_spain_la_liga: [
    { home: "Real Madrid", away: "Barcelona", threeWay: true, totalsLine: 2.5, offsetHours: 5 },
    { home: "Atlético Madrid", away: "Sevilla", threeWay: true, offsetHours: 8 },
    { home: "Real Sociedad", away: "Villarreal", threeWay: true, totalsLine: 2.5, offsetHours: 29 },
    { home: "Athletic Club", away: "Valencia", threeWay: true, offsetHours: 53 },
  ],
  basketball_nba: [
    { home: "Boston Celtics", away: "Miami Heat", threeWay: false, totalsLine: 221.5, offsetHours: 4 },
    { home: "Los Angeles Lakers", away: "Golden State Warriors", threeWay: false, totalsLine: 229.5, offsetHours: 7 },
    { home: "Denver Nuggets", away: "Phoenix Suns", threeWay: false, offsetHours: 10 },
    { home: "Milwaukee Bucks", away: "New York Knicks", threeWay: false, totalsLine: 218.5, offsetHours: 28 },
    { home: "Dallas Mavericks", away: "Oklahoma City Thunder", threeWay: false, offsetHours: 31 },
  ],
  tennis_atp: [
    { home: "C. Alcaraz", away: "J. Sinner", threeWay: false, offsetHours: 2 },
    { home: "N. Djokovic", away: "D. Medvedev", threeWay: false, offsetHours: 5 },
    { home: "A. Zverev", away: "S. Tsitsipas", threeWay: false, offsetHours: 26 },
    { home: "T. Fritz", away: "H. Rune", threeWay: false, offsetHours: 29 },
  ],
  icehockey_nhl: [
    { home: "Toronto Maple Leafs", away: "Boston Bruins", threeWay: false, totalsLine: 6.5, offsetHours: 6 },
    { home: "Edmonton Oilers", away: "Colorado Avalanche", threeWay: false, offsetHours: 9 },
    { home: "New York Rangers", away: "Florida Panthers", threeWay: false, totalsLine: 5.5, offsetHours: 32 },
  ],
  americanfootball_nfl: [
    { home: "Kansas City Chiefs", away: "Buffalo Bills", threeWay: false, totalsLine: 47.5, offsetHours: 50 },
    { home: "Philadelphia Eagles", away: "Dallas Cowboys", threeWay: false, offsetHours: 74 },
  ],
};

function hashStr(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const uniform = (rng: () => number, min: number, max: number) => min + (max - min) * rng();
const r3 = (n: number) => Math.round(n * 1000) / 1000;

export class DemoOddsProvider implements OddsProvider {
  readonly key = "demo";
  readonly name = "Demo data (seeded sample)";
  readonly isDemo = true;
  readonly refreshIntervalSec = 60;
  readonly sportKeys = SPORTS.map((s) => s.key);

  async listSports(): Promise<ProviderSport[]> {
    return SPORTS;
  }

  async health(): Promise<ProviderHealth> {
    return { ok: true, message: "Demo provider active – sample data only.", checkedAt: new Date().toISOString() };
  }

  async fetchOdds(sportKey: string): Promise<FetchOddsResult> {
    const sport = SPORTS.find((s) => s.key === sportKey);
    const fixtures = FIXTURES[sportKey] ?? [];
    if (!sport) return { events: [], fetchedAt: new Date().toISOString() };

    const now = Date.now();
    const dayStart = new Date(now);
    dayStart.setUTCHours(0, 0, 0, 0);
    const bucket = Math.floor(now / (5 * 60 * 1000));
    const bucketStart = bucket * 5 * 60 * 1000;

    const events: NormalizedEvent[] = fixtures.map((fx, index) => {
      const externalId = `demo-${sportKey}-${index + 1}`;
      let commence = dayStart.getTime() + fx.offsetHours * 3600_000;
      while (commence < now + 30 * 60_000) commence += 24 * 3600_000;
      const eventSeed = hashStr(externalId);
      const base = mulberry32(eventSeed);

      // "True" probabilities for this fixture (stable for the day).
      let probs: number[];
      let outcomes: string[];
      if (fx.threeWay) {
        const home = uniform(base, 0.3, 0.55);
        const draw = uniform(base, 0.2, 0.3);
        probs = [home, draw, Math.max(0.1, 1 - home - draw)];
        outcomes = [fx.home, "Draw", fx.away];
      } else {
        const home = uniform(base, 0.35, 0.65);
        probs = [home, 1 - home];
        outcomes = [fx.home, fx.away];
      }

      const bookSubset = DEMO_BOOKMAKERS.filter((_, i) => mulberry32(eventSeed + i * 97)() > 0.3);
      const books = bookSubset.length >= 5 ? bookSubset : DEMO_BOOKMAKERS.slice(0, 6);

      const h2h = this.buildMarket("h2h", 0, outcomes, probs, books, externalId, bucket, bucketStart);
      const markets: NormalizedBookmakerMarket[] = [...h2h];
      if (fx.totalsLine) {
        const overProb = uniform(mulberry32(eventSeed + 7), 0.45, 0.55);
        markets.push(
          ...this.buildMarket("totals", fx.totalsLine, ["Over", "Under"], [overProb, 1 - overProb], books, `${externalId}-tot`, bucket, bucketStart),
        );
      }

      return {
        externalId,
        sportKey,
        sportTitle: sport.title,
        league: sport.title,
        homeTeam: fx.home,
        awayTeam: fx.away,
        commenceTime: new Date(commence).toISOString(),
        bookmakers: markets,
      };
    });

    return { events, fetchedAt: new Date().toISOString() };
  }

  private buildMarket(
    marketKey: string,
    line: number,
    outcomes: string[],
    probs: number[],
    books: typeof DEMO_BOOKMAKERS,
    seedKey: string,
    bucket: number,
    bucketStart: number,
  ): NormalizedBookmakerMarket[] {
    const prices: number[][] = books.map((book, bi) => {
      const rng = mulberry32(hashStr(`${seedKey}:${book.key}:${bucket}`) + bi);
      return probs.map((p) => r3(Math.max(1.01, ((1 - book.margin) / p) * uniform(rng, 0.975, 1.025))));
    });

    // Inject a small theoretical arbitrage on roughly a third of the markets.
    const injectRng = mulberry32(hashStr(`${seedKey}:inject`));
    const injectEligible = injectRng() < 0.38;
    const injectVisible = (hashStr(seedKey) + bucket) % 9 !== 0; // periodically disappears
    if (injectEligible && injectVisible && books.length >= 2) {
      const outcomeIdx = Math.floor(injectRng() * outcomes.length);
      const bookIdx = Math.floor(injectRng() * books.length);
      const targetMargin = uniform(mulberry32(hashStr(`${seedKey}:m:${Math.floor(bucket / 3)}`)), 0.004, 0.032);
      let restSum = 0;
      for (let o = 0; o < outcomes.length; o++) {
        if (o === outcomeIdx) continue;
        restSum += 1 / Math.max(...prices.map((row) => row[o]));
      }
      const neededImplied = 1 - targetMargin - restSum;
      if (neededImplied > 0.02) {
        const fair = 1 / probs[outcomeIdx];
        const boosted = r3(Math.min(1 / neededImplied, fair * 1.6));
        if (boosted > prices[bookIdx][outcomeIdx]) prices[bookIdx][outcomeIdx] = boosted;
      }
    }

    return books.map((book, bi) => {
      const ageRng = mulberry32(hashStr(`${seedKey}:${book.key}:${bucket}:age`));
      const lastUpdate = new Date(bucketStart - Math.floor(uniform(ageRng, 0, 240)) * 1000).toISOString();
      return {
        bookmakerKey: book.key,
        bookmakerTitle: book.title,
        marketKey,
        line,
        lastUpdate,
        outcomes: outcomes.map((name, oi) => ({ name, price: prices[bi][oi], ...(line ? { point: line } : {}) })),
      };
    });
  }
}
