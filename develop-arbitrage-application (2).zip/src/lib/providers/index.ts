import { providerConfig } from "@/lib/env";
import { DemoOddsProvider } from "./demo";
import { TheOddsApiProvider } from "./the-odds-api";
import type { OddsProvider } from "./types";

export type { OddsProvider } from "./types";

let cached: OddsProvider | null = null;

/** Resolve the configured provider. Falls back to seeded demo data when no key is present. */
export function getOddsProvider(): OddsProvider {
  if (cached) return cached;
  const cfg = providerConfig();
  cached = cfg.useLive
    ? new TheOddsApiProvider(cfg.apiKey, cfg.sports, cfg.regions, cfg.markets, cfg.refreshIntervalSec)
    : new DemoOddsProvider();
  return cached;
}

export function isDemoMode(): boolean {
  return getOddsProvider().isDemo;
}
