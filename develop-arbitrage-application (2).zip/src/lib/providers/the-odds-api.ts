import { ProviderError, type FetchOddsResult, type NormalizedEvent, type OddsProvider, type ProviderHealth, type ProviderSport, type ProviderUsage } from "./types";

/**
 * Adapter for The Odds API (https://the-odds-api.com), a licensed commercial odds feed.
 * The key is only ever used server-side. Requests are kept to the configured sports and
 * refresh interval so the account quota is respected.
 *
 * NOTE: this adapter is implemented against the public v4 REST documentation but has not
 * been exercised in this environment because no API key is configured here.
 */
const BASE_URL = "https://api.the-odds-api.com/v4";

interface ApiSport {
  key: string;
  group: string;
  title: string;
  active: boolean;
  has_outrights: boolean;
}

interface ApiOutcome {
  name: string;
  price: number;
  point?: number;
}

interface ApiEvent {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: Array<{
    key: string;
    title: string;
    last_update: string;
    markets: Array<{ key: string; last_update: string; outcomes: ApiOutcome[] }>;
  }>;
}

export class TheOddsApiProvider implements OddsProvider {
  readonly key = "the-odds-api";
  readonly name = "The Odds API";
  readonly isDemo = false;
  private sportsCache: { at: number; data: ProviderSport[] } | null = null;

  constructor(
    private readonly apiKey: string,
    readonly sportKeys: string[],
    private readonly regions: string,
    private readonly markets: string,
    readonly refreshIntervalSec: number,
  ) {}

  private async request<T>(path: string, params: Record<string, string>): Promise<{ data: T; usage: ProviderUsage }> {
    const url = new URL(`${BASE_URL}${path}`);
    url.searchParams.set("apiKey", this.apiKey);
    for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
    let res: Response;
    try {
      res = await fetch(url, { signal: AbortSignal.timeout(15_000), headers: { Accept: "application/json" } });
    } catch (err) {
      throw new ProviderError(`Provider unreachable: ${err instanceof Error ? err.message : "network error"}`, "unavailable");
    }
    const usage: ProviderUsage = {
      requestsUsed: toInt(res.headers.get("x-requests-used")),
      requestsRemaining: toInt(res.headers.get("x-requests-remaining")),
    };
    if (res.status === 401) throw new ProviderError("Provider rejected the API key.", "auth", 401);
    if (res.status === 429) throw new ProviderError("Provider rate limit or quota exceeded.", usage.requestsRemaining === 0 ? "quota" : "rate_limit", 429);
    if (res.status === 422 || res.status === 404) throw new ProviderError(`Provider rejected the request (${res.status}).`, "bad_request", res.status);
    if (!res.ok) throw new ProviderError(`Provider error (${res.status}).`, "unknown", res.status);
    return { data: (await res.json()) as T, usage };
  }

  async listSports(): Promise<ProviderSport[]> {
    if (this.sportsCache && Date.now() - this.sportsCache.at < 60 * 60 * 1000) return this.sportsCache.data;
    const { data } = await this.request<ApiSport[]>("/sports", {});
    const sports = data.map((s) => ({ key: s.key, title: s.title, group: s.group, active: s.active }));
    this.sportsCache = { at: Date.now(), data: sports };
    return sports;
  }

  async fetchOdds(sportKey: string): Promise<FetchOddsResult> {
    const { data, usage } = await this.request<ApiEvent[]>(`/sports/${encodeURIComponent(sportKey)}/odds`, {
      regions: this.regions,
      markets: this.markets,
      oddsFormat: "decimal",
      dateFormat: "iso",
    });
    const events: NormalizedEvent[] = data.map((ev) => ({
      externalId: ev.id,
      sportKey: ev.sport_key,
      sportTitle: ev.sport_title,
      league: ev.sport_title,
      homeTeam: ev.home_team,
      awayTeam: ev.away_team,
      commenceTime: ev.commence_time,
      bookmakers: ev.bookmakers.flatMap((bk) =>
        bk.markets.map((m) => ({
          bookmakerKey: bk.key,
          bookmakerTitle: bk.title,
          marketKey: m.key,
          line: m.outcomes.find((o) => typeof o.point === "number")?.point ?? 0,
          lastUpdate: m.last_update || bk.last_update,
          outcomes: m.outcomes.map((o) => ({ name: o.name, price: Number(o.price), point: o.point })),
        })),
      ),
    }));
    return { events, usage, fetchedAt: new Date().toISOString() };
  }

  async health(): Promise<ProviderHealth> {
    try {
      const { usage } = await this.request<ApiSport[]>("/sports", {});
      return { ok: true, message: "Provider reachable.", checkedAt: new Date().toISOString(), usage };
    } catch (err) {
      return { ok: false, message: err instanceof Error ? err.message : "Provider check failed", checkedAt: new Date().toISOString() };
    }
  }
}

function toInt(value: string | null): number | undefined {
  if (value === null) return undefined;
  const n = Number(value);
  return Number.isFinite(n) ? n : undefined;
}
