/**
 * Provider abstraction. The rest of the app only ever sees normalized shapes,
 * so a provider can be swapped without touching the UI or the services.
 */
export interface ProviderSport {
  key: string;
  title: string;
  group: string;
  active: boolean;
}

export interface NormalizedOutcome {
  name: string;
  price: number;
  point?: number;
}

export interface NormalizedBookmakerMarket {
  bookmakerKey: string;
  bookmakerTitle: string;
  marketKey: string;
  line: number;
  lastUpdate: string;
  outcomes: NormalizedOutcome[];
}

export interface NormalizedEvent {
  externalId: string;
  sportKey: string;
  sportTitle: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  commenceTime: string;
  bookmakers: NormalizedBookmakerMarket[];
}

export interface ProviderUsage {
  requestsUsed?: number;
  requestsRemaining?: number;
}

export interface FetchOddsResult {
  events: NormalizedEvent[];
  usage?: ProviderUsage;
  fetchedAt: string;
}

export interface ProviderHealth {
  ok: boolean;
  message: string;
  checkedAt: string;
  usage?: ProviderUsage;
}

export interface OddsProvider {
  readonly key: string;
  readonly name: string;
  readonly isDemo: boolean;
  readonly refreshIntervalSec: number;
  readonly sportKeys: string[];
  listSports(): Promise<ProviderSport[]>;
  fetchOdds(sportKey: string): Promise<FetchOddsResult>;
  health(): Promise<ProviderHealth>;
}

export type ProviderErrorCode = "auth" | "quota" | "rate_limit" | "bad_request" | "unavailable" | "unknown";

export class ProviderError extends Error {
  constructor(
    message: string,
    public code: ProviderErrorCode,
    public status?: number,
  ) {
    super(message);
  }
}
