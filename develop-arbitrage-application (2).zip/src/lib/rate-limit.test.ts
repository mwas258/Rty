import { describe, expect, it } from "vitest";
import { HttpError } from "./http-error";
import { checkRateLimit, enforceRateLimit, getClientIp } from "./rate-limit";

describe("rate limiter", () => {
  it("allows up to the limit then blocks with a retry hint", () => {
    const key = `test:${Math.random()}`;
    for (let i = 0; i < 3; i++) expect(checkRateLimit(key, 3, 60_000).ok).toBe(true);
    const blocked = checkRateLimit(key, 3, 60_000);
    expect(blocked.ok).toBe(false);
    expect(blocked.retryAfterSec).toBeGreaterThan(0);
  });

  it("throws a 429 HttpError from enforceRateLimit", () => {
    const req = new Request("http://localhost/api/auth/login", { headers: { "x-forwarded-for": "203.0.113.5, 10.0.0.1" } });
    expect(getClientIp(req)).toBe("203.0.113.5");
    const name = `login-test-${Math.random()}`;
    enforceRateLimit(req, name, 1, 60_000);
    expect(() => enforceRateLimit(req, name, 1, 60_000)).toThrowError(HttpError);
    try {
      enforceRateLimit(req, name, 1, 60_000);
    } catch (err) {
      expect((err as HttpError).status).toBe(429);
    }
  });
});
