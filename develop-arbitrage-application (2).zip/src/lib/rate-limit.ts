import { HttpError } from "@/lib/http-error";

/**
 * In-memory sliding-window rate limiter. Suitable for a single server instance;
 * swap for Redis (same interface) when running multiple instances.
 */
type Entry = { count: number; resetAt: number };
const store = new Map<string, Entry>();
let lastSweep = Date.now();

export function checkRateLimit(key: string, limit: number, windowMs: number) {
  const now = Date.now();
  if (now - lastSweep > 60_000) {
    for (const [k, v] of store) if (v.resetAt <= now) store.delete(k);
    lastSweep = now;
  }
  const entry = store.get(key);
  if (!entry || entry.resetAt <= now) {
    store.set(key, { count: 1, resetAt: now + windowMs });
    return { ok: true, remaining: limit - 1, retryAfterSec: 0 };
  }
  entry.count += 1;
  if (entry.count > limit) {
    return { ok: false, remaining: 0, retryAfterSec: Math.max(1, Math.ceil((entry.resetAt - now) / 1000)) };
  }
  return { ok: true, remaining: limit - entry.count, retryAfterSec: 0 };
}

export function getClientIp(req: Request): string {
  const xf = req.headers.get("x-forwarded-for");
  return xf?.split(",")[0]?.trim() || req.headers.get("x-real-ip") || "unknown";
}

export function enforceRateLimit(req: Request, name: string, limit: number, windowMs: number, extraKey = ""): void {
  const result = checkRateLimit(`${name}:${getClientIp(req)}:${extraKey}`, limit, windowMs);
  if (!result.ok) {
    throw new HttpError(429, "Too many attempts. Please wait a moment and try again.", "rate_limited", {
      retryAfterSec: result.retryAfterSec,
    });
  }
}
