import { and, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import {
  alertRules,
  events,
  notifications,
  profiles,
  userPreferences,
  watchlist,
  type AlertRule,
  type OpportunityLeg,
  type OpportunityRow,
  type Profile,
  type UserPreferences,
} from "@/db/schema";
import { marketLabel } from "@/lib/arb/engine";
import { sendEmail } from "@/lib/email";
import { getEntitlements } from "@/lib/entitlements";
import { isEmailConfigured, isTelegramConfigured, appUrl } from "@/lib/env";
import { getFlag } from "@/lib/flags";
import { logError } from "@/lib/logger";
import { sendTelegramMessage } from "@/lib/telegram";
import type { EntitlementsDTO } from "@/lib/types";

export interface OpportunityChange {
  type: "new" | "odds_change" | "expired";
  opportunity: OpportunityRow;
  previousLegs: OpportunityLeg[] | null;
  previousMargin?: number;
}

type NewNotification = typeof notifications.$inferInsert;
type RuleCtx = { rule: AlertRule; profile: Profile; prefs: UserPreferences | null };

const pct = (n: number) => `${n.toFixed(2)}%`;

export function ruleMatches(rule: AlertRule, opp: OpportunityRow, prefs: UserPreferences | null): boolean {
  if (opp.marginPct < rule.minMarginPct) return false;
  if (rule.sports.length) {
    const group = opp.sportKey.split("_")[0];
    if (!rule.sports.includes(opp.sportKey) && !rule.sports.includes(group)) return false;
  }
  if (rule.markets.length && !rule.markets.includes(opp.marketKey)) return false;
  if (rule.bookmakers.length && !opp.legs.every((l) => rule.bookmakers.includes(l.bookmakerKey))) return false;
  if (rule.minNetProfit !== null && rule.minNetProfit !== undefined) {
    const stake = prefs?.defaultStake ?? 100;
    const estimate = (stake * opp.marginPct) / 100 - (stake * (prefs?.defaultFxPct ?? 0)) / 100 - (prefs?.defaultFixedCosts ?? 0);
    if (estimate < rule.minNetProfit) return false;
  }
  return true;
}

/** Evaluate opportunity changes against every enabled rule and create de-duplicated notifications. */
export async function evaluateAlerts(changes: OpportunityChange[]): Promise<number> {
  if (!changes.length) return 0;

  const ruleRows: RuleCtx[] = await db
    .select({ rule: alertRules, profile: profiles, prefs: userPreferences })
    .from(alertRules)
    .innerJoin(profiles, eq(alertRules.userId, profiles.id))
    .leftJoin(userPreferences, eq(userPreferences.userId, profiles.id))
    .where(and(eq(alertRules.enabled, true), eq(profiles.status, "active")));

  // Enforce plan limits server-side: only the first N rules (by creation) are active per user.
  const entitlementCache = new Map<string, EntitlementsDTO>();
  const perUserCount = new Map<string, number>();
  const activeRules: RuleCtx[] = [];
  for (const ctx of ruleRows.sort((a, b) => a.rule.createdAt.getTime() - b.rule.createdAt.getTime())) {
    let ent = entitlementCache.get(ctx.profile.id);
    if (!ent) {
      ent = await getEntitlements({ id: ctx.profile.id, role: ctx.profile.role });
      entitlementCache.set(ctx.profile.id, ent);
    }
    const used = perUserCount.get(ctx.profile.id) ?? 0;
    if (used < ent.limits.maxAlertRules) {
      activeRules.push(ctx);
      perUserCount.set(ctx.profile.id, used + 1);
    }
  }

  const eventIds = [...new Set(changes.map((c) => c.opportunity.eventId))];
  const eventRows = eventIds.length ? await db.select().from(events).where(inArray(events.id, eventIds)) : [];
  const eventMap = new Map(eventRows.map((e) => [e.id, e]));

  const pending: NewNotification[] = [];
  const seenKeys = new Set<string>();
  const push = (n: NewNotification) => {
    const k = `${n.userId}:${n.dedupeKey}`;
    if (seenKeys.has(k)) return;
    seenKeys.add(k);
    pending.push(n);
  };

  for (const change of changes) {
    const opp = change.opportunity;
    const ev = eventMap.get(opp.eventId);
    const title = ev ? `${ev.homeTeam} vs ${ev.awayTeam}` : "Event";
    const market = marketLabel(opp.marketKey, opp.outcomeCount, opp.line);
    const legsText = opp.legs.map((l) => `${l.outcome} @ ${l.odds.toFixed(2)} (${l.bookmakerName})`).join(" · ");
    const base = { opportunityId: opp.id, data: { marginPct: opp.marginPct, sportKey: opp.sportKey, marketKey: opp.marketKey, isDemo: opp.isDemo } };

    if (change.type === "expired") {
      const watchers = await db.select({ userId: watchlist.userId }).from(watchlist).where(eq(watchlist.opportunityId, opp.id));
      const notified = await db
        .selectDistinct({ userId: notifications.userId })
        .from(notifications)
        .where(and(eq(notifications.opportunityId, opp.id), inArray(notifications.type, ["new_opportunity", "odds_change"])));
      const userIds = new Set([...watchers.map((w) => w.userId), ...notified.map((n) => n.userId)]);
      const reason =
        opp.expiredReason === "event_started" ? "the event has started" : opp.expiredReason === "not_offered" ? "the market is no longer offered" : "the odds moved";
      for (const userId of userIds) {
        push({
          ...base,
          userId,
          type: "opportunity_expired",
          title: `Opportunity gone: ${title}`,
          body: `The ${market} opportunity (${pct(opp.marginPct)}) disappeared because ${reason}.`,
          dedupeKey: `opp:${opp.id}:expired:${opp.expiredAt?.getTime() ?? 0}`,
        });
      }
      continue;
    }

    for (const ctx of activeRules) {
      if (!ruleMatches(ctx.rule, opp, ctx.prefs)) continue;
      if (change.type === "new") {
        push({
          ...base,
          userId: ctx.profile.id,
          ruleId: ctx.rule.id,
          type: "new_opportunity",
          title: `${pct(opp.marginPct)} margin: ${title}`,
          body: `${market} — ${legsText}${opp.isDemo ? " (demo data)" : ""}`,
          dedupeKey: `rule:${ctx.rule.id}:opp:${opp.id}:new:${opp.timesSeen}`,
        });
      } else {
        const bucket = Math.round(opp.marginPct * 4) / 4;
        push({
          ...base,
          userId: ctx.profile.id,
          ruleId: ctx.rule.id,
          type: "odds_change",
          title: `Odds moved: ${title}`,
          body: `${market} margin ${pct(change.previousMargin ?? opp.marginPct)} → ${pct(opp.marginPct)}. ${legsText}`,
          dedupeKey: `rule:${ctx.rule.id}:opp:${opp.id}:margin:${bucket}`,
        });
      }
    }
  }

  if (!pending.length) return 0;
  const inserted = await db
    .insert(notifications)
    .values(pending)
    .onConflictDoNothing({ target: [notifications.userId, notifications.dedupeKey] })
    .returning();

  const triggeredRuleIds = [...new Set(inserted.map((n) => n.ruleId).filter((id): id is string => Boolean(id)))];
  if (triggeredRuleIds.length) {
    await db.update(alertRules).set({ lastTriggeredAt: new Date() }).where(inArray(alertRules.id, triggeredRuleIds));
  }

  if (inserted.length && (await getFlag("alerts.external_channels", true))) {
    const byRule = new Map(activeRules.map((r) => [r.rule.id, r]));
    for (const n of inserted) {
      const ctx = n.ruleId ? byRule.get(n.ruleId) : undefined;
      if (!ctx) continue;
      const ent = entitlementCache.get(ctx.profile.id);
      if (!ent?.limits.externalChannels) continue;
      const text = `${n.title}\n${n.body}\n${appUrl()}/app/opportunities/${n.opportunityId ?? ""}`;
      if (ctx.rule.channels.includes("email") && isEmailConfigured() && ctx.prefs?.emailAlerts && ctx.profile.emailVerifiedAt) {
        sendEmail({ to: ctx.profile.email, subject: n.title, text }).catch((err) => logError("Alert e-mail failed", err));
      }
      if (ctx.rule.channels.includes("telegram") && isTelegramConfigured() && ctx.prefs?.telegramAlerts && ctx.prefs.telegramChatId) {
        sendTelegramMessage(ctx.prefs.telegramChatId, text).catch((err) => logError("Alert telegram failed", err));
      }
    }
  }
  return inserted.length;
}

let lastStaleCheck = 0;

/** Notify alert users once per staleness episode when the provider stops delivering fresh data. */
export async function evaluateStaleAlerts(providerKey: string, lastSuccessAt: Date | null): Promise<void> {
  if (Date.now() - lastStaleCheck < 5 * 60_000) return;
  lastStaleCheck = Date.now();
  try {
    const users = await db
      .selectDistinct({ userId: alertRules.userId })
      .from(alertRules)
      .innerJoin(profiles, eq(alertRules.userId, profiles.id))
      .where(and(eq(alertRules.enabled, true), eq(profiles.status, "active")));
    if (!users.length) return;
    const key = `stale:${providerKey}:${lastSuccessAt ? lastSuccessAt.toISOString() : "never"}`;
    await db
      .insert(notifications)
      .values(
        users.map((u) => ({
          userId: u.userId,
          type: "stale_data" as const,
          title: "Odds data is stale",
          body: lastSuccessAt
            ? `The last successful provider refresh was at ${lastSuccessAt.toISOString()}. Opportunities may be outdated – treat them with caution.`
            : "No successful provider refresh has completed yet.",
          data: { providerKey },
          dedupeKey: key,
        })),
      )
      .onConflictDoNothing({ target: [notifications.userId, notifications.dedupeKey] });
  } catch (err) {
    await logError("Stale alert evaluation failed", err);
  }
}
