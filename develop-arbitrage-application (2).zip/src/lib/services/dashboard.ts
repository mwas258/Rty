import { and, desc, eq, gte, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookmakers, events, notifications, opportunities, sports, userActivity, userBookmakers, userPreferences, watchlist } from "@/db/schema";
import type { AuthUser } from "@/lib/auth/session";
import { getEntitlements } from "@/lib/entitlements";
import type { DashboardResponse } from "@/lib/types";
import { getProviderStatus, getWatchedIds, toOpportunityDTO } from "./opportunities";

export async function getDashboard(user: AuthUser): Promise<DashboardResponse> {
  const [stats] = await db
    .select({
      active: sql<number>`count(*) filter (where ${opportunities.status} = 'active')::int`,
      avg: sql<number>`coalesce(avg(${opportunities.marginPct}) filter (where ${opportunities.status} = 'active'), 0)::float`,
      best: sql<number>`coalesce(max(${opportunities.marginPct}) filter (where ${opportunities.status} = 'active'), 0)::float`,
      expired24: sql<number>`count(*) filter (where ${opportunities.status} = 'expired' and ${opportunities.expiredAt} > now() - interval '24 hours')::int`,
    })
    .from(opportunities);

  const [[{ savedBookmakers }], [{ totalBookmakers }], [{ watchlistCount }], [{ unread }], prefsRow] = await Promise.all([
    db
      .select({ savedBookmakers: sql<number>`count(*)::int` })
      .from(userBookmakers)
      .where(and(eq(userBookmakers.userId, user.id), eq(userBookmakers.available, true))),
    db.select({ totalBookmakers: sql<number>`count(*)::int` }).from(bookmakers).where(eq(bookmakers.active, true)),
    db.select({ watchlistCount: sql<number>`count(*)::int` }).from(watchlist).where(eq(watchlist.userId, user.id)),
    db
      .select({ unread: sql<number>`count(*)::int` })
      .from(notifications)
      .where(and(eq(notifications.userId, user.id), isNull(notifications.readAt))),
    db.select().from(userPreferences).where(eq(userPreferences.userId, user.id)).limit(1),
  ]);

  const watched = await getWatchedIds(user.id);
  const topRows = await db
    .select({ opp: opportunities, ev: events, sportTitle: sports.title })
    .from(opportunities)
    .innerJoin(events, eq(opportunities.eventId, events.id))
    .innerJoin(sports, eq(events.sportId, sports.id))
    .where(and(eq(opportunities.status, "active"), gte(events.commenceTime, new Date())))
    .orderBy(desc(opportunities.marginPct))
    .limit(5);

  const activityRows = await db.select().from(userActivity).where(eq(userActivity.userId, user.id)).orderBy(desc(userActivity.createdAt)).limit(8);
  const notificationRows = await db.select().from(notifications).where(eq(notifications.userId, user.id)).orderBy(desc(notifications.createdAt)).limit(5);
  const [entitlements, provider] = await Promise.all([getEntitlements(user), getProviderStatus()]);

  return {
    stats: {
      activeOpportunities: stats.active,
      averageMarginPct: stats.avg,
      bestMarginPct: stats.best,
      savedBookmakers,
      totalBookmakers,
      watchlistCount,
      unreadNotifications: unread,
      expiredLast24h: stats.expired24,
    },
    topOpportunities: topRows.map((r) => toOpportunityDTO(r.opp, r.ev, r.sportTitle, watched.has(r.opp.id))),
    recentActivity: activityRows.map((a) => ({
      id: a.id,
      action: a.action,
      entityType: a.entityType,
      entityId: a.entityId,
      metadata: a.metadata,
      createdAt: a.createdAt.toISOString(),
    })),
    recentNotifications: notificationRows.map((n) => ({
      id: n.id,
      type: n.type,
      title: n.title,
      body: n.body,
      data: n.data,
      opportunityId: n.opportunityId,
      readAt: n.readAt ? n.readAt.toISOString() : null,
      createdAt: n.createdAt.toISOString(),
    })),
    entitlements,
    provider,
    widgets: prefsRow[0]?.dashboardWidgets ?? ["opportunities", "margin", "bookmakers", "activity", "subscription"],
  };
}
