import { and, asc, desc, eq, gte, ilike, inArray, like, lte, or, sql, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { bookmakers, events, oddsSnapshots, opportunities, sports, userBookmakers, watchlist, type EventRow, type OpportunityLeg, type OpportunityRow } from "@/db/schema";
import { dataFreshness, detectBestOdds, marketLabel, type PricedOutcome } from "@/lib/arb/engine";
import { getFlag } from "@/lib/flags";
import { getOddsProvider } from "@/lib/providers";
import type { EntitlementsDTO, OddsMatrixCell, OpportunityDTO, OpportunityDetailResponse, OpportunityFacets, OpportunityListResponse, ProviderStatusDTO } from "@/lib/types";
import type { OpportunityQuery } from "@/lib/validation";
import { evaluateStaleAlerts } from "./alerts";
import { getLastRun } from "./sync";

export function toOpportunityDTO(opp: OpportunityRow, ev: EventRow, sportTitle: string, watched = false): OpportunityDTO {
  return {
    id: opp.id,
    eventId: opp.eventId,
    marketId: opp.marketId,
    sportKey: opp.sportKey,
    sportTitle,
    league: ev.league,
    homeTeam: ev.homeTeam,
    awayTeam: ev.awayTeam,
    commenceTime: ev.commenceTime.toISOString(),
    eventStatus: ev.status,
    marketKey: opp.marketKey,
    marketLabel: marketLabel(opp.marketKey, opp.outcomeCount, opp.line),
    line: opp.line,
    outcomeCount: opp.outcomeCount,
    status: opp.status,
    impliedSum: opp.impliedSum,
    marginPct: opp.marginPct,
    peakMarginPct: opp.peakMarginPct,
    legs: opp.legs,
    provider: opp.provider,
    isDemo: opp.isDemo,
    timesSeen: opp.timesSeen,
    firstSeenAt: opp.firstSeenAt.toISOString(),
    lastSeenAt: opp.lastSeenAt.toISOString(),
    expiredAt: opp.expiredAt ? opp.expiredAt.toISOString() : null,
    expiredReason: opp.expiredReason,
    dataUpdatedAt: opp.dataUpdatedAt.toISOString(),
    watched,
  };
}

export async function getProviderStatus(): Promise<ProviderStatusDTO> {
  const provider = getOddsProvider();
  const [last, lastSuccess, liveSync] = await Promise.all([getLastRun(provider.key), getLastRun(provider.key, true), getFlag("provider.live_sync", true)]);
  const intervalSec = provider.refreshIntervalSec;
  const lastSuccessAt = lastSuccess?.finishedAt ?? null;
  const stale = !lastSuccessAt || Date.now() - lastSuccessAt.getTime() > intervalSec * 1000 * 3;
  if (stale && last) void evaluateStaleAlerts(provider.key, lastSuccessAt);
  return {
    key: provider.key,
    name: provider.name,
    isDemo: provider.isDemo,
    intervalSec,
    lastRunAt: last?.startedAt.toISOString() ?? null,
    lastSuccessAt: lastSuccessAt ? lastSuccessAt.toISOString() : null,
    lastStatus: last?.status ?? null,
    lastError: last?.status === "error" ? last.error : null,
    stale,
    nextRefreshAt: lastSuccessAt ? new Date(lastSuccessAt.getTime() + intervalSec * 1000).toISOString() : null,
    requestsRemaining: lastSuccess?.requestsRemaining ?? null,
    requestsUsed: lastSuccess?.requestsUsed ?? null,
    liveSyncEnabled: liveSync,
  };
}

export async function getWatchedIds(userId: string): Promise<Set<string>> {
  const rows = await db.select({ id: watchlist.opportunityId }).from(watchlist).where(eq(watchlist.userId, userId));
  return new Set(rows.map((r) => r.id));
}

function sportCondition(values: string[]): SQL | undefined {
  if (!values.length) return undefined;
  const parts = values.map((v) => (v.includes("_") ? eq(opportunities.sportKey, v) : like(opportunities.sportKey, `${v}_%`)));
  return parts.length === 1 ? parts[0] : or(...parts);
}

export async function listOpportunities(userId: string, query: OpportunityQuery, entitlements: EntitlementsDTO): Promise<OpportunityListResponse> {
  const limits = entitlements.limits;
  const advanced = limits.advancedFilters;
  const status = query.status ?? "active";
  const conds: (SQL | undefined)[] = [];
  if (status !== "all") conds.push(eq(opportunities.status, status));
  conds.push(sportCondition(query.sports));
  if (query.markets.length) conds.push(inArray(opportunities.marketKey, query.markets));
  if (query.minMargin !== undefined) conds.push(gte(opportunities.marginPct, query.minMargin));
  if (query.startsWithinHours) conds.push(lte(events.commenceTime, new Date(Date.now() + query.startsWithinHours * 3600_000)));
  if (advanced && query.outcomeCount) conds.push(eq(opportunities.outcomeCount, query.outcomeCount));
  if (query.q) {
    const term = `%${query.q}%`;
    conds.push(or(ilike(events.homeTeam, term), ilike(events.awayTeam, term), ilike(events.league, term)));
  }

  const stake = query.stake && query.stake > 0 ? query.stake : 100;
  const sort = query.sort ?? "margin";
  const dir = query.dir ?? (sort === "event_time" ? "asc" : "desc");
  const order =
    sort === "event_time"
      ? dir === "asc"
        ? asc(events.commenceTime)
        : desc(events.commenceTime)
      : sort === "updated"
        ? dir === "asc"
          ? asc(opportunities.dataUpdatedAt)
          : desc(opportunities.dataUpdatedAt)
        : dir === "asc"
          ? asc(opportunities.marginPct)
          : desc(opportunities.marginPct);

  const rows = await db
    .select({ opp: opportunities, ev: events, sportTitle: sports.title })
    .from(opportunities)
    .innerJoin(events, eq(opportunities.eventId, events.id))
    .innerJoin(sports, eq(events.sportId, sports.id))
    .where(and(...conds.filter((c): c is SQL => Boolean(c))))
    .orderBy(order, desc(opportunities.marginPct))
    .limit(1000);

  const bookmakerRows = await db.select().from(bookmakers);
  const countryByKey = new Map(bookmakerRows.map((b) => [b.key, b.country]));
  const watched = await getWatchedIds(userId);

  let items = rows.map((r) => toOpportunityDTO(r.opp, r.ev, r.sportTitle, watched.has(r.opp.id)));

  if (query.leagues.length) items = items.filter((o) => query.leagues.includes(o.league));
  if (query.bookmakers.length) items = items.filter((o) => o.legs.every((l) => query.bookmakers.includes(l.bookmakerKey)));
  if (query.minNetProfit !== undefined) items = items.filter((o) => (stake * o.marginPct) / 100 >= query.minNetProfit!);
  if (advanced) {
    if (query.countries.length) items = items.filter((o) => o.legs.every((l) => query.countries.includes(countryByKey.get(l.bookmakerKey) ?? "")));
    if (query.minOdds !== undefined) items = items.filter((o) => o.legs.every((l) => l.odds >= query.minOdds!));
    if (query.maxOdds !== undefined) items = items.filter((o) => o.legs.every((l) => l.odds <= query.maxOdds!));
    if (query.freshness && query.freshness !== "any") {
      items = items.filter((o) => {
        const level = dataFreshness(o.dataUpdatedAt).level;
        return query.freshness === "fresh" ? level === "fresh" : level !== "stale";
      });
    }
  }

  const total = items.length;
  const planLimit = limits.scannerLimit;
  const requested = query.limit && query.limit > 0 ? Math.min(query.limit, 500) : 200;
  const effectiveLimit = planLimit === null ? requested : Math.min(planLimit, requested);
  const limited = planLimit !== null && total > planLimit;
  items = items.slice(0, effectiveLimit);

  const [provider, facets] = await Promise.all([getProviderStatus(), getFacets(bookmakerRows)]);
  const advancedRequested = Boolean(query.countries.length || query.minOdds !== undefined || query.maxOdds !== undefined || query.outcomeCount || (query.freshness && query.freshness !== "any"));
  return { items, total, limited, limit: planLimit, advancedFiltersApplied: advanced || !advancedRequested, provider, facets };
}

export async function getFacets(bookmakerRows?: (typeof bookmakers.$inferSelect)[]): Promise<OpportunityFacets> {
  const books = bookmakerRows ?? (await db.select().from(bookmakers));
  const active = await db
    .select({ sportKey: opportunities.sportKey, marketKey: opportunities.marketKey, league: events.league, sportTitle: sports.title })
    .from(opportunities)
    .innerJoin(events, eq(opportunities.eventId, events.id))
    .innerJoin(sports, eq(events.sportId, sports.id))
    .where(eq(opportunities.status, "active"));
  const allSports = await db.select({ key: sports.key, title: sports.title }).from(sports).where(eq(sports.active, true)).orderBy(asc(sports.title));
  const leagues = [...new Set(active.map((a) => a.league))].sort();
  const marketsSet = [...new Set(active.map((a) => a.marketKey))].sort();
  return {
    sports: allSports,
    leagues,
    bookmakers: books.filter((b) => b.active).map((b) => ({ key: b.key, name: b.name, country: b.country })).sort((a, b) => a.name.localeCompare(b.name)),
    countries: [...new Set(books.map((b) => b.country).filter((c): c is string => Boolean(c)))].sort(),
    markets: marketsSet,
  };
}

export async function getOpportunityDetail(userId: string, id: string): Promise<OpportunityDetailResponse | null> {
  const [row] = await db
    .select({ opp: opportunities, ev: events, sportTitle: sports.title })
    .from(opportunities)
    .innerJoin(events, eq(opportunities.eventId, events.id))
    .innerJoin(sports, eq(events.sportId, sports.id))
    .where(eq(opportunities.id, id))
    .limit(1);
  if (!row) return null;

  const watched = await getWatchedIds(userId);
  const opportunity = toOpportunityDTO(row.opp, row.ev, row.sportTitle, watched.has(id));

  const snaps = await db
    .select({ snap: oddsSnapshots, book: bookmakers, availability: userBookmakers.available })
    .from(oddsSnapshots)
    .innerJoin(bookmakers, eq(oddsSnapshots.bookmakerId, bookmakers.id))
    .leftJoin(userBookmakers, and(eq(userBookmakers.bookmakerId, bookmakers.id), eq(userBookmakers.userId, userId)))
    .where(eq(oddsSnapshots.marketId, row.opp.marketId))
    .orderBy(desc(oddsSnapshots.capturedAt));

  const latest = snaps.filter((s) => s.snap.isLatest);
  const outcomes = [...new Set([...row.opp.legs.map((l) => l.outcome), ...latest.map((s) => s.snap.outcomeName)])];
  const bookMap = new Map<string, OpportunityDetailResponse["bookmakers"][number]>();
  const matrix: Record<string, Record<string, OddsMatrixCell>> = {};
  const bestByOutcome = new Map(row.opp.legs.map((l) => [l.outcome, l.bookmakerKey]));

  for (const s of latest) {
    if (!bookMap.has(s.book.key)) {
      bookMap.set(s.book.key, {
        key: s.book.key,
        name: s.book.name,
        country: s.book.country,
        isExchange: s.book.isExchange,
        commissionPct: s.book.commissionPct,
        available: s.availability ?? null,
      });
    }
    (matrix[s.book.key] ??= {})[s.snap.outcomeName] = {
      price: s.snap.price,
      updatedAt: s.snap.providerUpdatedAt.toISOString(),
      isBest: bestByOutcome.get(s.snap.outcomeName) === s.book.key,
    };
  }

  // Previous snapshot (for odds movement warnings).
  const older = snaps.filter((s) => !s.snap.isLatest);
  let previousLegs: OpportunityLeg[] | null = null;
  if (older.length) {
    const latestOlder = older[0].snap.capturedAt.getTime();
    const prevSet = older.filter((s) => Math.abs(s.snap.capturedAt.getTime() - latestOlder) < 5000);
    const prices: Record<string, PricedOutcome[]> = {};
    for (const s of prevSet) {
      (prices[s.snap.outcomeName] ??= []).push({ bookmakerKey: s.book.key, bookmakerName: s.book.name, price: s.snap.price, updatedAt: s.snap.providerUpdatedAt.toISOString() });
    }
    const det = detectBestOdds(outcomes, prices);
    if (det.complete) previousLegs = det.legs.map((l) => ({ outcome: l.outcome, bookmakerKey: l.bookmakerKey, bookmakerName: l.bookmakerName, odds: l.price, updatedAt: l.updatedAt }));
  }

  return {
    opportunity,
    outcomes,
    bookmakers: [...bookMap.values()].sort((a, b) => a.name.localeCompare(b.name)),
    matrix,
    provider: await getProviderStatus(),
    previousLegs,
  };
}

export async function countActive(): Promise<number> {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(opportunities).where(eq(opportunities.status, "active"));
  return count;
}
