import { and, desc, eq, inArray, lt, sql } from "drizzle-orm";
import { db } from "@/db";
import {
  auditLogs,
  authTokens,
  bookmakers,
  errorLogs,
  events,
  markets,
  notifications,
  oddsSnapshots,
  opportunities,
  providerRuns,
  sessions,
  sports,
  userActivity,
  type OpportunityLeg,
} from "@/db/schema";
import { detectBestOdds, type PricedOutcome } from "@/lib/arb/engine";
import { getFlag } from "@/lib/flags";
import { logError, logInfo } from "@/lib/logger";
import { getOddsProvider, type OddsProvider } from "@/lib/providers";
import type { NormalizedBookmakerMarket, NormalizedEvent, ProviderSport, ProviderUsage } from "@/lib/providers/types";
import { slugify } from "@/lib/utils";
import { evaluateAlerts, type OpportunityChange } from "./alerts";

export interface SyncResult {
  skipped: boolean;
  reason?: string;
  runId?: number;
  eventsCount: number;
  opportunitiesCount: number;
  changes: number;
  error?: string;
  nextAllowedAt?: string;
}

let inFlight: Promise<SyncResult> | null = null;
let lastRetentionAt = 0;

/** Trigger a provider refresh. Concurrent callers share the same run. */
export async function runSync(opts: { trigger: string; force?: boolean }): Promise<SyncResult> {
  if (inFlight) return inFlight;
  inFlight = doSync(opts).finally(() => {
    inFlight = null;
  });
  return inFlight;
}

export async function getLastRun(providerKey: string, onlySuccess = false) {
  const where = onlySuccess
    ? and(eq(providerRuns.provider, providerKey), eq(providerRuns.status, "success"))
    : eq(providerRuns.provider, providerKey);
  const [row] = await db.select().from(providerRuns).where(where).orderBy(desc(providerRuns.startedAt)).limit(1);
  return row ?? null;
}

async function doSync({ trigger, force = false }: { trigger: string; force?: boolean }): Promise<SyncResult> {
  const provider = getOddsProvider();
  const intervalMs = provider.refreshIntervalSec * 1000;
  const empty = { eventsCount: 0, opportunitiesCount: 0, changes: 0 };

  const lastSuccess = await getLastRun(provider.key, true);
  if (!force && lastSuccess?.finishedAt && Date.now() - lastSuccess.finishedAt.getTime() < intervalMs) {
    return { skipped: true, reason: "interval", nextAllowedAt: new Date(lastSuccess.finishedAt.getTime() + intervalMs).toISOString(), ...empty };
  }
  if (!provider.isDemo && !force && !(await getFlag("provider.live_sync", true))) {
    return { skipped: true, reason: "flag_disabled", ...empty };
  }
  const lastAny = await getLastRun(provider.key);
  if (!force && lastAny?.status === "error" && lastAny.finishedAt && Date.now() - lastAny.finishedAt.getTime() < 60_000) {
    return { skipped: true, reason: "backoff", ...empty };
  }
  // Recover from crashed runs.
  await db
    .update(providerRuns)
    .set({ status: "error", error: "Run did not finish (process restarted)", finishedAt: new Date() })
    .where(and(eq(providerRuns.status, "running"), lt(providerRuns.startedAt, new Date(Date.now() - 10 * 60_000))));

  const startedAt = new Date();
  const [run] = await db.insert(providerRuns).values({ provider: provider.key, trigger, status: "running", startedAt }).returning();
  const changes: OpportunityChange[] = [];
  let eventsCount = 0;
  let usage: ProviderUsage = {};

  try {
    const sportIds = await upsertSports(await provider.listSports(), provider.sportKeys);
    const bookmakerIds = await loadBookmakerIds();

    for (const sportKey of provider.sportKeys) {
      const sportId = sportIds.get(sportKey);
      if (!sportId) continue;
      const result = await provider.fetchOdds(sportKey);
      if (result.usage) usage = result.usage;
      for (const ev of dedupeEvents(result.events)) {
        await ingestEvent(ev, sportId, provider, bookmakerIds, changes);
        eventsCount += 1;
      }
    }

    changes.push(...(await expireMissing(provider.sportKeys, startedAt)));
    changes.push(...(await expireStarted()));

    const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(opportunities).where(eq(opportunities.status, "active"));
    const finishedAt = new Date();
    await db
      .update(providerRuns)
      .set({
        status: "success",
        finishedAt,
        durationMs: finishedAt.getTime() - startedAt.getTime(),
        eventsCount,
        opportunitiesCount: count,
        requestsUsed: usage.requestsUsed ?? null,
        requestsRemaining: usage.requestsRemaining ?? null,
      })
      .where(eq(providerRuns.id, run.id));

    await evaluateAlerts(changes).catch((err) => logError("Alert evaluation failed", err));
    await maybeRunRetention();
    logInfo("Odds sync complete", { provider: provider.key, trigger, eventsCount, opportunities: count, changes: changes.length });
    return { skipped: false, runId: run.id, eventsCount, opportunitiesCount: count, changes: changes.length };
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown sync error";
    const finishedAt = new Date();
    await db
      .update(providerRuns)
      .set({ status: "error", finishedAt, durationMs: finishedAt.getTime() - startedAt.getTime(), eventsCount, error: message.slice(0, 500) })
      .where(eq(providerRuns.id, run.id));
    await logError("Odds sync failed", err, { provider: provider.key, trigger });
    return { skipped: false, runId: run.id, eventsCount, opportunitiesCount: 0, changes: 0, error: message };
  }
}

async function upsertSports(meta: ProviderSport[], wanted: string[]): Promise<Map<string, number>> {
  const map = new Map<string, number>();
  for (const key of wanted) {
    const m = meta.find((s) => s.key === key) ?? { key, title: key, group: key.split("_")[0], active: true };
    const [row] = await db
      .insert(sports)
      .values({ key: m.key, title: m.title, groupName: m.group, active: true })
      .onConflictDoUpdate({ target: sports.key, set: { title: m.title, groupName: m.group, active: true } })
      .returning({ id: sports.id });
    map.set(key, row.id);
  }
  return map;
}

async function loadBookmakerIds(): Promise<Map<string, number>> {
  const rows = await db.select({ id: bookmakers.id, key: bookmakers.key }).from(bookmakers);
  return new Map(rows.map((r) => [r.key, r.id]));
}

/** Drop duplicate events (same teams & kick-off hour) that some feeds return under different ids. */
export function dedupeEvents(list: NormalizedEvent[]): NormalizedEvent[] {
  const seen = new Set<string>();
  const out: NormalizedEvent[] = [];
  for (const ev of list) {
    const fp = fingerprintOf(ev);
    if (seen.has(fp)) continue;
    seen.add(fp);
    out.push(ev);
  }
  return out;
}

function fingerprintOf(ev: NormalizedEvent): string {
  const commence = new Date(ev.commenceTime);
  const hour = Number.isNaN(commence.getTime()) ? "invalid" : commence.toISOString().slice(0, 13);
  return `${ev.sportKey}|${slugify(ev.homeTeam)}|${slugify(ev.awayTeam)}|${hour}`;
}

function orderOutcomes(group: { marketKey: string; books: NormalizedBookmakerMarket[] }, ev: NormalizedEvent): string[] {
  const names: string[] = [];
  for (const b of group.books) for (const o of b.outcomes) if (!names.includes(o.name)) names.push(o.name);
  const rank = (n: string) => {
    if (group.marketKey === "totals") return n.toLowerCase().startsWith("over") ? 0 : 1;
    if (n === ev.homeTeam) return 0;
    if (n === ev.awayTeam) return 2;
    return 1;
  };
  return names.sort((a, b) => rank(a) - rank(b));
}

function legsChanged(prev: OpportunityLeg[], next: OpportunityLeg[]): boolean {
  if (prev.length !== next.length) return true;
  return next.some((leg) => {
    const old = prev.find((p) => p.outcome === leg.outcome);
    if (!old) return true;
    if (old.bookmakerKey !== leg.bookmakerKey) return true;
    return Math.abs(leg.odds - old.odds) / old.odds >= 0.01;
  });
}

async function ingestEvent(
  ev: NormalizedEvent,
  sportId: number,
  provider: OddsProvider,
  bookmakerIds: Map<string, number>,
  changes: OpportunityChange[],
): Promise<void> {
  const commence = new Date(ev.commenceTime);
  if (Number.isNaN(commence.getTime())) return;
  const status = commence.getTime() > Date.now() ? "upcoming" : "live";

  const [eventRow] = await db
    .insert(events)
    .values({
      provider: provider.key,
      externalId: ev.externalId,
      fingerprint: fingerprintOf(ev),
      sportId,
      sportKey: ev.sportKey,
      league: ev.league,
      homeTeam: ev.homeTeam,
      awayTeam: ev.awayTeam,
      commenceTime: commence,
      status,
    })
    .onConflictDoUpdate({
      target: events.fingerprint,
      set: { provider: provider.key, externalId: ev.externalId, league: ev.league, commenceTime: commence, status, updatedAt: new Date() },
    })
    .returning({ id: events.id });

  const groups = new Map<string, { marketKey: string; line: number; books: NormalizedBookmakerMarket[] }>();
  for (const bm of ev.bookmakers) {
    if (!bm.outcomes.length) continue;
    const key = `${bm.marketKey}|${bm.line}`;
    const g = groups.get(key) ?? { marketKey: bm.marketKey, line: bm.line, books: [] };
    g.books.push(bm);
    groups.set(key, g);
  }

  for (const group of groups.values()) {
    const outcomeNames = orderOutcomes(group, ev);
    if (outcomeNames.length < 2) continue;

    const [market] = await db
      .insert(markets)
      .values({ eventId: eventRow.id, marketKey: group.marketKey, line: group.line, outcomeCount: outcomeNames.length, outcomes: outcomeNames })
      .onConflictDoUpdate({
        target: [markets.eventId, markets.marketKey, markets.line],
        set: { outcomeCount: outcomeNames.length, outcomes: outcomeNames, updatedAt: new Date() },
      })
      .returning({ id: markets.id });

    const snapshotRows: (typeof oddsSnapshots.$inferInsert)[] = [];
    const pricesByOutcome: Record<string, PricedOutcome[]> = {};
    let latestUpdate = 0;

    for (const bm of group.books) {
      let bookmakerId = bookmakerIds.get(bm.bookmakerKey);
      if (!bookmakerId) {
        const [b] = await db
          .insert(bookmakers)
          .values({ key: bm.bookmakerKey, name: bm.bookmakerTitle, supportedMarkets: [] })
          .onConflictDoUpdate({ target: bookmakers.key, set: { name: bm.bookmakerTitle } })
          .returning({ id: bookmakers.id });
        bookmakerId = b.id;
        bookmakerIds.set(bm.bookmakerKey, bookmakerId);
      }
      const parsed = new Date(bm.lastUpdate);
      const updatedAt = Number.isNaN(parsed.getTime()) ? new Date() : parsed;
      latestUpdate = Math.max(latestUpdate, updatedAt.getTime());
      for (const o of bm.outcomes) {
        if (!Number.isFinite(o.price) || o.price <= 1) continue;
        snapshotRows.push({ marketId: market.id, bookmakerId, outcomeName: o.name, price: o.price, providerUpdatedAt: updatedAt });
        (pricesByOutcome[o.name] ??= []).push({
          bookmakerKey: bm.bookmakerKey,
          bookmakerName: bm.bookmakerTitle,
          price: o.price,
          updatedAt: updatedAt.toISOString(),
        });
      }
    }

    await db.update(oddsSnapshots).set({ isLatest: false }).where(and(eq(oddsSnapshots.marketId, market.id), eq(oddsSnapshots.isLatest, true)));
    if (snapshotRows.length) await db.insert(oddsSnapshots).values(snapshotRows);

    const detection = detectBestOdds(outcomeNames, pricesByOutcome);
    const [existing] = await db.select().from(opportunities).where(eq(opportunities.marketId, market.id)).limit(1);
    const dataUpdatedAt = new Date(latestUpdate || Date.now());

    if (detection.complete && detection.isArbitrage) {
      const legs: OpportunityLeg[] = detection.legs.map((l) => ({
        outcome: l.outcome,
        bookmakerKey: l.bookmakerKey,
        bookmakerName: l.bookmakerName,
        odds: l.price,
        updatedAt: l.updatedAt,
      }));
      if (!existing) {
        const [created] = await db
          .insert(opportunities)
          .values({
            eventId: eventRow.id,
            marketId: market.id,
            sportKey: ev.sportKey,
            marketKey: group.marketKey,
            line: group.line,
            status: "active",
            impliedSum: detection.impliedSum,
            marginPct: detection.marginPct,
            peakMarginPct: detection.marginPct,
            outcomeCount: outcomeNames.length,
            legs,
            provider: provider.key,
            isDemo: provider.isDemo,
            dataUpdatedAt,
          })
          .returning();
        changes.push({ type: "new", opportunity: created, previousLegs: null });
      } else {
        const wasExpired = existing.status === "expired";
        const [updated] = await db
          .update(opportunities)
          .set({
            status: "active",
            impliedSum: detection.impliedSum,
            marginPct: detection.marginPct,
            peakMarginPct: Math.max(existing.peakMarginPct, detection.marginPct),
            outcomeCount: outcomeNames.length,
            legs,
            lastSeenAt: new Date(),
            dataUpdatedAt,
            expiredAt: null,
            expiredReason: null,
            timesSeen: wasExpired ? existing.timesSeen + 1 : existing.timesSeen,
          })
          .where(eq(opportunities.id, existing.id))
          .returning();
        if (wasExpired) changes.push({ type: "new", opportunity: updated, previousLegs: existing.legs });
        else if (Math.abs(existing.marginPct - detection.marginPct) >= 0.25 || legsChanged(existing.legs, legs)) {
          changes.push({ type: "odds_change", opportunity: updated, previousLegs: existing.legs, previousMargin: existing.marginPct });
        }
      }
    } else if (existing && existing.status === "active") {
      const [expired] = await db
        .update(opportunities)
        .set({ status: "expired", expiredAt: new Date(), expiredReason: "odds_moved", dataUpdatedAt })
        .where(eq(opportunities.id, existing.id))
        .returning();
      changes.push({ type: "expired", opportunity: expired, previousLegs: existing.legs });
    }
  }
}

async function expireMissing(sportKeys: string[], startedAt: Date): Promise<OpportunityChange[]> {
  if (!sportKeys.length) return [];
  const rows = await db
    .update(opportunities)
    .set({ status: "expired", expiredAt: new Date(), expiredReason: "not_offered" })
    .where(and(eq(opportunities.status, "active"), inArray(opportunities.sportKey, sportKeys), lt(opportunities.lastSeenAt, startedAt)))
    .returning();
  return rows.map((o) => ({ type: "expired" as const, opportunity: o, previousLegs: o.legs }));
}

async function expireStarted(): Promise<OpportunityChange[]> {
  const now = new Date();
  const started = db.select({ id: events.id }).from(events).where(lt(events.commenceTime, now));
  const rows = await db
    .update(opportunities)
    .set({ status: "expired", expiredAt: now, expiredReason: "event_started" })
    .where(and(eq(opportunities.status, "active"), inArray(opportunities.eventId, started)))
    .returning();
  return rows.map((o) => ({ type: "expired" as const, opportunity: o, previousLegs: o.legs }));
}

/** Retention policies (run at most hourly). Keeps the database bounded. */
export async function maybeRunRetention(force = false): Promise<void> {
  if (!force && Date.now() - lastRetentionAt < 60 * 60_000) return;
  lastRetentionAt = Date.now();
  const days = (n: number) => new Date(Date.now() - n * 86_400_000);
  try {
    await db.delete(oddsSnapshots).where(and(eq(oddsSnapshots.isLatest, false), lt(oddsSnapshots.capturedAt, days(30))));
    await db.delete(opportunities).where(and(eq(opportunities.status, "expired"), lt(opportunities.expiredAt, days(180))));
    await db.delete(notifications).where(lt(notifications.createdAt, days(90)));
    await db.delete(userActivity).where(lt(userActivity.createdAt, days(365)));
    await db.delete(auditLogs).where(lt(auditLogs.createdAt, days(365)));
    await db.delete(providerRuns).where(lt(providerRuns.startedAt, days(30)));
    await db.delete(errorLogs).where(lt(errorLogs.createdAt, days(30)));
    await db.delete(sessions).where(lt(sessions.expiresAt, new Date()));
    await db.delete(authTokens).where(lt(authTokens.expiresAt, days(1)));
  } catch (err) {
    await logError("Retention job failed", err);
  }
}
