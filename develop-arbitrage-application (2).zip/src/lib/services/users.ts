import { and, eq, isNull, sql } from "drizzle-orm";
import { db } from "@/db";
import { notifications, userPreferences, type AlertRule, type NotificationRow, type UserPreferences } from "@/db/schema";
import { isEmailConfigured, isGoogleConfigured, isPaymentsConfigured, isTelegramConfigured } from "@/lib/env";
import { getFlag } from "@/lib/flags";
import { getOddsProvider } from "@/lib/providers";
import type { AlertRuleDTO, AppConfigDTO, NotificationDTO, PreferencesDTO } from "@/lib/types";

export async function getOrCreatePreferences(userId: string): Promise<UserPreferences> {
  const [existing] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId)).limit(1);
  if (existing) return existing;
  const [created] = await db.insert(userPreferences).values({ userId }).onConflictDoNothing().returning();
  if (created) return created;
  const [again] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId)).limit(1);
  return again;
}

export function toPreferencesDTO(p: UserPreferences): PreferencesDTO {
  return {
    theme: p.theme,
    currency: p.currency,
    defaultStake: p.defaultStake,
    defaultCommissionPct: p.defaultCommissionPct,
    defaultFxPct: p.defaultFxPct,
    defaultFixedCosts: p.defaultFixedCosts,
    roundingStep: p.roundingStep,
    minMarginPct: p.minMarginPct,
    preferredSports: p.preferredSports,
    preferredMarkets: p.preferredMarkets,
    telegramChatId: p.telegramChatId,
    emailAlerts: p.emailAlerts,
    telegramAlerts: p.telegramAlerts,
    dashboardWidgets: p.dashboardWidgets,
    responsibleUseAckAt: p.responsibleUseAckAt ? p.responsibleUseAckAt.toISOString() : null,
  };
}

export function toNotificationDTO(n: NotificationRow): NotificationDTO {
  return {
    id: n.id,
    type: n.type,
    title: n.title,
    body: n.body,
    data: n.data,
    opportunityId: n.opportunityId,
    readAt: n.readAt ? n.readAt.toISOString() : null,
    createdAt: n.createdAt.toISOString(),
  };
}

export function toAlertRuleDTO(r: AlertRule): AlertRuleDTO {
  return {
    id: r.id,
    name: r.name,
    minMarginPct: r.minMarginPct,
    minNetProfit: r.minNetProfit,
    sports: r.sports,
    markets: r.markets,
    bookmakers: r.bookmakers,
    channels: r.channels,
    enabled: r.enabled,
    lastTriggeredAt: r.lastTriggeredAt ? r.lastTriggeredAt.toISOString() : null,
    createdAt: r.createdAt.toISOString(),
  };
}

export async function countUnread(userId: string): Promise<number> {
  const [{ count }] = await db
    .select({ count: sql<number>`count(*)::int` })
    .from(notifications)
    .where(and(eq(notifications.userId, userId), isNull(notifications.readAt)));
  return count;
}

export async function getAppConfig(): Promise<AppConfigDTO> {
  const provider = getOddsProvider();
  return {
    demoMode: provider.isDemo,
    providerKey: provider.key,
    providerName: provider.name,
    emailDelivery: isEmailConfigured(),
    telegram: isTelegramConfigured(),
    google: isGoogleConfigured(),
    trialEnabled: await getFlag("billing.trial_enabled", true),
    paymentsEnabled: isPaymentsConfigured(),
  };
}
