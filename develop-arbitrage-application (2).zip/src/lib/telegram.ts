import { isTelegramConfigured } from "@/lib/env";
import { logWarn } from "@/lib/logger";

/** Telegram Bot API adapter – only active when TELEGRAM_BOT_TOKEN is configured. */
export async function sendTelegramMessage(chatId: string, text: string): Promise<boolean> {
  if (!isTelegramConfigured() || !chatId) return false;
  try {
    const res = await fetch(`https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text, disable_web_page_preview: true }),
      signal: AbortSignal.timeout(10_000),
    });
    if (!res.ok) logWarn("Telegram API rejected message", { status: res.status });
    return res.ok;
  } catch (err) {
    logWarn("Telegram delivery failed", { error: err instanceof Error ? err.message : String(err) });
    return false;
  }
}
