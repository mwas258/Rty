import type { OpportunityLeg } from "@/db/schema";
import type { PlanKey, PlanLimits } from "@/lib/plans";

export type { OpportunityLeg };

export interface AuthUserDTO {
  id: string;
  email: string;
  displayName: string;
  role: "user" | "admin";
  emailVerified: boolean;
  mfaEnabled: boolean;
  createdAt: string;
}

export interface PreferencesDTO {
  theme: "system" | "dark" | "light";
  currency: string;
  defaultStake: number;
  defaultCommissionPct: number;
  defaultFxPct: number;
  defaultFixedCosts: number;
  roundingStep: number;
  minMarginPct: number;
  preferredSports: string[];
  preferredMarkets: string[];
  telegramChatId: string | null;
  emailAlerts: boolean;
  telegramAlerts: boolean;
  dashboardWidgets: string[];
  responsibleUseAckAt: string | null;
}

export interface EntitlementsDTO {
  plan: PlanKey;
  planName: string;
  status: string;
  limits: PlanLimits;
  periodEnd: string | null;
  cancelAtPeriodEnd: boolean;
  isTrial: boolean;
  trialEligible: boolean;
  source: "subscription" | "admin" | "none";
}

export interface AppConfigDTO {
  demoMode: boolean;
  providerKey: string;
  providerName: string;
  emailDelivery: boolean;
  telegram: boolean;
  google: boolean;
  trialEnabled: boolean;
  paymentsEnabled: boolean;
}

export interface MeResponse {
  user: AuthUserDTO;
  preferences: PreferencesDTO;
  entitlements: EntitlementsDTO;
  config: AppConfigDTO;
  unreadNotifications: number;
}

export interface OpportunityDTO {
  id: string;
  eventId: string;
  marketId: string;
  sportKey: string;
  sportTitle: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  commenceTime: string;
  eventStatus: string;
  marketKey: string;
  marketLabel: string;
  line: number;
  outcomeCount: number;
  status: "active" | "expired";
  impliedSum: number;
  marginPct: number;
  peakMarginPct: number;
  legs: OpportunityLeg[];
  provider: string;
  isDemo: boolean;
  timesSeen: number;
  firstSeenAt: string;
  lastSeenAt: string;
  expiredAt: string | null;
  expiredReason: string | null;
  dataUpdatedAt: string;
  watched: boolean;
}

export interface ProviderStatusDTO {
  key: string;
  name: string;
  isDemo: boolean;
  intervalSec: number;
  lastRunAt: string | null;
  lastSuccessAt: string | null;
  lastStatus: string | null;
  lastError: string | null;
  stale: boolean;
  nextRefreshAt: string | null;
  requestsRemaining: number | null;
  requestsUsed: number | null;
  liveSyncEnabled: boolean;
}

export interface OpportunityFacets {
  sports: { key: string; title: string }[];
  leagues: string[];
  bookmakers: { key: string; name: string; country: string | null }[];
  countries: string[];
  markets: string[];
}

export interface OpportunityListResponse {
  items: OpportunityDTO[];
  total: number;
  limited: boolean;
  limit: number | null;
  advancedFiltersApplied: boolean;
  provider: ProviderStatusDTO;
  facets: OpportunityFacets;
}

export interface OddsMatrixCell {
  price: number;
  updatedAt: string;
  isBest: boolean;
}

export interface OpportunityDetailResponse {
  opportunity: OpportunityDTO;
  outcomes: string[];
  bookmakers: { key: string; name: string; country: string | null; isExchange: boolean; commissionPct: number; available: boolean | null }[];
  matrix: Record<string, Record<string, OddsMatrixCell>>;
  provider: ProviderStatusDTO;
  previousLegs: OpportunityLeg[] | null;
}

export interface BookmakerDTO {
  id: number;
  key: string;
  name: string;
  country: string | null;
  currency: string | null;
  website: string | null;
  supportedMarkets: string[];
  isExchange: boolean;
  commissionPct: number;
  active: boolean;
  available: boolean | null;
  notes: string | null;
  activeOpportunities: number;
}

export interface WatchlistItemDTO {
  id: string;
  note: string | null;
  marginAtSave: number;
  createdAt: string;
  opportunity: OpportunityDTO;
}

export interface AlertRuleDTO {
  id: string;
  name: string;
  minMarginPct: number;
  minNetProfit: number | null;
  sports: string[];
  markets: string[];
  bookmakers: string[];
  channels: string[];
  enabled: boolean;
  lastTriggeredAt: string | null;
  createdAt: string;
}

export interface NotificationDTO {
  id: string;
  type: string;
  title: string;
  body: string;
  data: Record<string, unknown>;
  opportunityId: string | null;
  readAt: string | null;
  createdAt: string;
}

export interface ActivityDTO {
  id: number;
  action: string;
  entityType: string | null;
  entityId: string | null;
  metadata: Record<string, unknown>;
  createdAt: string;
}

export interface DashboardResponse {
  stats: {
    activeOpportunities: number;
    averageMarginPct: number;
    bestMarginPct: number;
    savedBookmakers: number;
    totalBookmakers: number;
    watchlistCount: number;
    unreadNotifications: number;
    expiredLast24h: number;
  };
  topOpportunities: OpportunityDTO[];
  recentActivity: ActivityDTO[];
  recentNotifications: NotificationDTO[];
  entitlements: EntitlementsDTO;
  provider: ProviderStatusDTO;
  widgets: string[];
}

export interface HistoryResponse {
  opportunities: OpportunityDTO[];
  activity: ActivityDTO[];
  historyDays: number;
  csvExport: boolean;
}

export interface SavedFilterDTO {
  id: string;
  name: string;
  filters: Record<string, unknown>;
  createdAt: string;
}

export interface SessionDTO {
  id: string;
  current: boolean;
  userAgent: string | null;
  ip: string | null;
  createdAt: string;
  lastSeenAt: string;
  expiresAt: string;
}
