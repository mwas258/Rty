export function cn(...parts: Array<string | false | null | undefined>): string {
  return parts.filter(Boolean).join(" ");
}

export function formatMoney(value: number, currency = "EUR", maximumFractionDigits = 2): string {
  try {
    return new Intl.NumberFormat(undefined, { style: "currency", currency, maximumFractionDigits }).format(value);
  } catch {
    return `${value.toFixed(maximumFractionDigits)} ${currency}`;
  }
}

export function formatNumber(value: number, digits = 2): string {
  return new Intl.NumberFormat(undefined, { maximumFractionDigits: digits, minimumFractionDigits: digits }).format(value);
}

export function formatPct(value: number, digits = 2): string {
  return `${value >= 0 ? "" : "-"}${Math.abs(value).toFixed(digits)}%`;
}

export function formatOdds(value: number): string {
  return value.toFixed(2);
}

export function formatDateTime(value: string | Date | null | undefined): string {
  if (!value) return "—";
  const d = typeof value === "string" ? new Date(value) : value;
  if (Number.isNaN(d.getTime())) return "—";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(d);
}

export function formatTime(value: string | Date): string {
  const d = typeof value === "string" ? new Date(value) : value;
  return new Intl.DateTimeFormat(undefined, { hour: "2-digit", minute: "2-digit" }).format(d);
}

export function formatRelative(value: string | Date | null | undefined, now = Date.now()): string {
  if (!value) return "—";
  const t = typeof value === "string" ? new Date(value).getTime() : value.getTime();
  if (!Number.isFinite(t)) return "—";
  const diff = Math.round((t - now) / 1000);
  const abs = Math.abs(diff);
  const fmt = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" });
  if (abs < 60) return fmt.format(diff, "second");
  if (abs < 3600) return fmt.format(Math.round(diff / 60), "minute");
  if (abs < 86400) return fmt.format(Math.round(diff / 3600), "hour");
  return fmt.format(Math.round(diff / 86400), "day");
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

const SPORT_ICONS: Record<string, string> = {
  soccer: "⚽",
  basketball: "🏀",
  tennis: "🎾",
  icehockey: "🏒",
  americanfootball: "🏈",
  baseball: "⚾",
  mma: "🥊",
  boxing: "🥊",
  cricket: "🏏",
  rugbyleague: "🏉",
  rugbyunion: "🏉",
  golf: "⛳",
  volleyball: "🏐",
  esports: "🎮",
};

export function sportIcon(sportKey: string): string {
  const group = sportKey.split("_")[0];
  return SPORT_ICONS[group] ?? "🏆";
}

export function sportGroupLabel(sportKey: string): string {
  const group = sportKey.split("_")[0];
  const labels: Record<string, string> = {
    soccer: "Soccer",
    basketball: "Basketball",
    tennis: "Tennis",
    icehockey: "Ice hockey",
    americanfootball: "American football",
    baseball: "Baseball",
    mma: "MMA",
  };
  return labels[group] ?? group;
}

export function truncate(value: string, max = 40): string {
  return value.length > max ? `${value.slice(0, max - 1)}…` : value;
}

export function csvEscape(value: unknown): string {
  const s = value === null || value === undefined ? "" : String(value);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function toCsv(rows: Array<Record<string, unknown>>, columns: string[]): string {
  const header = columns.join(",");
  const body = rows.map((r) => columns.map((c) => csvEscape(r[c])).join(",")).join("\n");
  return `${header}\n${body}\n`;
}
