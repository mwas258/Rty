import { z } from "zod";

export const emailSchema = z.string().trim().toLowerCase().min(3, "Enter your e-mail address").email("Enter a valid e-mail address").max(254);

export const passwordSchema = z
  .string()
  .min(10, "Use at least 10 characters")
  .max(128, "Password is too long")
  .regex(/[A-Za-z]/, "Include at least one letter")
  .regex(/\d/, "Include at least one number");

export const registerSchema = z.object({
  displayName: z.string().trim().min(2, "Enter your name").max(60),
  email: emailSchema,
  password: passwordSchema,
  acceptTerms: z.boolean().refine((v) => v === true, { message: "Please accept the terms and responsible-use notice" }),
});
export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Enter your password"),
  remember: z.boolean(),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const forgotPasswordSchema = z.object({ email: emailSchema });
export type ForgotPasswordInput = z.infer<typeof forgotPasswordSchema>;

export const resetPasswordSchema = z
  .object({
    token: z.string().min(10),
    password: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((v) => v.password === v.confirmPassword, { message: "Passwords do not match", path: ["confirmPassword"] });
export type ResetPasswordInput = z.infer<typeof resetPasswordSchema>;

export const changePasswordSchema = z
  .object({
    currentPassword: z.string().min(1, "Enter your current password"),
    newPassword: passwordSchema,
    confirmPassword: z.string(),
  })
  .refine((v) => v.newPassword === v.confirmPassword, { message: "Passwords do not match", path: ["confirmPassword"] });
export type ChangePasswordInput = z.infer<typeof changePasswordSchema>;

export const mfaCodeSchema = z.object({ code: z.string().trim().regex(/^\d{6}$/, "Enter the 6-digit code") });
export const mfaVerifySchema = z.object({ challengeToken: z.string().min(10), code: z.string().trim().regex(/^\d{6}$/, "Enter the 6-digit code") });
export const mfaDisableSchema = z.object({ password: z.string().min(1), code: z.string().trim().regex(/^\d{6}$/, "Enter the 6-digit code") });

export const profileSchema = z.object({ displayName: z.string().trim().min(2, "Enter your name").max(60) });
export type ProfileInput = z.infer<typeof profileSchema>;

export const preferencesSchema = z.object({
  theme: z.enum(["system", "dark", "light"]),
  currency: z.string().trim().length(3, "Use a 3-letter currency code").toUpperCase(),
  defaultStake: z.number().min(1, "Minimum 1").max(1_000_000),
  defaultCommissionPct: z.number().min(0).max(100),
  defaultFxPct: z.number().min(0).max(100),
  defaultFixedCosts: z.number().min(0).max(100_000),
  roundingStep: z.number().min(0).max(1000),
  minMarginPct: z.number().min(0).max(50),
  preferredSports: z.array(z.string()).max(50),
  preferredMarkets: z.array(z.string()).max(20),
  telegramChatId: z.string().trim().max(64).nullable(),
  emailAlerts: z.boolean(),
  telegramAlerts: z.boolean(),
  dashboardWidgets: z.array(z.string()).max(10),
});
export type PreferencesInput = z.infer<typeof preferencesSchema>;

export const ALERT_CHANNELS = ["in_app", "email", "telegram"] as const;

export const alertRuleSchema = z.object({
  name: z.string().trim().min(2, "Give the alert a name").max(60),
  minMarginPct: z.number().min(0, "Cannot be negative").max(50, "Max 50%"),
  minNetProfit: z.number().min(0).max(1_000_000).nullable(),
  sports: z.array(z.string()).max(50),
  markets: z.array(z.string()).max(20),
  bookmakers: z.array(z.string()).max(100),
  channels: z.array(z.enum(ALERT_CHANNELS)).min(1, "Pick at least one channel"),
  enabled: z.boolean(),
});
export type AlertRuleInput = z.infer<typeof alertRuleSchema>;

export const watchlistCreateSchema = z.object({ opportunityId: z.string().uuid(), note: z.string().trim().max(200).optional() });

export const bookmakerAvailabilitySchema = z.object({ available: z.boolean(), notes: z.string().trim().max(200).nullable().optional() });

export const savedFilterSchema = z.object({ name: z.string().trim().min(1).max(60), filters: z.record(z.string(), z.unknown()) });

export const SORT_OPTIONS = ["margin", "profit", "event_time", "updated"] as const;
export type SortOption = (typeof SORT_OPTIONS)[number];

const csv = (max = 100) => z.string().optional().transform((v) => (v ? v.split(",").map((s) => s.trim()).filter(Boolean).slice(0, max) : []));
const num = () => z.coerce.number().optional();

export const opportunityQuerySchema = z.object({
  q: z.string().trim().max(80).optional(),
  status: z.enum(["active", "expired", "all"]).optional(),
  sports: csv(),
  leagues: csv(),
  countries: csv(),
  bookmakers: csv(),
  markets: csv(),
  minMargin: num(),
  minNetProfit: num(),
  stake: num(),
  minOdds: num(),
  maxOdds: num(),
  startsWithinHours: num(),
  outcomeCount: num(),
  freshness: z.enum(["any", "fresh", "aging"]).optional(),
  sort: z.enum(SORT_OPTIONS).optional(),
  dir: z.enum(["asc", "desc"]).optional(),
  limit: num(),
});
export type OpportunityQuery = z.infer<typeof opportunityQuerySchema>;

export const subscriptionActionSchema = z.object({ action: z.enum(["start_trial", "cancel", "resume", "checkout"]) });

export const adminUserPatchSchema = z.object({
  userId: z.string().uuid(),
  role: z.enum(["user", "admin"]).optional(),
  status: z.enum(["active", "disabled"]).optional(),
  plan: z.enum(["free", "premium"]).optional(),
  resetMfa: z.boolean().optional(),
});

export const flagPatchSchema = z.object({ key: z.string().min(1), enabled: z.boolean() });

export const activitySchema = z.object({
  action: z.enum(["calculation_saved", "opportunity_viewed", "export_csv"]),
  entityType: z.string().max(40).optional(),
  entityId: z.string().max(80).optional(),
  metadata: z.record(z.string(), z.unknown()).optional(),
});
