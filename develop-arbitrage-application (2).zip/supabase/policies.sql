-- Row-level security policies for deployments where the same schema lives in Supabase and
-- clients query PostgREST directly with Supabase Auth JWTs. In the default self-hosted
-- deployment every query goes through the Next.js API layer, which enforces the same rules.
--
-- Assumptions: profiles.id == auth.uid(); admin role is stored in profiles.role and NEVER settable by users.

create or replace function public.is_admin() returns boolean language sql stable as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

-- Owner-scoped tables -------------------------------------------------------
alter table public.profiles enable row level security;
create policy "profiles: read own"   on public.profiles for select using (id = auth.uid() or public.is_admin());
create policy "profiles: update own" on public.profiles for update using (id = auth.uid())
  with check (id = auth.uid() and role = (select role from public.profiles where id = auth.uid())); -- role immutable by owner
create policy "profiles: admin manage" on public.profiles for all using (public.is_admin()) with check (public.is_admin());

alter table public.user_preferences enable row level security;
create policy "prefs: owner" on public.user_preferences for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table public.user_bookmakers enable row level security;
create policy "user_bookmakers: owner" on public.user_bookmakers for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table public.watchlist enable row level security;
create policy "watchlist: owner" on public.watchlist for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table public.alert_rules enable row level security;
create policy "alert_rules: owner" on public.alert_rules for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table public.notifications enable row level security;
create policy "notifications: owner read" on public.notifications for select using (user_id = auth.uid());
create policy "notifications: owner mark read" on public.notifications for update using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "notifications: owner delete" on public.notifications for delete using (user_id = auth.uid());
-- inserts are performed by the service role (alert engine) only.

alter table public.saved_filters enable row level security;
create policy "saved_filters: owner" on public.saved_filters for all using (user_id = auth.uid()) with check (user_id = auth.uid());

alter table public.user_activity enable row level security;
create policy "activity: owner read"   on public.user_activity for select using (user_id = auth.uid());
create policy "activity: owner insert" on public.user_activity for insert with check (user_id = auth.uid());

alter table public.subscriptions enable row level security;
create policy "subscriptions: owner read" on public.subscriptions for select using (user_id = auth.uid() or public.is_admin());
-- writes only via service role (billing webhooks / admin API) so users cannot grant themselves Premium.

alter table public.sessions enable row level security;
alter table public.auth_tokens enable row level security;
-- No user policies: sessions/tokens are only touched by the server with the service role.

-- Shared read-only reference & market data ---------------------------------
alter table public.bookmakers enable row level security;
alter table public.sports enable row level security;
alter table public.events enable row level security;
alter table public.markets enable row level security;
alter table public.odds_snapshots enable row level security;
alter table public.opportunities enable row level security;
create policy "bookmakers: authenticated read"     on public.bookmakers     for select to authenticated using (true);
create policy "sports: authenticated read"         on public.sports         for select to authenticated using (true);
create policy "events: authenticated read"         on public.events         for select to authenticated using (true);
create policy "markets: authenticated read"        on public.markets        for select to authenticated using (true);
create policy "odds_snapshots: authenticated read" on public.odds_snapshots for select to authenticated using (true);
create policy "opportunities: authenticated read"  on public.opportunities  for select to authenticated using (true);
-- Plan-based limits (e.g. free users see only the top 15) must stay in the API layer / an RPC, not in RLS.

-- Operations tables: admin only ---------------------------------------------
alter table public.audit_logs enable row level security;
alter table public.feature_flags enable row level security;
alter table public.provider_runs enable row level security;
alter table public.error_logs enable row level security;
create policy "audit: admin read"        on public.audit_logs    for select using (public.is_admin());
create policy "flags: admin all"         on public.feature_flags for all    using (public.is_admin()) with check (public.is_admin());
create policy "provider_runs: admin"     on public.provider_runs for select using (public.is_admin());
create policy "error_logs: admin"        on public.error_logs    for select using (public.is_admin());

-- Retention (run via pg_cron or the application's maybeRunRetention job):
--   delete from odds_snapshots where is_latest = false and captured_at < now() - interval '30 days';
--   delete from opportunities  where status = 'expired' and expired_at < now() - interval '180 days';
--   delete from notifications  where created_at < now() - interval '90 days';
--   delete from provider_runs  where started_at < now() - interval '30 days';
--   delete from error_logs     where created_at < now() - interval '30 days';
--   delete from audit_logs     where created_at < now() - interval '365 days';
